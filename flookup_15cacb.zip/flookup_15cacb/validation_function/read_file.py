import pandas as pd
import io
from pandas.api.types import is_datetime64_any_dtype as is_datetime

def read_file(file):
    file_name = file.filename
    df = None
    if file_name.endswith('.csv'):
        try:
            file_content = io.StringIO(file.stream.read().decode("UTF8"))
            df = pd.read_csv(file_content)
            df = df.applymap(lambda x: x.upper() if isinstance(x, str) else x)
            df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            df = df.fillna("")
        except Exception as e:
            print(e)
            raise e
    else:
        xlsx = pd.ExcelFile(file)
        df = xlsx.parse(xlsx.sheet_names[0])
        df = df.applymap(lambda x: x.upper() if isinstance(x, str) else x)
        df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        df = df.fillna("")

    # convert date columns to string


    # is_datetime(df[column])]]
    for col in df.columns:
        if is_datetime(df[col]):
            df[col] = df[col].dt.strftime('%Y-%m-%d')

    return df

def check_file_validity(file):
    file_name = file.filename
    if not (file and (file_name.endswith('.csv') or file_name.endswith('.xls') or file_name.endswith('.xlsx'))):
        return 'Invalid'
    return 'valid'

def replace_special_characters(s):
    s = str(s)
    s = s.replace("&", "&amp;")
    s = s.replace("<", "&lt;")
    s = s.replace(">", "&gt;")
    s = s.replace("'", "&apos;")
    s = s.replace('"', "&quot;")
    return s
