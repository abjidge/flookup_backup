import re
import datetime
import pandas as pd

def is_valid_pan(pan):
    pan_regex = r"^[A-Z]{5}\d{4}[A-Z]{1}$"
    match = re.search(pan_regex, str(pan))
    return bool(match)

def validate_string_length_lessthan(st, length):
    if len(str(st)) <= length:
        return True
    else:
        False

def is_valid_tan(tan):
    tan_regex = r"^[A-Z]{4}\d{5}[A-Z]{1}$"
    match = re.search(tan_regex, str(tan))
    return bool(match)

def is_valid_pincode(pincode):
    pincode_pattern = "^[0-9]{6}$"
    return bool(re.match(pincode_pattern, str(pincode)))

def is_valid_email(email):
    email_pattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return bool(re.match(email_pattern, str(email)))

def is_valid_phone_number(phone_number):
    phone_number_pattern = "^\+?[0-9]{10}$"
    return bool(re.match(phone_number_pattern, str(phone_number)))

def is_valid_phone_number2(phone_number):
    phone_number_pattern = "^\+?[0-9]{10,12}$"
    return bool(re.match(phone_number_pattern, str(phone_number)))

# def is_valid_date(date_string):
#     date_regex = r"\d{4}-\d{2}-\d{2}"
#     match = re.search(date_regex, str(date_string))
#     return bool(match)


def check_date_in_range(date, start, end=None):
    # if isinstance(date, pd.Timestamp):
    #     date = date.strftime('%Y-%m-%d')

    start = datetime.datetime.strptime(start, "%Y-%m-%d")
    date = datetime.datetime.strptime(date, "%Y-%m-%d")
    if not end:
        end = datetime.datetime.now()
    if start <= date <= end:
        return True
    else:
        return False

def is_valid_date(date_text):
    # if isinstance(date_text, pd.Timestamp):
    #     try:
    #         date_text.strftime('%Y-%m-%d')
    #         return True
    #     except:
    #         return False
    # else:
    try:
        datetime.date.fromisoformat(date_text)
        return True
    except ValueError:
        return False

def is_valid_currency(value):
    currency_regex = r"^\d+(\.\d{1,2})?$"
    match = re.search(currency_regex, str(value))
    return bool(match)

def is_valid_membership_no(n):
    return bool(re.match("^[0-9]{6}$", str(n)))

def is_valid_bsr(bsr):
    pattern = r'^\d{7}$'
    return bool(re.match(pattern, str(bsr)))

def is_not_past_date(date):
    # if isinstance(date, pd.Timestamp):
    #     date = date.strftime('%Y-%m-%d')
    current_date = datetime.datetime.now().strftime("%Y-%m-%d")
    if datetime.datetime.strptime(date, "%Y-%m-%d") < datetime.datetime.strptime(current_date, "%Y-%m-%d"):
        return False
    else:
        return True
