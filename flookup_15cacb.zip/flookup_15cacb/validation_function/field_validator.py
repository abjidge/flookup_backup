from validation_function.format_validator import is_valid_pincode, is_valid_email, is_valid_phone_number, is_valid_date, \
    is_valid_currency, is_valid_pan, is_valid_tan, is_valid_membership_no, is_valid_bsr, is_not_past_date, \
    validate_string_length_lessthan, check_date_in_range, is_valid_phone_number2
from static.data.data import list_states, list_countries, fields_map, list_status, list_residential_status, list_banks, list_nature_remittance, list_purpose_categories, list_purpose_code, list_currency, binary_list, codes
from flask import make_response, jsonify

def field_order_validator(df,form_type):
    return "invalid" if not (list(df.columns)==fields_map[form_type]) else "valid"

def replace_codes(df, form_type, is_15CAC):
    if form_type == '15CAA' or form_type == '15CAD':
        df['State (Remitter)'] = df['State (Remitter)'].replace(codes)
        df['Country (Remitter)'] = df['Country (Remitter)'].replace(codes)
        df['Residential status of remitter'] = df['Residential status of remitter'].replace(codes)
        df['Country (Remittee)'] = df['Country (Remittee)'].replace(codes)
        df['Country to which remittance is made'] = df['Country to which remittance is made'].replace(codes)
        df['Name of Bank'] = df['Name of Bank'].replace(codes)
        df['I/ We (Verification)'] = df['I/ We (Verification)'].replace(codes)
        df['Please furnish the relevant purpose category as per RBI'] = df['Please furnish the relevant purpose category as per RBI'].replace(codes)
        if form_type == '15CAA':
            df['Status (Remitter)'] = df['Status (Remitter)'].replace(codes)
            df['Nature of remittance as per agreement/document'] = df['Nature of remittance as per agreement/document'].replace(codes)
        else:
            df['Status of Remitter'] = df['Status of Remitter'].replace(codes)
            df['Nature of Remittance'] = df['Nature of Remittance'].replace(codes)
    if form_type == '15CB':
        df['Remitter Detail ( I / We)'] = df['Remitter Detail ( I / We)'].replace(codes)
        if not is_15CAC:
            df['Remitter Detail ( I / We)'] = df['Remitter Detail ( I / We)'].replace({"1":"01","2":"02"})
        df['Remitter Honorific (Mr/ Ms / M/s)'] = df['Remitter Honorific (Mr/ Ms / M/s)'].replace(codes)
        # df['State (Beneficiary of the Remittance)'] = df['State (Beneficiary of the Remittance)'].replace(codes)
        df['Beneficiary Honirific (Mr/ Ms / M/s)'] = df['Beneficiary Honirific (Mr/ Ms / M/s)'].replace(codes)
        df['Country (Beneficiary of the Remittance)'] = df['Country (Beneficiary of the Remittance)'].replace(codes)
        df['Country to which remittance is made'] = df['Country to which remittance is made'].replace(codes)
        df['Currency in which remittance is made ']=df['Currency in which remittance is made '].replace(codes)
        df['Name of the Bank']=df['Name of the Bank'].replace(codes)
        if not is_15CAC:
            df['Name of the Bank'] = df['Name of the Bank'].str.slice(-2)
        df['Nature of remittance as per agreement/document']=df['Nature of remittance as per agreement/document'].replace(codes)
        df['Please furnish the relevant purpose category as per RBI']=df['Please furnish the relevant purpose category as per RBI'].replace(codes)
        df['In Case the remittance is net of the taxes, whether tax payable has been grossed up ']=df['In Case the remittance is net of the taxes, whether tax payable has been grossed up '].replace(codes)
        df['Is remittance chargeable to tax in India '] = df['Is remittance chargeable to tax in India '].replace(codes)
        df['Whether tax residency certificate is obtained from the recipient of the remittance '] = df['Whether tax residency certificate is obtained from the recipient of the remittance '].replace(codes)
        df['If the remittance is for royalties, fee for technical services, interest, dividend, etc , (not connected with permanent establishment) please indicate '] = df['If the remittance is for royalties, fee for technical services, interest, dividend, etc , (not connected with permanent establishment) please indicate '].replace(codes)
        df['In Case the remittance is on account of business income, please indicate '] = df['In Case the remittance is on account of business income, please indicate '].replace(codes)
        df['If yes, Whether Such income is liable to tax in India '] = df['If yes, Whether Such income is liable to tax in India '].replace(codes)
        df['In case the remittance is on account of capital gains, please indicate'] = df['In case the remittance is on account of capital gains, please indicate'].replace(codes)
        df['In case of remittance not covered by sub-items A,B,C']=df['In case of remittance not covered by sub-items A,B,C'].replace(codes)
        df['Whether taxable in India as per DTAA'] = df['Whether taxable in India as per DTAA'].replace(codes)
        try:
            df['Rate of TDS Category']=df['Rate of TDS Category'].replace(codes)
        except:
            pass
        df['State (Accountant)'] = df['State (Accountant)'].replace(codes)
        df['Country (Accountant)'] = df['Country (Accountant)'].replace(codes)
    if form_type == "15CAC":
        df['State (Remitter)'] = df['State (Remitter)'].replace(codes)
        df['Country (Remitter)'] = df['Country (Remitter)'].replace(codes)
        df['Status (Remitter)'] = df['Status (Remitter)'].replace(codes)
        df['Residential Status of Remitter'] = df['Residential Status of Remitter'].replace(codes)
        df['Status (Remittee)'] = df['Status (Remittee)'].replace(codes)
        df['Whether any order/ certificate u/s 195(2)/ 195(3)/ 197 of Income-Tax Act has been obtained from the Assessing Officer'] = df['Whether any order/ certificate u/s 195(2)/ 195(3)/ 197 of Income-Tax Act has been obtained from the Assessing Officer'].replace(codes)
        df['Section under which order/certificate has been obtained'] = df['Section under which order/certificate has been obtained'].replace(codes)
        df['I/ We (Verification)'] = df['I/ We (Verification)'].replace(codes)
    return df

def validate(value,column_name,form_type,internal_validation_map):
    if column_name == "Document Type" or column_name == "15CA Document Type":
        return ("valid" if value == form_type else "Incorrect Document Type")
    elif column_name == "Remitter Detail ( I / We)" or column_name=="I/ We (Verification)":
        return ("valid" if value in ['I','WE'] else "Choose from I/We")
    elif column_name == "Remitter Honorific (Mr/ Ms / M/s)":
        return ("valid" if value in ['MR','MS','M/S'] else "Choose from Mr/ Ms / M/s")
    elif column_name == "Beneficiary Honirific (Mr/ Ms / M/s)":
        return ("valid" if value in ['MR','MS','M/S'] else "Choose from Mr/ Ms / M/s")
    elif column_name == 'Name of the Benificiary of the remittance ':
        if not validate_string_length_lessthan(value, 125):
            return "Name of Benificiary of the remittance should have less than 126 characters"
        return ("valid" if value != "" else "Name of the Benificiary of the remittance is Mandatory")
    elif column_name == 'Accountant Name':
        if not validate_string_length_lessthan(value,125):
            return "Accountant name should be less than or equal to 125 characters."
        return ("valid" if value != "" else "Accountant Name is Mandatory")
    elif column_name == 'Name of the propriertorship/firm (Accountant)':
        if not validate_string_length_lessthan(value, 125):
            return "Name of the propriertorship/firm (Accountant) should have less than or equal to 125 characters"
        return ("valid" if value != "" else "Name of the propriertorship/firm (Accountant) is Mandatory")
    elif column_name == 'Name of Remitter' or column_name == 'Name of the Remitter':
        if not validate_string_length_lessthan(value, 126):
            return "Name of Remitter should have less than 126 characters"
        return ("valid" if value != "" else "Name of Remitter is Mandatory")
    elif column_name == 'PAN of the Remitter (if available)' or column_name=='PAN of the Remitter' or column_name=='PAN Number  of Remitter':
        if value != "" and not is_valid_pan(value):
            return "Invalid Pan number"
        internal_validation_map['PAN'] = (True if (value!="" and is_valid_pan(value)) else False)
        return "valid"
    elif column_name == 'TAN of the Remitter (if available)':
        if value != "" and not is_valid_tan(value):
            return "Invalid TAN number"
        return ("valid" if (internal_validation_map['PAN'] or is_valid_tan(value)) else "Either a valid PAN or TAN of Remitter is Mandatory")
    elif column_name == 'TAN of the Remitter':
        if value != "" and not is_valid_tan(value):
            return "Invalid TAN number"
        return "valid" if (value=="" or is_valid_tan(value)) else "Invalid value for TAN of the Remitter"
    elif column_name == 'Flat/Door/Building (Beneficiary of the Remittance)':
        if not validate_string_length_lessthan(value, 50):
            return "Flat/Door/Building (Beneficiary of the Remittance) should have less than or equal to 50 characters"
        return ("valid" if value != "" else "Flat/ Door/ Bulding of Beneficiary of the Remittance Mandatory")
    elif column_name == "Name of the Premises/Building/Village (Beneficiary of the Remittance)":
        if not validate_string_length_lessthan(value, 50):
            return "Name of the Premises/Building/Village (Beneficiary of the Remittance) should have less than or equal to 50 characters"
        return "valid"
    elif column_name == "Road/Street (Beneficiary of the Remittance)":
        if not validate_string_length_lessthan(value, 50):
            return "Road/Street (Beneficiary of the Remittance) should have less than or equal to 50 characters"
        return "valid"
    elif column_name == 'Flat/Door/Building (Accountant)':
        if not validate_string_length_lessthan(value, 50):
            return "Flat/Door/Building (Accountant) should have less than or equal to 50 characters"
        return ("valid" if value != "" else "Flat/ Door/ Bulding of Accountant is Mandatory")
    elif column_name == 'Premises/Building/Village (Accountant)':
        if not validate_string_length_lessthan(value, 50):
            return "Premises/Building/Village (Accountant) should have less than or equal to 50 characters"
        return 'valid'
    elif column_name == 'Road/Street (Accountant)':
        if not validate_string_length_lessthan(value, 50):
            return "Road/Street (Accountant) should have less than or equal to 50 characters"
        return 'valid'
    elif column_name == 'Flat/ Door/ Block No. (Remitter)':
        if not validate_string_length_lessthan(value, 50):
            return "Flat/ Door/ Block No. (Remitter) should have less than or equal to 50 characters"
        return ("valid" if value != "" else "Flat/ Door/ Bulding is Mandatory")
    elif column_name == 'Area/Locality (Beneficiary of the Remittance)':
        if not validate_string_length_lessthan(value, 50):
            return "Area/Locality (Beneficiary of the Remittance) should have less than or equal to 50 characters"
        return ("valid" if value != "" else "Area/ Locality for Beneficiary of the Remittance is Mandatory")
    elif column_name == 'Area/Locality (Accountant)':
        if not validate_string_length_lessthan(value, 50):
            return "Area/Locality (Accountant) should have less than or equal to 50 characters"
        return ("valid" if value != "" else "Area/ Locality for Accountant is Mandatory")
    elif column_name == 'BSR Code of the bank branch (7 digit)':
        return 'valid' if value != "" and is_valid_bsr(value) else "Please Enter a valid BSR code"
    elif column_name == 'Area/ Locality (Remitter)':
        if value == '': return "Area/ Locality (Remitter) is Mandatory."
        if validate_string_length_lessthan(value,50):
            return 'valid'
        else:
            return 'Area/ Locality (Remitter) should be less than 50 character.'
    elif column_name == 'Town/ City/ District (Remitter)':
        if value == '': return "Town/ City/ District (Remitter) is Mandatory."
        if validate_string_length_lessthan(value,50):
            return 'valid'
        else:
            return 'Town/ City/ District (Remitter) should be less than 50 character.'
    elif column_name == 'Town/City/District (Accountant)':
        if not validate_string_length_lessthan(value, 50):
            return "Town/City/District (Accountant) should have less than or equal to 50 characters"
        return ("valid" if value != "" else "Town/ City/ District of Account is Mandatory")
    elif column_name == 'Town/City/District (Beneficiary of the Remittance)':
        if not validate_string_length_lessthan(value, 50):
            return "Town/City/District (Beneficiary of the Remittance) should have less than or equal to 50 characters"
        return ("valid" if value != "" else "Town/ City/ District for Beneficiary of the Remittance is Mandatory")
    elif column_name == "Registration No":
        if value == "": return 'valid'
        if str(value).isalnum() and len(str(value)) == 8:
            return 'valid'
        else:
            return "Invalid value for Registration No, should be consisting of only alphanumeric characters and length should be exactly 8."
    elif column_name == 'State (Remitter)':
        if value == "": return "State is Mandatory"
        return "valid" if value.upper() in list_states else "Invalid value for state"
    elif column_name == 'State (Accountant)':
        if value == "": return "State of Accountant is Mandatory"
        return "valid" if value.upper() in list_states else "Invalid value for state of Accountant"
    elif column_name == 'State (Beneficiary of the Remittance)':
        if value == "": return "State is Mandatory for Beneficiary of the Remittance"
        return "valid" if value.upper() in list_states else "Invalid value for state of Beneficiary of the Remittance"
    elif column_name == 'Country (Remitter)':
        if value == "": return "Country is Mandatory"
        return "valid" if value.upper() in list_countries else "Invalid value for Country"
    elif column_name == 'Country (Accountant)':
        if value == "": return "Country of Accountant is Mandatory"
        return "valid" if value.upper() in list_countries else "Invalid value for Country of Accountant"
    elif column_name == 'Country (Beneficiary of the Remittance)':
        if value == "": return "Country for Beneficiary of the Remittance is Mandatory"
        return "valid" if value.upper() in list_countries else "Invalid value for Country for Beneficiary of the Remittance"
    elif column_name == 'ZIP Code (Beneficiary of the Remittance)':
        if value == "": return "ZIP Code is Mandatory for Beneficiary of the Remittance"
        return 'valid' if str(value).isalnum() and 6 <= len(str(value)) <= 8 else "Invalid value for ZIP Code (Beneficiary of the Remittance), can consist of only alphanumeric characters upto length 8."
    elif column_name == 'PIN Code (Remitter)':
        if value == "": return "PIN Code is Mandatory"
        return "valid" if is_valid_pincode(value) else "Invalid PIN Code"
    elif column_name == 'AO Type':
        if value == "": return 'valid'
        if validate_string_length_lessthan(value,2) and str(value).isalnum():
            return 'valid'
        return "AO Type shouldn't be more than 2 characters and should consist of alphanumerics only."
    elif column_name == 'Area Code':
        if value == "": return 'valid'
        if validate_string_length_lessthan(value,3) and str(value).isalnum():
            return 'valid'
        return "Area Code shouldn't be more than 3 characters and should consist of alphanumerics only."
    elif column_name == 'Range Code':
        if value == "": return 'valid'
        if validate_string_length_lessthan(value,3) and str(value).isdigit():
            return 'valid'
        return "Range Code shouldn't be more than 3 characters and should consist of numbers only."
    elif column_name == 'AO Number':
        if value == "": return 'valid'
        if validate_string_length_lessthan(value,2) and str(value).isdigit():
            return 'valid'
        return "AO Number shouldn't be more than 2 characters and should consist of numbers only."
    elif column_name == 'PIN Code (Accountant)':
        if value == "": return "PIN Code of Accountant is Mandatory"
        return "valid" if is_valid_pincode(value) else "Invalid PIN Code of Accountant"
    elif column_name == 'Email Address (Remitter)':
        if value == "": return "Email Address is Mandatory"
        return "valid" if is_valid_email(value) else "Invalid Email Address(Remitter)"
    elif column_name == 'Phone Number (Remitter)':
        if value == "": return "Phone Number is Mandatory"
        return "valid" if is_valid_phone_number(value) else "Invalid Phone Number"
    elif column_name == 'Phone Number (Remittee)' or column_name=="(ISD Code)-Phone Number (Recipient of Remittance)":
        if value == "": return "valid"
        return "valid" if is_valid_phone_number2(value) else "Invalid Phone Number for Remittee."
    elif column_name == 'Status (Remitter)' or column_name=='Status of Remitter':
        if value == "": return "Status is Mandatory"
        return "valid" if value in list_status else "Invalid Status Entry"
    elif column_name == "Status (Remittee)":
        if value == "": return "Status (Remittee) is Mandatory"
        return "valid" if value in list_status else "Invalid Status Entry for Remittee"
    elif column_name == 'Residential status of remitter':
        if value == "": return "Residential status of remitter is Mandatory"
        return "valid" if value in list_residential_status else "Invalid Residential status of remitter Entry"
    elif column_name == 'Name of recipient of remittance':
        if value == "": return "Name of recipient of remittance is Mandatory"
        if validate_string_length_lessthan(value,125):
            return "valid"
        else:
            return "Name of recipient of remittance should be less than 125 characters."
    elif column_name == 'Flat/ Door/ Block no. (Remittee)':
        if value == "": return "Flat/ Door/ Block no of Remittee is Mandatory"
        if validate_string_length_lessthan(value,50):
            return 'valid'
        else:
            return "Flat/ Door/ Block no of Remittee should be less than 50 characters."
    elif column_name == 'Name of premises/ Building/ Village Remittee (Remittee)':
        if value == "": return 'valid'
        if validate_string_length_lessthan(value,50):
            return 'valid'
        else:
            return 'Name of Premises/ Building/ Village (Remittee) should be less than 50 character.'
    elif column_name == 'Road/ Street/ Post Office (Remittee)':
        if value == "": return 'valid'
        if validate_string_length_lessthan(value,50):
            return 'valid'
        else:
            return 'Road/ Street/ Post Office (Remittee) should be less than 50 character.'
    elif column_name == 'PAN of the recipient of remittance, if available':
        if value == "": return 'valid'
        if is_valid_pan(value):
            return 'valid'
        else:
            return "Invalid PAN Number for recipient of remittance"
    elif column_name == 'Area/ Locality (Remittee)':
        if value == "": return "Area/ Locality of Remittee is Mandatory"
        if validate_string_length_lessthan(value,50):
            return 'valid'
        else:
            return 'Area/ Locality of Remittee should be less than 50 character.'
    elif column_name == 'Town/ City/ District (Remittee)':
        if value == "": return "Town/ City/ District of Remittee is Mandatory"
        if validate_string_length_lessthan(value,50):
            return 'valid'
        else:
            return 'Town/ City/ District of Remittee should be less than 50 character.'
    elif column_name == 'State (Remittee)':
        if value == "": return "State of Remittee is Mandatory"
        return "valid" if value.upper() in list_states else "Invalid value for state of Remittee"
    elif column_name == 'Country (Remittee)':
        if value == "": return "Country is Mandatory"
        return "valid" if value.upper() in list_countries else "Invalid value for Country of Remittee"
    elif column_name == 'ZIP Code (Remittee)':
        if value == "": return "ZIP Code is Mandatory"
        return "valid" if str(value).isalnum() and 6 <= len(str(value)) <= 8 else "Zip code length should be 6-8 characters and should contain only alphanumeric characters."
    elif column_name == 'Country to which remittance is made':
        if value == "": return "Country to which remittance is made is Mandatory"
        if value in list_countries:
            internal_validation_map['COUNTRY'] = (False if value=="OTHERS" else True)
            return "valid"
        else:
            return "Invalid value for Country to which remittance is made"
    elif column_name == "Enabled only if 'Country to which remittance is made' value is set to 'Others'" or column_name=="Country to which remittance is made' value is set to 'Other'":
        if ('COUNTRY' in internal_validation_map and internal_validation_map["COUNTRY"]==False):
            return ("valid" if value!="" else "As Country to which remittance is made is 'OTHERS', this field can't be empty")
        else:
            print(value,value=="")
            return "valid" if value =="" else "This field should be left empty, as county is not 'Other'."
    elif column_name == 'Currency in which remittance is made\xa0' or column_name=="Currency in which remittance is made ":
        if value == "": return "Currency in which remittance is made is Mandatory"
        if value in list_currency:
            internal_validation_map['CURRENCY'] = (False if value=="Others" else True)
            return "valid"
        else:
            return "Invalid value for Currency in which remittance is made"
    elif column_name == "Enabled only if 'Currency in which remittance is made' value is set to 'Others'" or column_name=="Enabled only if 'Currency in which remittance is made' value is set to 'Other'":
        if ('CURRENCY' in internal_validation_map and internal_validation_map["CURRENCY"]==False):
            return ("valid" if value!="" else "As Currency in which remittance is made is 'OTHERS', this field can't be empty")
        else:
            return "valid" if value == "" else "This field should be empty as currency is not selected to others."
    elif column_name == "Country of which the recipient of remittance is resident":
        if value == "": return "Country of which the recipient of remittance is resident is Mandatory"
        return ("valid" if value in list_countries else "Invalid value for country of which the recipient of remittance is resident")
    elif column_name == "Amount payable in foreign currency":
        if value == "": return "Amount payable in foreign currency is Mandatory"
        return ("valid" if is_valid_currency(value) else "currency value can be max upto two decimal points(Amount payable in foreign currency)")
    elif column_name == "Designation (Verification)":
        if value == "": return "Designation is Mandatory."
        if validate_string_length_lessthan(value,20):
            return 'valid'
        else:
            return 'Designation should not contain more than 20 characters.'
    elif column_name == "Amount of TDS in foreign currency ":
        if value == "": return "Amount of TDS in foreign currency is Mandatory"
        if is_valid_currency(value):
            if int(value)>0:internal_validation_map['TAX'] = True
            return ("valid" if is_valid_currency(value) else "currency value can be max upto two decimal points(Amount of TDS in foreign currency)")
    elif column_name == "Amount payable in Indian Rs":
        if value == "": return "Amount payable in Indian Rs is Mandatory"
        return ("valid" if is_valid_currency(value) else "currency value can be max upto two decimal points(Amount payable in Indian currency)")
    elif column_name == "Amount of TDS in Indian Rs":
        if value == "": return "Amount of TDS in Indian Rs is Mandatory"
        if is_valid_currency(value):
            if int(value)>0:internal_validation_map['TAX'] = True
            return ("valid" if is_valid_currency(value) else "currency value can be max upto two decimal points(Amount of TDS in foreign currency)")
    elif column_name == "Rate of TDS Category" and form_type=="15CB":
        if 'TAX' in internal_validation_map and internal_validation_map['TAX'] == True:
            return 'valid' if value in ['AS PER INCOME-TAX ACT', 'AS PER DTAA'] else "Invalid value for Rate of TDS Category"
        else:
            return 'valid' if value=="" else "This field should be empty as TDS value is 0"
    elif column_name == "Rate of TDS" and form_type=="15CB":
        if 'TAX' in internal_validation_map and internal_validation_map['TAX'] == True:
            return 'valid' if is_valid_currency(value) else "Invalid value for Rate of TDS"
        else:
            return 'valid' if value=="" else "This field should be empty as TDS value is 0"
    elif column_name == "Date of deduction of tax at source, if any" and form_type=="15CB":
        if 'TAX' in internal_validation_map and internal_validation_map['TAX'] == True:
            return 'valid' if is_valid_date(value) else "Invalid format for for Date(YYYY-MM-DD) of deduction of tax at source, if any"
        else:
            return 'valid' if value=="" else "This field should be empty as TDS value is 0"
    elif column_name == "Actual amount of remittance after TDS (In foreign currency)" and form_type=="15CB":
        if 'TAX' in internal_validation_map and internal_validation_map['TAX'] == True:
            return 'valid' if is_valid_currency(value) else "Invalid value for Actual amount of remittance after TDS (In foreign currency)"
        else:
            return 'valid' if value=="" else "This field should be empty as TDS value is 0"
    elif column_name == 'Amount payable before TDS (In Indian Currency)':
        if value == "": return "Amount payable before TDS (In Indian Currency) is Mandatory"
        return "valid" if is_valid_currency(value) else "currency value can be max upto two decimal points(Amount payable before TDS)"
    elif column_name == 'Aggregate amount of remittance made during the financial year including this proposed remittance':
        if value == "": return "Aggregate amount of remittance made during the financial year including this proposed remittance, is Mandatory"
        return "valid" if is_valid_currency(value) else "currency value can be max upto two decimal points(Aggregate amount of remittance made)"
    elif column_name == 'Name of Bank':
        if value == "": return "Name of Bank is Mandatory"
        if value in list_banks:
            internal_validation_map['BANK'] = (False if value == 'Other Bank' else True)
            return "valid"
        else:
            return "Invalid value for Name of Bank"
    elif column_name == "Enabled only if 'Name of the Bank' value is set to 'Other'\n":
        if 'BANK' in internal_validation_map and internal_validation_map['BANK']==False:
            return ("valid" if value!="" else "As Name of the Bank is Other, this can't be empty")
        else:
            return "valid" if value == "" else "This field should be empty, as 'Name of the Bank' is not 'Other'."
    elif column_name == 'Name of the branch of the bank':
        if value == "": return "Name of the branch is Mandatory"
        if not validate_string_length_lessthan(value,125):
            return "Branch of the bank shouldn't be greater than 125 characters"
        return "valid"
    elif column_name == 'Proposed date of remittance (YYYY-MM-DD)':
        if value == "": return "Proposed date of remittance is Mandatory"
        if is_valid_date(value):
            if is_not_past_date(value):
                return "valid"
            else:
                return "Proposed date of remittance (YYYY-MM-DD), can not be before the current date."
        else:
            return "Invalid data format for Proposed date of remittance (YYYY-MM-DD)"
    elif column_name == 'Name of Premises/ Building/ Village (Remitter)':
        if value == "": return 'valid'
        if validate_string_length_lessthan(value,50):
            return 'valid'
        else:
            return 'Name of Premises/ Building/ Village (Remitter) should be less than 50 character.'
    elif column_name == 'Road/ Street/ Post Office (Remitter)':
        if value == "": return 'valid'
        if validate_string_length_lessthan(value,50):
            return 'valid'
        else:
            return 'Road/ Street/ Post Office (Remitter) should be less than 50 character.'
    elif column_name == 'Nature of remittance as per agreement/document':
        if value == "": return "Nature of remittance as per agreement/document is Mandatory"
        if value in list_nature_remittance:
            internal_validation_map['NATURE'] = (False if value=='Other Income / Other (Not in the Nature of Income)' else True)
            return "valid"
        else:
            return "Invalid value for Nature of remittance as per agreement/document"
    elif column_name == "Enabled only if 'Nature of remittance' value is set to 'Other Income'\n":
        if 'NATURE' in internal_validation_map and internal_validation_map['NATURE'] == False:
            return ("valid" if value!="" else "As you have choosen 'Other Income / Other (Not in the Nature of Income)', this field can't be empty")
        else:
            return "valid" if value == "" else "This field should be empty, as 'Nature of remittance' is not 'Other'."
    elif column_name == 'Please furnish the relevant purpose category as per RBI':
        if value == "": return "purpose category as per RBI is Mandatory"
        return "valid" if value in list_purpose_categories else "Invalid value for purpose category as per RBI"
    elif column_name == 'Please furnish the relevant purpose code as per RBI':
        return "valid" if value!="" else "purpose code as per RBI is Mandatory"
    elif column_name == 'Is remittance chargeable to tax in India ':
        if value == 'YES':
            internal_validation_map['REMITTANCE_CHARGEABLE']=True
        elif value == 'NO':
            internal_validation_map['REMITTANCE_CHARGEABLE']=False
        return "valid" if value in binary_list else "choose YES/NO for Is remittance chargeable to tax"
    elif column_name == "If not, reasons thereof":
        if 'REMITTANCE_CHARGEABLE' in internal_validation_map and internal_validation_map['REMITTANCE_CHARGEABLE'] == False:
            return "valid" if value!="" else "As Is remittance chargeable to tax is choosen as 'NO', this field can't be empty"
        else:
            return "valid" if value == "" else "As Is remittance chargeable to tax is choosen as 'Yes', this field should be empty"
    elif column_name == "If yes, The relevant section of the Act under which the remittance is covered":
        if 'REMITTANCE_CHARGEABLE' in internal_validation_map and internal_validation_map['REMITTANCE_CHARGEABLE'] == True:
            return "valid" if value!="" else "As Is remittance chargeable to tax is choosen as 'YES', this field can't be empty"
        else:
            return "valid" if value=="" else "As Is remittance chargeable to tax is choosen as 'No', this field should be empty"
    elif column_name == "If yes, The amount of Income Chargeable to tax ":
        if 'REMITTANCE_CHARGEABLE' in internal_validation_map and internal_validation_map['REMITTANCE_CHARGEABLE'] == True:
            return "valid" if (value!="" and is_valid_currency(value)) else "As Is remittance chargeable to tax is choosen as 'YES', this field can't be empty(in case of no vlaue enter 0)"
        else:
            return "valid" if (value=="") else "As Is remittance chargeable to tax is choosen as 'No', this field should be empty"
    elif column_name == "If yes, The Tax liablity":
        if 'REMITTANCE_CHARGEABLE' in internal_validation_map and internal_validation_map['REMITTANCE_CHARGEABLE'] == True:
            return "valid" if (value!="" and is_valid_currency(value)) else "As Is remittance chargeable to tax is choosen as 'YES', this field can't be empty(in case of no vlaue enter 0)"
        else:
            return "valid" if (value=="" ) else "As Is remittance chargeable to tax is choosen as 'No', this field should be empty"
    elif column_name == "If yes, Basis of determining taxable income and tax liability":
        if 'REMITTANCE_CHARGEABLE' in internal_validation_map and internal_validation_map['REMITTANCE_CHARGEABLE'] == True:
            return "valid" if value!="" else "As Is remittance chargeable to tax is choosen as 'YES', this field can't be empty"
        else:
            return "valid" if (value=="" ) else "As Is remittance chargeable to tax is choosen as 'No', this field should be empty"
    elif column_name == "Whether tax residency certificate is obtained from the recipient of the remittance ":
        if value in binary_list:
            internal_validation_map['TAX_RESIDENCY_CERTIFICATE'] = (True if value=="YES" else False)
            return "valid"
        else:
            return "Choose YES/NO for Whether tax residency certificate is obtained from the recipient"
    elif column_name == "If the remittance is for royalties, fee for technical services, interest, dividend, etc , (not connected with permanent establishment) please indicate ":
        if value in binary_list:
            internal_validation_map['IS_FOR_ROYALITIES'] = (True if value=="YES" else False)
            return "valid"
        else:
            return "Choose YES/NO for If the remittance is for royalties"
    elif column_name == "If yes, Article of DTAA":
        if "IS_FOR_ROYALITIES" in internal_validation_map and internal_validation_map['IS_FOR_ROYALITIES'] == True:
            return "valid" if value!="" else "As value for If the remittance is for royalties, is choosen as 'YES', this field is Mandatory"
        else:
            return "valid" if value=="" else "As value for If the remittance is for royalties, is choosen as 'No', this field should be empty"
    elif column_name == "Rate of TDS required to be deduced in terms of such article of the applicable DTAA":
        if "IS_FOR_ROYALITIES" in internal_validation_map and internal_validation_map['IS_FOR_ROYALITIES'] == True:
            return "valid" if (value!="" and is_valid_currency(value)) else "As value for If the remittance is for royalties, is choosen as 'YES', this field is Mandatory"
        else:
            return "valid" if value == "" else "As value for If the remittance is for royalties, is choosen as 'No', this field should be empty"
    elif column_name == "In Case the remittance is on account of business income, please indicate ":
        if value in binary_list:
            internal_validation_map['ACCOUNT_OF_BUSINESS'] = (True if value=="YES" else False)
            return "valid"
        else:
            return "Choose YES/NO for In Case the remittance is on account of business income, please indicate "
    elif column_name == "If yes, Whether Such income is liable to tax in India ":
        if ("ACCOUNT_OF_BUSINESS" in internal_validation_map and internal_validation_map['ACCOUNT_OF_BUSINESS']==True):
            if value in binary_list:
                internal_validation_map['IS_TAXABLE'] = (True if value=="YES" else False)
                return "valid"
            else:
                return "Choose YES/NO for If yes, Whether Such income is liable to tax in India "
        else:
            return "valid"
    elif column_name=="If so, the basis of arriving at the rate of deduction of tax":
        if ("IS_TAXABLE" in internal_validation_map and internal_validation_map["IS_TAXABLE"]==True):
            return 'valid' if (value!="" and is_valid_currency(value)) else "Field If so, the basis of arriving at the rate of deduction of tax is Mandatory"
        else:
            return "valid" if value == "" else "As, Whether Such income is liable to tax in India is answered as 'No', this field should be empty."
    elif column_name=="If not, please furnish brief reasons thereof. specifying relevant article of DTAA ":
        if ("IS_TAXABLE" in internal_validation_map and internal_validation_map["IS_TAXABLE"]==False):
            return "valid" if value!="" else "As, Whether Such income is liable to tax in India is answered as 'NO', this field is Mandatory"
        else:
            return "valid" if value == "" else "As, Whether Such income is liable to tax in India is answered as 'Yes', this field should be empty."
    elif column_name=="In case the remittance is on account of capital gains, please indicate":
        if value in binary_list:
            internal_validation_map['ACCOUNT_OF_CAPITAL'] = (True if value=="YES" else False)
            return "valid"
        else:
            return "Choose YES/NO for In case the remittance is on account of capital gains, please indicate"
    elif column_name=="Amount of long term capital gains ":
        if "ACCOUNT_OF_CAPITAL" in internal_validation_map and internal_validation_map["ACCOUNT_OF_CAPITAL"]==True:
            return "valid" if (value!="" and is_valid_currency(value)) else "Invalid value for Amount of long term capital gains"
        else:
            return "valid" if value == "" else "This field should be empty"
    elif column_name=="Amount of short-term capital gains ":
        if "ACCOUNT_OF_CAPITAL" in internal_validation_map and internal_validation_map["ACCOUNT_OF_CAPITAL"]==True:
            return "valid" if (value!="" and is_valid_currency(value)) else "Invalid value for Amount of short-term capital gains"
        else:
            return "valid" if value == "" else "This field should be empty"
    elif column_name=="Basis of arriving at taxable income ":
        if "ACCOUNT_OF_CAPITAL" in internal_validation_map and internal_validation_map["ACCOUNT_OF_CAPITAL"]==True:
            return "valid" if value!="" else "Invalid value for Basis of arriving at taxable income"
        else:
            return "valid" if value == "" else "This field should be empty"
    elif column_name=="In case of remittance not covered by sub-items A,B,C":
        if value in binary_list:
            internal_validation_map['ABC'] = (True if value=="YES" else False)
            return "valid"
        else:
            return "Choose YES/NO for In case of remittance not covered by sub-items A,B,C"
    elif column_name=="If yes, Please specify nature of remittance ":
        if "ABC" in internal_validation_map and internal_validation_map['ABC']==True:
            return "valid" if value!="" else "If yes, Please specify nature of remittance"
        else:
            return "valid" if value == "" else "This field should be empty"
    elif column_name=="Whether taxable in India as per DTAA":
        if value in binary_list:
            internal_validation_map['IS_TAXABLE_D'] = (True if value=="YES" else False)
            return "valid"
        else:
            return "Choose YES/NO for Whether taxable in India as per DTAA"
    elif column_name == "If yes, rate of TDS required to be deduced in terms of such article of the applicable DTAA":
        if 'IS_TAXABLE_D' in internal_validation_map and internal_validation_map['IS_TAXABLE_D'] == True:
            return 'valid' if (value!="" and is_valid_currency(value)) else "Field 'If yes, rate of TDS required to be deduced in terms of such article of the applicable DTAA' is Mandatory"
        else:
            return "valid"
    elif column_name == "If not, then please furnish brief reasons thereof. specifying relevant article of DTAA":
        if 'IS_TAXABLE_D' in internal_validation_map and internal_validation_map['IS_TAXABLE_D'] == False:
            return 'valid' if (value!="") else "Field 'If not, then please furnish brief reasons thereof. specifying relevant article of DTAA' is Mandatory"
        else:
            return "valid"
    elif column_name == 'Tax Deducted: (a) Amount of TDS':
        if value == "": return "Tax Deducted: (a) Amount of TDS is Mandatory"
        return "valid" if is_valid_currency(value) else "in Tax Deducted: (a) Amount of TDS, value of currency can be max upto two decimal points"
    elif column_name == "Membership No":
        return "valid" if is_valid_membership_no(value) else "Invalid membership number for Accountant"
    elif column_name == "Principal Place of Business":
        if value == "": "Principal Place of Business is Mandatory"
        if validate_string_length_lessthan(value,75):
            return 'valid'
        return "Principal place of business shouldn't be more than 75 characters."
    elif column_name == "Principal place of business (Recipient of Remittance)":
        if not validate_string_length_lessthan(value, 50):
            return "Principal place of business (Recipient of Remittance) should have less than or equal to 50 characters"
        return "valid" if value!="" else "Principal place of business (Recipient of Remittance) is Mandatory"
    elif column_name == "Date of certificate (YYYY-MM-DD)":
        if value =="": return "Date of certificate (YYYY-MM-DD) is Mandatory"
        return 'valid' if is_valid_date(value) else "Incorrect Date format for Date of certificate (YYYY-MM-DD)"
    elif column_name == "Certificate No.":
        return 'valid' if value != "" else "Certificate No. is Mandatory"
    elif column_name == "Whether any order/ certificate u/s 195(2)/ 195(3)/ 197 of Income-Tax Act has been obtained from the Assessing Officer":
        if value =="": return "Whether any order/ certificate u/s 195(2)/ 195(3)/ 197 of Income-Tax Act has been obtained from the Assessing Officer is Mandatory"
        return "valid" if value in binary_list else " Invalid value for Whether any order/ certificate u/s 195(2)/ 195(3)/ 197 of Income-Tax Act has been obtained from the Assessing Officer"
    elif column_name == "Son/ Daughter of (Verification)":
        if value!="": "Son/ Daughter of (Verification) is Mandatory"
        if validate_string_length_lessthan(value,125):
            return 'valid'
        else:
            return 'Son/ Daughter of (Verification) should be less than 50 character.'
    elif column_name == "Full name in block letters (Verification)":
        if value!="": "Full name in block letters (Verification) is Mandatory"
        if validate_string_length_lessthan(value,125):
            return 'valid'
        else:
            return 'Full name in block letters (Verification) should be less than 50 character.'
    elif column_name == "Place (Verification)":
        if value == "": return "Place (Verification) is Mandatory"
        if validate_string_length_lessthan(value,20):
            if str(value).isalpha():
                return 'valid'
            else:
                "Invalid as contains special characters or numbers, in field Place (Verification)"
        else:
            return "Place (Verification) should be less than 20 characters."
    elif column_name == "Place (Verification)":
        return "valid" if value!="" else "Place (Verification) is Mandatory"
    elif column_name == "Date (YYYY-MM-DD) (Verification)":
        if value == "": return "Date (YYYY-MM-DD) (Verification) is Mandatory"
        return "valid" if (is_valid_date(value) and is_not_past_date(value)) else "Invalid format or date is before current date for, Date (YYYY-MM-DD) (Verification)"
    elif column_name == 'Tax Deducted: (b) Rate of TDS':
        if value == "": return 'valid'
        if is_valid_currency(value):
            return 'valid'
        else:
            return "Rate of TDS should not contain special characters or alphabatic characters."
    elif column_name == "Tax Deducted: (c) Date of deduction (YYYY-MM-DD)":
        if value == "":
            return "Date of deduction (YYYY-MM-DD) is Mandatory"
        if is_valid_date(value):
            if check_date_in_range(value, '2004-04-01'):
                return "valid"
            else:
                return "Date should be between the 1st of April of 2004 and the current date for Date of deduction (YYYY-MM-DD)"
        else:
            return "Incorrect Date format for Date of deduction (YYYY-MM-DD)"
    else:
        return "valid"
