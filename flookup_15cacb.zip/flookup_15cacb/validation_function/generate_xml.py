import pandas as pd
import re, uuid,os
import shutil
def generate_xml(df,form_type):
    # Replace blank values with a pattern
    print('generating XML')
    df = df.replace('', '######')
    df = df.fillna('######')
    li = [df.columns.values.tolist()] + df.values.tolist()
    folder = str(uuid.uuid4())
    os.makedirs(folder)
    counter = 1
    if form_type == "15CAA":
        for row in li[1:]:
          st ='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ns5:FORM15CA xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:Form="http://incometaxindiaefiling.gov.in/common" xmlns:FORM15CA="http://incometaxindiaefiling.gov.in/FORM15CA" xmlns:FORM15CB="http://incometaxindiaefiling.gov.in/FORM15CB" xmlns:ns5="http://incometaxindiaefiling.gov.in/FORM15CAB">
  <Form:CreationInfo>
    <Form:SWVersionNo>1.0</Form:SWVersionNo>
    <Form:SWCreatedBy>ITD_JAVA_UTILITY</Form:SWCreatedBy>
    <Form:XMLCreatedBy>ITD_JAVA_UTILITY</Form:XMLCreatedBy>
    <Form:XMLCreationDate>2021-12-13</Form:XMLCreationDate>
    <Form:IntermediaryCity>Delhi</Form:IntermediaryCity>
  </Form:CreationInfo>
  <Form:Form_Details>
    <Form:FormName>FORM15CA</Form:FormName>
    <Form:Description>FORM15CA</Form:Description>
    <Form:AssessmentYear>2017</Form:AssessmentYear>
    <Form:SchemaVer>Ver1.0</Form:SchemaVer>
    <Form:FormVer>1.1</Form:FormVer>
  </Form:Form_Details>
  <ns5:PartType>PA</ns5:PartType>
  <ns5:RemitterDetls>
    <ns5:NameRemitter>{1}</ns5:NameRemitter>
    <ns5:PAN>{2}</ns5:PAN>
    <ns5:Tan>{3}</ns5:Tan>
    <ns5:RemitterAddrs>
      <ns5:PremisesBuildingVillage>{5}</ns5:PremisesBuildingVillage>
      <ns5:TownCityDistrict>{8}</ns5:TownCityDistrict>
      <ns5:FlatDoorBuilding>{4}</ns5:FlatDoorBuilding>
      <ns5:AreaLocality>{7}</ns5:AreaLocality>
      <ns5:Pincode>{11}</ns5:Pincode>
      <Form:State>{9}</Form:State>
      <ns5:RoadStreet>{6}</ns5:RoadStreet>
      <ns5:Country>{10}</ns5:Country>
    </ns5:RemitterAddrs>
      <ns5:EmailRemitter>{12}</ns5:EmailRemitter>
      <ns5:PhoneRemitter>{13}</ns5:PhoneRemitter>
      <ns5:Status>{14}</ns5:Status>
      <ns5:DomesticFlg>{15}</ns5:DomesticFlg>
  </ns5:RemitterDetls>
  <ns5:RemitteeDetls>
    <ns5:NameRemittee>{16}</ns5:NameRemittee>
    <ns5:PanRemittee>{17}</ns5:PanRemittee>
    <ns5:RemitteeAddrs>
      <ns5:PremisesBuildingVillage>{19}</ns5:PremisesBuildingVillage>
      <ns5:TownCityDistrict>{22}</ns5:TownCityDistrict>
      <ns5:FlatDoorBuilding>{18}</ns5:FlatDoorBuilding>
      <ns5:AreaLocality>{21}</ns5:AreaLocality>
      <ns5:ZipCode>{25}</ns5:ZipCode>
      <Form:State>{23}</Form:State>
      <ns5:RoadStreet>{20}</ns5:RoadStreet>
      <ns5:Country>{24}</ns5:Country>
    </ns5:RemitteeAddrs>
    <ns5:EmailRemittee>{26}</ns5:EmailRemittee>
    <ns5:PhoneRemittee>{27}</ns5:PhoneRemittee>
    <ns5:CountryRemMade>{28}</ns5:CountryRemMade>
    <ns5:CountryRemMadeDesc>{29}</ns5:CountryRemMadeDesc>
  </ns5:RemitteeDetls>
  <ns5:RemittanceDetls>
    <ns5:AmtPayBefTds>{30}</ns5:AmtPayBefTds>
    <ns5:AggAmtRem>{31}</ns5:AggAmtRem>
    <ns5:NameBankCode>{32}</ns5:NameBankCode>
    <ns5:NameBankDesc>{33}</ns5:NameBankDesc>
    <ns5:BranchName>{34}</ns5:BranchName>
    <ns5:PropDateRem>{35}</ns5:PropDateRem>
    <ns5:NatureRemCategory>{36}</ns5:NatureRemCategory>
    <ns5:NatureRemCode>{37}</ns5:NatureRemCode>
    <ns5:AmtTaxDeductn>{40}</ns5:AmtTaxDeductn>
    <ns5:DateOfDeductn>{42}</ns5:DateOfDeductn>
    <ns5:RevPurCategory>{38}</ns5:RevPurCategory>
    <ns5:RevPurCode>{39}</ns5:RevPurCode>
    <ns5:RateofTDS>{41}</ns5:RateofTDS>
  </ns5:RemittanceDetls>
  <ns5:Declaration>
    <ns5:LandlordName>{44}</ns5:LandlordName>
    <ns5:StyledName>{45}</ns5:StyledName>
    <ns5:I_We>{43}</ns5:I_We>
    <ns5:VerificationDate>{48}</ns5:VerificationDate>
    <ns5:VerDesignation>{46}</ns5:VerDesignation>
    <ns5:VerificationPlace>{47}</ns5:VerificationPlace>
  </ns5:Declaration>
</ns5:FORM15CA>'''.format(*row)

          # remove blank values(pattern) line
          st = re.sub(".*######.*\n?","",st)

          # write file to folder
          filename = folder + '/' + 'file_' + str(counter) + '.xml'
          with open(filename, "w") as f:
            f.write(st)

          # print(st)
          counter = counter + 1
    if form_type == "15CB":
        for row in li[1:]:
          st ='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<FORM15CB:FORM15CB xmlns:Form="http://incometaxindiaefiling.gov.in/common" xmlns:FORM15CB="http://incometaxindiaefiling.gov.in/FORM15CAB">
    <Form:CreationInfo>
        <Form:SWVersionNo>1</Form:SWVersionNo>
        <Form:SWCreatedBy>DIT-EFILING-JAVA</Form:SWCreatedBy>
        <Form:XMLCreatedBy>DIT-EFILING-JAVA</Form:XMLCreatedBy>
        <Form:XMLCreationDate>2023-01-31</Form:XMLCreationDate>
        <Form:IntermediaryCity>Delhi</Form:IntermediaryCity>
    </Form:CreationInfo>
    <Form:Form_Details>
        <Form:FormName>FORM15CB</Form:FormName>
        <Form:Description>FORM15CB</Form:Description>
        <Form:AssessmentYear>2017</Form:AssessmentYear>
        <Form:SchemaVer>Ver1.1</Form:SchemaVer>
        <Form:FormVer>1</Form:FormVer>
    </Form:Form_Details>
    <FORM15CB:RemitterDetails>
        <FORM15CB:IorWe>{1}</FORM15CB:IorWe>
        <FORM15CB:RemitterHonorific>{2}</FORM15CB:RemitterHonorific>
        <FORM15CB:NameRemitter>{3}</FORM15CB:NameRemitter>
        <FORM15CB:PAN>{4}</FORM15CB:PAN>
        <FORM15CB:BeneficiaryHonorific>{5}</FORM15CB:BeneficiaryHonorific>
    </FORM15CB:RemitterDetails>
    <FORM15CB:RemitteeDetls>
        <FORM15CB:NameRemittee>{6}</FORM15CB:NameRemittee>
        <FORM15CB:RemitteeAddrs>
            <FORM15CB:PremisesBuildingVillage>{8}</FORM15CB:PremisesBuildingVillage>
            <FORM15CB:TownCityDistrict>{11}</FORM15CB:TownCityDistrict>
            <FORM15CB:FlatDoorBuilding>{7}</FORM15CB:FlatDoorBuilding>
            <FORM15CB:AreaLocality>{10}</FORM15CB:AreaLocality>
            <FORM15CB:ZipCode>{14}</FORM15CB:ZipCode>
            <Form:State>{12}</Form:State>
            <FORM15CB:RoadStreet>{9}</FORM15CB:RoadStreet>
            <FORM15CB:Country>{13}</FORM15CB:Country>
        </FORM15CB:RemitteeAddrs>
    </FORM15CB:RemitteeDetls>
    <FORM15CB:RemittanceDetails>
        <FORM15CB:CountryRemMadeSecb>{15}</FORM15CB:CountryRemMadeSecb>
        <FORM15CB:CountryRemMadeSecbDesc>{16}</FORM15CB:CountryRemMadeSecbDesc>
        <FORM15CB:CurrencySecbCode>{17}</FORM15CB:CurrencySecbCode>
        <FORM15CB:CurrencySecbDesc>{18}</FORM15CB:CurrencySecbDesc>
        <FORM15CB:AmtPayForgnRem>{19}</FORM15CB:AmtPayForgnRem>
        <FORM15CB:AmtPayIndRem>{20}</FORM15CB:AmtPayIndRem>
        <FORM15CB:NameBankCode>{21}</FORM15CB:NameBankCode>
        <FORM15CB:NameBankDesc>{22}</FORM15CB:NameBankDesc>
        <FORM15CB:BranchName>{23}</FORM15CB:BranchName>
        <FORM15CB:BsrCode>{24}</FORM15CB:BsrCode>
        <FORM15CB:PropDateRem>{25}</FORM15CB:PropDateRem>
        <FORM15CB:NatureRemCategory>{26}</FORM15CB:NatureRemCategory>
        <FORM15CB:NatureRemCode>{27}</FORM15CB:NatureRemCode>
        <FORM15CB:RevPurCategory>{28}</FORM15CB:RevPurCategory>
        <FORM15CB:RevPurCode>{29}</FORM15CB:RevPurCode>
        <FORM15CB:TaxPayGrossSecb>{30}</FORM15CB:TaxPayGrossSecb>
    </FORM15CB:RemittanceDetails>
    <FORM15CB:ItActDetails>
        <FORM15CB:RemittanceCharIndia>{31}</FORM15CB:RemittanceCharIndia>
        <FORM15CB:ReasonNot>{32}</FORM15CB:ReasonNot>
        <FORM15CB:SecRemCovered>{33}</FORM15CB:SecRemCovered>
        <FORM15CB:AmtIncChrgIt>{34}</FORM15CB:AmtIncChrgIt>
        <FORM15CB:TaxLiablIt>{35}</FORM15CB:TaxLiablIt>
        <FORM15CB:BasisDeterTax>{36}</FORM15CB:BasisDeterTax>
    </FORM15CB:ItActDetails>
    <FORM15CB:DTAADetails>
        <FORM15CB:TaxResidCert>{37}</FORM15CB:TaxResidCert>
        <FORM15CB:RelevantDtaa>{38}</FORM15CB:RelevantDtaa>
        <FORM15CB:RelevantArtDtaa>{39}</FORM15CB:RelevantArtDtaa>
        <FORM15CB:TaxIncDtaa>{40}</FORM15CB:TaxIncDtaa>
        <FORM15CB:TaxLiablDtaa>{41}</FORM15CB:TaxLiablDtaa>
        <FORM15CB:RemForRoyFlg>{42}</FORM15CB:RemForRoyFlg>
        <FORM15CB:ArtDtaa>{43}</FORM15CB:ArtDtaa>
        <FORM15CB:RateTdsADtaa>{44}</FORM15CB:RateTdsADtaa>
        <FORM15CB:RemAcctBusIncFlg>{45}</FORM15CB:RemAcctBusIncFlg>
        <FORM15CB:IncLiabIndiaFlg>{46}</FORM15CB:IncLiabIndiaFlg>
        <FORM15CB:ArrAtRateDedTax>{47}</FORM15CB:ArrAtRateDedTax>
        <FORM15CB:ReasonofReleventArtDtaa>{48}</FORM15CB:ReasonofReleventArtDtaa>
        <FORM15CB:RemOnCapGainFlg>{49}</FORM15CB:RemOnCapGainFlg>
        <FORM15CB:AmtLongTrm>{50}</FORM15CB:AmtLongTrm>
        <FORM15CB:AmtShortTrm>{51}</FORM15CB:AmtShortTrm>
        <FORM15CB:BasisTaxIncDtaa>{52}</FORM15CB:BasisTaxIncDtaa>
        <FORM15CB:OtherRemDtaa>{53}</FORM15CB:OtherRemDtaa>
        <FORM15CB:NatureRemDtaa>{54}</FORM15CB:NatureRemDtaa>
        <FORM15CB:TaxIndDtaaFlg>{55}</FORM15CB:TaxIndDtaaFlg>
        <FORM15CB:RateTdsDDtaa>{56}</FORM15CB:RateTdsDDtaa>
        <FORM15CB:RelArtDetlDDtaa>{57}</FORM15CB:RelArtDetlDDtaa>
    </FORM15CB:DTAADetails>
    <FORM15CB:TDSDetails>
        <FORM15CB:AmtPayForgnTds>{58}</FORM15CB:AmtPayForgnTds>
        <FORM15CB:AmtPayIndianTds>{59}</FORM15CB:AmtPayIndianTds>
        <FORM15CB:RateTdsSecbFlg>{60}</FORM15CB:RateTdsSecbFlg>
        <FORM15CB:RateTdsSecB>{61}</FORM15CB:RateTdsSecB>
        <FORM15CB:ActlAmtTdsForgn>{62}</FORM15CB:ActlAmtTdsForgn>
        <FORM15CB:DednDateTds>{63}</FORM15CB:DednDateTds>
    </FORM15CB:TDSDetails>
    <FORM15CB:AcctntDetls>
        <FORM15CB:NameAcctnt>{64}</FORM15CB:NameAcctnt>
        <FORM15CB:NameFirmAcctnt>{65}</FORM15CB:NameFirmAcctnt>
        <FORM15CB:AcctntAddrs>
            <FORM15CB:TownCityDistrict>{70}</FORM15CB:TownCityDistrict>
            <FORM15CB:FlatDoorBuilding>{66}</FORM15CB:FlatDoorBuilding>
            <FORM15CB:AreaLocality>{69}</FORM15CB:AreaLocality>
            <FORM15CB:Pincode>{73}</FORM15CB:Pincode>
            <Form:State>{71}</Form:State>
            <FORM15CB:RoadStreet>{68}</FORM15CB:RoadStreet>
            <FORM15CB:Country>{72}</FORM15CB:Country>
        </FORM15CB:AcctntAddrs>
        <FORM15CB:MembershipNumber>{74}</FORM15CB:MembershipNumber>
        <FORM15CB:RegNoAcctnt>{75}</FORM15CB:RegNoAcctnt>
    </FORM15CB:AcctntDetls>
</FORM15CB:FORM15CB>'''.format(*row)

          # remove blank values(pattern) line
          st = re.sub(".*######.*\n?","",st)

          # write file to folder
          filename = folder + '/' + 'file_' + str(counter) + '.xml'
          with open(filename, "w") as f:
            f.write(st)

          # print(st)
          counter = counter + 1
    if form_type == "15CAD":
        for row in li[1:]:
          st = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
          <ns5:FORM15CA xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:Form="http://incometaxindiaefiling.gov.in/common" xmlns:FORM15CA="http://incometaxindiaefiling.gov.in/FORM15CA" xmlns:FORM15CB="http://incometaxindiaefiling.gov.in/FORM15CB" xmlns:ns5="http://incometaxindiaefiling.gov.in/FORM15CAB">
              <Form:CreationInfo>
                  <Form:SWVersionNo>1.0</Form:SWVersionNo>
                  <Form:SWCreatedBy>ITD_JAVA_UTILITY</Form:SWCreatedBy>
                  <Form:XMLCreatedBy>ITD_JAVA_UTILITY</Form:XMLCreatedBy>
                  <Form:XMLCreationDate>2023-01-13</Form:XMLCreationDate>
                  <Form:IntermediaryCity>Delhi</Form:IntermediaryCity>
              </Form:CreationInfo>
              <Form:Form_Details>
                  <Form:FormName>FORM15CA</Form:FormName>
                  <Form:Description>FORM15CA</Form:Description>
                  <Form:AssessmentYear>2017</Form:AssessmentYear>
                  <Form:SchemaVer>Ver1.0</Form:SchemaVer>
                  <Form:FormVer>1.1</Form:FormVer>
              </Form:Form_Details>
              <ns5:PartType>PD</ns5:PartType>
              <ns5:RemitterDetls>
                  <ns5:NameRemitter>{1}</ns5:NameRemitter>
                  <ns5:PAN>{2}</ns5:PAN>
                  <ns5:Tan>{3}</ns5:Tan>
                  <ns5:RemitterAddrs>
                      <ns5:PremisesBuildingVillage>{5}</ns5:PremisesBuildingVillage>
                      <ns5:TownCityDistrict>{8}</ns5:TownCityDistrict>
                      <ns5:FlatDoorBuilding>{4}</ns5:FlatDoorBuilding>
                      <ns5:AreaLocality>{7}</ns5:AreaLocality>
                      <ns5:Pincode>{11}</ns5:Pincode>
                      <Form:State>{9}</Form:State>
                      <ns5:RoadStreet>{6}</ns5:RoadStreet>
                      <ns5:Country>{24}</ns5:Country>
                  </ns5:RemitterAddrs>
                  <ns5:EmailRemitter>{12}</ns5:EmailRemitter>
                  <ns5:PhoneRemitter>{13}</ns5:PhoneRemitter>
                  <ns5:Status>{14}</ns5:Status>
                  <ns5:DomesticFlg>{15}</ns5:DomesticFlg>
              </ns5:RemitterDetls>
              <ns5:RemitteeDetls>
                  <ns5:NameRemittee>{16}</ns5:NameRemittee>
                  <ns5:PanRemittee>{17}</ns5:PanRemittee>
                  <ns5:RemitteeAddrs>
                      <ns5:PremisesBuildingVillage>{19}</ns5:PremisesBuildingVillage>
                      <ns5:TownCityDistrict>{22}</ns5:TownCityDistrict>
                      <ns5:FlatDoorBuilding>{18}</ns5:FlatDoorBuilding>
                      <ns5:AreaLocality>{21}</ns5:AreaLocality>
                      <ns5:ZipCode>{25}</ns5:ZipCode>
                      <Form:State>{23}</Form:State>
                      <ns5:RoadStreet>{20}</ns5:RoadStreet>
                      <ns5:Country>{24}</ns5:Country>
                  </ns5:RemitteeAddrs>
                  <ns5:EmailRemittee>{26}</ns5:EmailRemittee>
                  <ns5:PhoneRemittee>{27}</ns5:PhoneRemittee>
              </ns5:RemitteeDetls>
              <ns5:RemittanceDetls>
                  <ns5:NameBankCode>{35}</ns5:NameBankCode>
                  <ns5:NameBankDesc>{36}</ns5:NameBankDesc>
                  <ns5:BranchName>{37}</ns5:BranchName>
                  <ns5:PropDateRem>{39}</ns5:PropDateRem>
                  <ns5:NatureRemCategory>{40}</ns5:NatureRemCategory>
                  <ns5:NatureRemCode>{43}</ns5:NatureRemCode>
                  <ns5:BsrCode>{38}</ns5:BsrCode>
                  <ns5:CountryRemMadeSecb>{28}</ns5:CountryRemMadeSecb>
                  <ns5:CountryRemMadeSecbDesc>{29}</ns5:CountryRemMadeSecbDesc>
                  <ns5:CurrencySecbCode>{30}</ns5:CurrencySecbCode>
                  <ns5:CurrencySecbDesc>{31}</ns5:CurrencySecbDesc>
                  <ns5:AmtPayForgnRem>{33}</ns5:AmtPayForgnRem>
                  <ns5:AmtPayIndRem>{34}</ns5:AmtPayIndRem>
                  <ns5:RevPurCategory>{42}</ns5:RevPurCategory>
                  <ns5:RevPurCode>{43}</ns5:RevPurCode>
                  <ns5:CountryRemMadeRecipient>{32}</ns5:CountryRemMadeRecipient>
              </ns5:RemittanceDetls>
              <ns5:Declaration>
                  <ns5:LandlordName>{45}</ns5:LandlordName>
                  <ns5:StyledName>{46}</ns5:StyledName>
                  <ns5:I_We>{44}</ns5:I_We>
                  <ns5:VerificationDate>{49}</ns5:VerificationDate>
                  <ns5:VerDesignation>{47}</ns5:VerDesignation>
                  <ns5:VerificationPlace>{48}</ns5:VerificationPlace>
              </ns5:Declaration>
          </ns5:FORM15CA>
'''.format(*row)

          # remove blank values(pattern) line
          st = re.sub(".*######.*\n?","",st)

          # write file to folder
          filename = folder + '/' + 'file_' + str(counter) + '.xml'
          with open(filename, "w") as f:
            f.write(st)

          # print(st)
          counter = counter + 1
    if form_type == "15CAC":
        for row in li[1:]:
          st = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ns5:FORM15CA xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:Form="http://incometaxindiaefiling.gov.in/common" xmlns:FORM15CA="http://incometaxindiaefiling.gov.in/FORM15CA" xmlns:FORM15CB="http://incometaxindiaefiling.gov.in/FORM15CB" xmlns:ns5="http://incometaxindiaefiling.gov.in/FORM15CAB">
    <Form:CreationInfo>
        <Form:SWVersionNo>1.0</Form:SWVersionNo>
        <Form:SWCreatedBy>ITD_JAVA_UTILITY</Form:SWCreatedBy>
        <Form:XMLCreatedBy>ITD_JAVA_UTILITY</Form:XMLCreatedBy>
        <Form:XMLCreationDate>2022-12-05</Form:XMLCreationDate>
        <Form:IntermediaryCity>Delhi</Form:IntermediaryCity>
    </Form:CreationInfo>
    <Form:Form_Details>
        <Form:FormName>FORM15CA</Form:FormName>
        <Form:Description>FORM15CA</Form:Description>
        <Form:AssessmentYear>2017</Form:AssessmentYear>
        <Form:SchemaVer>Ver1.0</Form:SchemaVer>
        <Form:FormVer>1.1</Form:FormVer>
    </Form:Form_Details>
    <ns5:PartType>PC</ns5:PartType>
    <ns5:RemitterDetls>
        <ns5:NameRemitter>{44}</ns5:NameRemitter>
        <ns5:PAN>{45}</ns5:PAN>
        <ns5:Tan>{3}</ns5:Tan>
        <ns5:RemitterAddrs>
            <ns5:PremisesBuildingVillage>{10}</ns5:PremisesBuildingVillage>
            <ns5:TownCityDistrict>{13}</ns5:TownCityDistrict>
            <ns5:FlatDoorBuilding>{9}</ns5:FlatDoorBuilding>
            <ns5:AreaLocality>{12}</ns5:AreaLocality>
            <ns5:Pincode>{16}</ns5:Pincode>
            <Form:State>{14}</Form:State>
            <ns5:RoadStreet>{11}</ns5:RoadStreet>
            <ns5:Country>{15}</ns5:Country>
        </ns5:RemitterAddrs>
        <ns5:EmailRemitter>{17}</ns5:EmailRemitter>
        <ns5:PhoneRemitter>{18}</ns5:PhoneRemitter>
        <ns5:Status>{19}</ns5:Status>
        <ns5:PrincPlcBusRemter>{23}</ns5:PrincPlcBusRemter>
        <ns5:DomesticFlg>{20}</ns5:DomesticFlg>
        <ns5:AreaCode>{4}</ns5:AreaCode>
        <ns5:AoType>{5}</ns5:AoType>
        <ns5:RangeCode>{6}</ns5:RangeCode>
        <ns5:AoNumber>{7}</ns5:AoNumber>
    </ns5:RemitterDetls>
    <ns5:RemitteeDetls>
        <ns5:NameRemittee>{47}</ns5:NameRemittee>
        <ns5:PanRemittee>{21}</ns5:PanRemittee>
        <ns5:StatusRemittee>{22}</ns5:StatusRemittee>
        <ns5:RemitteeAddrs>
            <ns5:PremisesBuildingVillage>{49}</ns5:PremisesBuildingVillage>
            <ns5:TownCityDistrict>{52}</ns5:TownCityDistrict>
            <ns5:FlatDoorBuilding>{48}</ns5:FlatDoorBuilding>
            <ns5:AreaLocality>{51}</ns5:AreaLocality>
            <ns5:ZipCode>{55}</ns5:ZipCode>
            <Form:State>{53}</Form:State>
            <ns5:RoadStreet>{50}</ns5:RoadStreet>
            <ns5:Country>{54}</ns5:Country>
        </ns5:RemitteeAddrs>
        <ns5:EmailRemittee>{24}</ns5:EmailRemittee>
        <ns5:PhoneRemittee>{25}</ns5:PhoneRemittee>
        <ns5:PrincPlcBusRemtee>{23}</ns5:PrincPlcBusRemtee>
    </ns5:RemitteeDetls>
    <ns5:RemittanceDetls>
        <ns5:NameBankCode>{62}</ns5:NameBankCode>
        <ns5:NameBankDesc>{63}</ns5:NameBankDesc>
        <ns5:BranchName>{64}</ns5:BranchName>
        <ns5:PropDateRem>{66}</ns5:PropDateRem>
        <ns5:NatureRemCategory>{67}</ns5:NatureRemCategory>
        <ns5:NatureRemCode>{68}</ns5:NatureRemCode>
        <ns5:BsrCode>{65}</ns5:BsrCode>
        <ns5:CountryRemMadeSecb>{56}</ns5:CountryRemMadeSecb>
        <ns5:CountryRemMadeSecbDesc>{57}</ns5:CountryRemMadeSecbDesc>
        <ns5:CurrencySecbCode>{58}</ns5:CurrencySecbCode>
        <ns5:CurrencySecbDesc>{59}</ns5:CurrencySecbDesc>
        <ns5:AmtPayForgnRem>{60}</ns5:AmtPayForgnRem>
        <ns5:AmtPayIndRem>{61}</ns5:AmtPayIndRem>
        <ns5:TaxPayGrossSecb>{71}</ns5:TaxPayGrossSecb>
        <ns5:RevPurCategory>{69}</ns5:RevPurCategory>
        <ns5:RevPurCode>{70}</ns5:RevPurCode>
    </ns5:RemittanceDetls>
    <ns5:AcctntDetls>
        <ns5:NameAcctnt>{105}</ns5:NameAcctnt>
        <ns5:NameFirmAcctnt>{106}</ns5:NameFirmAcctnt>
        <ns5:AcctntAddrs>
            <ns5:PremisesBuildingVillage>108</ns5:PremisesBuildingVillage>
            <ns5:TownCityDistrict>{111}</ns5:TownCityDistrict>
            <ns5:FlatDoorBuilding>{107}</ns5:FlatDoorBuilding>
            <ns5:AreaLocality>{110}</ns5:AreaLocality>
            <ns5:Pincode>{114}</ns5:Pincode>
            <Form:State>{112}</Form:State>
            <ns5:RoadStreet>{109}</ns5:RoadStreet>
            <ns5:Country>{113}</ns5:Country>
        </ns5:AcctntAddrs>
        <ns5:MembershipNumber>{115}</ns5:MembershipNumber>
        <ns5:CertDate>{26}</ns5:CertDate>
        <ns5:CertNumber>{27}</ns5:CertNumber>
    </ns5:AcctntDetls>
    <ns5:AoOrderDetls>
        <ns5:OrderAoFlg>{28}</ns5:OrderAoFlg>
        <ns5:CertSection>{29}</ns5:CertSection>
        <ns5:NameAo>{30}</ns5:NameAo>
        <ns5:DesgAo>{31}</ns5:DesgAo>
        <ns5:OrderDateAo>{32}</ns5:OrderDateAo>
        <ns5:OrderNumAo>{33}</ns5:OrderNumAo>
    </ns5:AoOrderDetls>
    <ns5:ItActDetails>
        <ns5:ReasonNot>{73}</ns5:ReasonNot>
        <ns5:SecRemCovered>{74}</ns5:SecRemCovered>
        <ns5:AmtIncChrgIt>{75}</ns5:AmtIncChrgIt>
        <ns5:TaxLiablIt>{76}</ns5:TaxLiablIt>
        <ns5:BasisDeterTax>{77}</ns5:BasisDeterTax>
    </ns5:ItActDetails>
    <ns5:DTAADetails>
        <ns5:TaxResidCert>{78}</ns5:TaxResidCert>
        <ns5:RelevantDtaa>{79}</ns5:RelevantDtaa>
        <ns5:RelevantArtDtaa>{80}</ns5:RelevantArtDtaa>
        <ns5:TaxIncDtaa>{81}</ns5:TaxIncDtaa>
        <ns5:TaxLiablDtaa>{82}</ns5:TaxLiablDtaa>
        <ns5:RemForRoyFlg>{83}</ns5:RemForRoyFlg>
        <ns5:ArtDtaa>{84}</ns5:ArtDtaa>
        <ns5:RateTdsADtaa>{85}</ns5:RateTdsADtaa>
        <ns5:RemAcctBusIncFlg>{86}</ns5:RemAcctBusIncFlg>
        <ns5:IncLiabIndiaFlg>{87}</ns5:IncLiabIndiaFlg>
        <ns5:AmtToTaxInd>{88}</ns5:AmtToTaxInd>
        <ns5:ReasonofReleventArtDtaa>{89}</ns5:ReasonofReleventArtDtaa>
        <ns5:RemOnCapGainFlg>{90}</ns5:RemOnCapGainFlg>
        <ns5:AmtLongTrm>{91}</ns5:AmtLongTrm>
        <ns5:AmtShortTrm>{92}</ns5:AmtShortTrm>
        <ns5:BasisTaxIncDtaa>{93}</ns5:BasisTaxIncDtaa>
        <ns5:OtherRemDtaa>{94}</ns5:OtherRemDtaa>
        <ns5:NatureRemDtaa>{95}</ns5:NatureRemDtaa>
        <ns5:TaxIndDtaaFlg>{96}</ns5:TaxIndDtaaFlg>
        <ns5:RateTdsDDtaa>{97}</ns5:RateTdsDDtaa>
        <ns5:RelArtDetlDDtaa>{98}</ns5:RelArtDetlDDtaa>
    </ns5:DTAADetails>
    <ns5:TDSDetails>
        <ns5:AmtPayForgnTds>{99}</ns5:AmtPayForgnTds>
        <ns5:AmtPayIndianTds>{100}</ns5:AmtPayIndianTds>
        <ns5:RateTdsSecbFlg>{101}</ns5:RateTdsSecbFlg>
        <ns5:RateTdsSecB>{102}</ns5:RateTdsSecB>
        <ns5:ActlAmtTdsForgn>{103}</ns5:ActlAmtTdsForgn>
        <ns5:DednDateTds>{104}</ns5:DednDateTds>
    </ns5:TDSDetails>
    <ns5:Declaration>
        <ns5:LandlordName>{37}</ns5:LandlordName>
        <ns5:StyledName>{36}</ns5:StyledName>
        <ns5:I_We>{35}</ns5:I_We>
        <ns5:VerificationDate>{39}</ns5:VerificationDate>
        <ns5:VerDesignation>{38}</ns5:VerDesignation>
        <ns5:VerificationPlace>{40}</ns5:VerificationPlace>
    </ns5:Declaration>
</ns5:FORM15CA>'''.format(*row)

          # remove blank values(pattern) line
          st = re.sub(".*######.*\n?","",st)

          # write file to folder
          filename = folder + '/' + 'file_' + str(counter) + '.xml'
          with open(filename, "w") as f:
            f.write(st)

          # print(st)
          counter = counter + 1

    # create zip folder
    shutil.make_archive(folder, 'zip', folder)
    return folder+'.zip'
