
document.addEventListener("DOMContentLoaded", function() {
  document.getElementById('formList').addEventListener("change", function() {
    const formValue = document.getElementById('formList').value;
    if (formValue === '15CAC') {
      document.getElementById("submit1").style.display = 'none';
      document.getElementById("upload2").style.display = '';
      document.getElementById("bottom-div").style.justifyContent = 'space-between';
      document.getElementById("submit2").style.display = '';
      document.getElementById("upload1").style.backgroundColor = "#6c757d";
    } else {
      var dropdownValue = document.getElementById("formList").value;
      localStorage.setItem("dropdownValue", dropdownValue);
      location.reload();
    }
  });
});

window.onload = function() {
  var storedValue = localStorage.getItem("dropdownValue");
  if (storedValue) {
    document.getElementById("formList").value = storedValue;
  }
};
document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("upload1").addEventListener("click", function() {
    // alert("button has been clicked");
    buttonColor1 = document.getElementById('upload1').style.backgroundColor;
    if(buttonColor1=="rgb(13, 110, 253)" ||buttonColor1=="" ){
    document.getElementById("file-input1").click();
  }else{
    alert("First Upload 15CB");
    console.log(buttonColor1,"this");
  }
  });
});
document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("upload2").addEventListener("click", function() {
    // alert("button has been clicked");
    document.getElementById("file-input2").click();
  });
});
document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("file-input1").addEventListener("change", function() {
    // alert("button has been clicked");
    document.getElementById("submit1").style.backgroundColor = "#0d6efd";
    document.getElementById("submit2").style.backgroundColor = "#0d6efd";
  });
});
document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("file-input2").addEventListener("change", function() {
    // alert("button has been clicked");
    document.getElementById("upload1").style.backgroundColor = "#0d6efd";
  });
});
document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("submit1").addEventListener("click", function() {
    // alert("button has been clicked");
    buttonColor = document.getElementById("submit1").style.backgroundColor;
    if(buttonColor=="rgb(13, 110, 253)"){
    const fileInput = document.getElementById("file-input1");
    const formListValue = document.getElementById("formList").value;
    let csvFile = fileInput.files[0];
    const fileType = csvFile.name.split('.')[1];
    if(fileType=='csv'||fileType=='xlsx'||fileType=='xls'){
    const formData = new FormData();
    formData.append('file', csvFile);
    formData.append('formValue',formListValue);
    document.getElementById('loading-icon').style.display = '';
    document.getElementById('submit-icon').style.display = 'none';
    document.getElementById('loader').style.display = '';
    fetch('/csv', {
    method: 'POST',
    body: formData
}).then(response => {
  document.getElementById('loading-icon').style.display = 'none';
  document.getElementById('loader').style.display = 'none';
  document.getElementById('submit-icon').style.display = '';
  document.getElementById('file-input1').value = '';
  document.getElementById('submit1').style.backgroundColor = '#6c757d';
    if (response.ok) {
      alert("file uploaded successfully!")
    const file_name = response.headers.get('filename');
    console.log('filename: ', file_name);
    if (!file_name) {
      throw new Error('Filename not found in response headers');
    }
    // Delete the file
  fetch('/delete_file', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ file_name })
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to delete file');
      }
      console.log(`File '${file_name}' has been deleted.`);
    })
    .catch(error => console.error(error));
      fileData = response.blob();
      document.getElementById("download1").style.backgroundColor = "#0d6efd";
      document.getElementById('error-log').innerHTML = '<span style="color:green;">File successfully validated, click download button to save the file.<span>'
        return response.json();
    }else if(response.status==422){
      alert("there are errors in the file.");
      return response.json();
    }else if(response.status==400){
      document.getElementById('error-log').innerHTML = '<span style="color:red;">Validation Failed, Either all the columns are not present or order of columns is wrong (or may be you choose the wrong file type from dropdown).<span>'
    }else {
        console.log(`Error: ${response.status} ${response.statusText}`);
    }
}).then(data => {
  document.getElementById('loading-icon').style.display = 'none';
  document.getElementById('loader').style.display = 'none';
  document.getElementById('submit-icon').style.display = '';
    const errors = data.errors;
    var errorHtml = ""
    for (const key in errors) {
      const arr = errors[key];
      for (const error of arr){
        for (const column in error) {
  (function(col) {
    errorHtml = errorHtml + 'in Line ' + '<span style="color:red;">' + key + '</span>' + ' : ' + error[col] + ' ' + '<i class="fa fa-clone" aria-hidden="true" onclick="actualFunction(\'' + col + '\', this);" style="cursor: pointer"></i>' + '<br>'
  })(column);
}

    }
    }
    document.getElementById('error-log').innerHTML = errorHtml;
}).catch(error => {
    console.log(error);
});
}else{
  alert("Uploaded File should be either of '.csv', '.xls' or '.xlsx' Type");
}
}else{
  alert('Please upload the CSV file first');
}

  });
});

document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("submit2").addEventListener("click", function() {
    // alert("button has been clicked");
    buttonColor = document.getElementById("submit1").style.backgroundColor;
    if(buttonColor=="rgb(13, 110, 253)"){
    const fileInput = document.getElementById("file-input1");
    const fileInput2 = document.getElementById("file-input2");
    const formListValue = document.getElementById("formList").value;
    let csvFile = fileInput.files[0];
    let csvFile2 = fileInput2.files[0];
    const formData = new FormData();
    formData.append('15CAC', csvFile);
    formData.append('15CB',csvFile2);
    formData.append('formValue',formListValue);
    document.getElementById('loading-icon1').style.display = '';
    document.getElementById('loader').style.display = '';
    document.getElementById('submit-icon1').style.display = 'none';
    fetch('/csv', {
    method: 'POST',
    body: formData
}).then(response => {
    if (response.ok) {
      document.getElementById('loading-icon1').style.display = 'none';
      document.getElementById('loader').style.display = 'none';
      document.getElementById('submit-icon1').style.display = '';
      document.getElementById('file-input1').value = '';
      document.getElementById('submit2').style.backgroundColor = '#6c757d';
      alert("file uploaded successfully!")
      const file_name = response.headers.get('filename');
      console.log('filename: ', file_name);
      if (!file_name) {
        throw new Error('Filename not found in response headers');
      }
      // Delete the file
    fetch('/delete_file', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ file_name })
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to delete file');
        }
        console.log(`File '${file_name}' has been deleted.`);
      })
      .catch(error => console.error(error));
      fileData = response.blob();
      document.getElementById("download1").style.backgroundColor = "#0d6efd";
      document.getElementById('error-log').innerHTML = '<span style="color:green;">File successfully validated, click download button to save the file.<span>'
        return response.json();
    }else if(response.status==422){
      alert("there are errors in the file.");
      return response.json();
    }else if(response.status==400){
      document.getElementById('error-log').innerHTML = '<span style="color:red;">Validation Failed, Either all the columns are not present or order of columns is wrong (or may be you choose the wrong file type from dropdown).<span>'
    }else {
        console.log(`Error: ${response.status} ${response.statusText}`);
    }
}).then(data => {
  document.getElementById('loading-icon1').style.display = 'none';
  document.getElementById('loader').style.display = 'none';
  document.getElementById('submit-icon1').style.display = '';
    const errors = data.errors;
    const message = data.message;
    var errorHtml = ""
    errorHtml = '<strong>'+message+'</strong>'+'<br>';
    for (const key in errors) {
      const arr = errors[key];
      for (const error of arr){
        for (const column in error) {
  (function(col) {
    errorHtml = errorHtml + 'in Line ' + '<span style="color:red;">' + key + '</span>' + ' : ' + error[col] + ' ' + '<i class="fa fa-clone" aria-hidden="true" onclick="actualFunction(\'' + col + '\', this);" style="cursor: pointer"></i>' + '<br>'
  })(column);
}

    }
    }
    document.getElementById('error-log').innerHTML = errorHtml;
}).catch(error => {
    console.log(error);
});
}else{
  alert('Please upload the CSV file first');
}

  });
});
function actualFunction(param1, icon) {
  var dummy = document.createElement("textarea");
  document.body.appendChild(dummy);
  dummy.value = param1;
  dummy.select();
  document.execCommand("copy");
  document.body.removeChild(dummy);

  icon.style.color = "blue";
  setTimeout(() => {
    icon.style.color = "";
  }, 500);
}
document.addEventListener("DOMContentLoaded", function() {
document.getElementById('download1').addEventListener('click', function() {
  buttonColorDownload = document.getElementById("download1").style.backgroundColor;
  if(buttonColorDownload=="rgb(13, 110, 253)"){
    fileData.then(blob => {
        // create a new Blob object with the file data
        const file = new Blob([blob], { type: 'application/zip' });
        // create a link element to simulate a download
        const a = document.createElement('a');
        a.href = window.URL.createObjectURL(file);
        a.download = 'example.zip';
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
    });
  }else{
    alert("First upload and validate CSV file.")
  }
});
});
function openNav() {
  console.log('opening');
  var sidenav = document.getElementById("mySidenav");
  var main = document.getElementById("main");
  sidenav.style.width = "250px";
  main.style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  var sidenav = document.getElementById("mySidenav");
  var main = document.getElementById("main");
  sidenav.style.width = "0";
  main.style.marginLeft = "0";
  document.body.style.backgroundColor = "rgb(234, 231, 228)";
}

// script to toggle dropdown menu on click
let dropdown = document.querySelectorAll('.dropdown');
dropdown.forEach(element => {
  element.addEventListener('click', () => {
    let content = element.querySelector('.dropdown-content');
    content.classList.toggle("show");
  });
});
