# import xml.etree.ElementTree as ET
import os

def inplace_change(filename, old_string, new_string):
    # Safely read the input filename using 'with'
    with open(filename) as f:
        s = f.read()
        if old_string not in s:
            print('"{old_string}" not found in {filename}.'.format(**locals()))
            return

    # Safely write the changed content, if found in the file
    with open(filename, 'w') as f:
        print('Changing "{old_string}" to "{new_string}" in {filename}'.format(**locals()))
        s = s.replace(old_string, new_string)
        f.write(s)


def double_spaces(line):
    spaces = 0
    for char in line:
        if char == ' ':
            spaces = spaces + 1
        else:
            break
    line = ' ' * spaces + line 
    return line


for file in os.listdir(r'old'):
    print(file)
    inplace_change('old/'+file,'<Form:SWVersionNo>1</Form:SWVersionNo>','<Form:SWVersionNo>1.0</Form:SWVersionNo>')

    # Find Sequence 
    sequence = ['NameBankCode','NameBankDesc','BranchName','PropDateRem','NatureRemCategory','BsrCode','CountryRemMadeSecb','CurrencySecbCode','AmtPayForgnRem','AmtPayIndRem','TaxPayGrossSecb','RevPurCategory','RevPurCode']
    store_sequence = []
    for tag in sequence:
        with open('old/'+file) as f:
            for line in f:
                if tag in line:
                    # print(line)
                    store_sequence.append(line)
            
    # Correct Sequence
    counter = -1
    with open('old/'+file) as f:
        with open('intermediate/'+file, "w") as f1:
            for line in f:
                if '<ns5:RemittanceDetls>' in line:
                    counter = 0
                    # print(line)
                    f1.write(line)
                    # print('open')
                elif '</ns5:RemittanceDetls>' in line:
                    counter = -1
                    f1.write(line)
                    # print('close')
                elif counter != -1:
                    # print(counter)
                    # print(store_sequence[counter])
                    f1.write(store_sequence[counter])
                    counter = counter + 1
                    # print('sequence')
                else:
                    f1.write(line)
                    # print('nornal')

    # Add extra spaces
    with open('intermediate/'+file) as f:
        with open('new/'+file, "w") as f1:
            for line in f:
                line = double_spaces(line)
                f1.write(line)