from flask import Flask, request, jsonify, render_template,Response
import os,io
import json
from flask import Flask, render_template
from flask import Flask,render_template, flash, redirect , url_for , session ,request, logging
from datetime import date,datetime
import pytz
from wtforms import Form, StringField , TextAreaField ,PasswordField , validators
from functools import wraps
from flask import send_file

from werkzeug.utils import secure_filename
import os
import zipfile
# import zipfile as ZipFile
from zipfile import ZipFile 
from flask import Flask, request, redirect, url_for, flash, render_template
from datetime import datetime
import shutil
import time
from threading import Thread 

app = Flask(__name__)

UPLOAD_FOLDER = os.path.dirname(os.path.realpath(__file__))
ALLOWED_EXTENSIONS = set(['zip'])

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET','POST'])
def upload_file():
    
    if request.method == 'POST':
        
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit a empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            # print('---------aa-------')
            filename = secure_filename(file.filename)

            now = datetime.now()
            date_time = now.strftime("%m_%d_%Y_%H_%M_%S")

            folder_name = filename.split('.zip')[0]+'_'+date_time
            # print('folder_name',folder_name)

            temp_UPLOAD_FOLDER = os.path.join(UPLOAD_FOLDER,folder_name)
            # print('temp_UPLOAD_FOLDER',temp_UPLOAD_FOLDER)

            
            print('---------temp_UPLOAD_FOLDER----------')
            print(temp_UPLOAD_FOLDER)
            try:
                os.mkdir(temp_UPLOAD_FOLDER)
            except Exception as e: 
                print(e)
                print('File exists')

            # print(temp_UPLOAD_FOLDER)
            file.save(os.path.join(temp_UPLOAD_FOLDER, filename))
            zip_ref = zipfile.ZipFile(os.path.join(temp_UPLOAD_FOLDER, filename), 'r')
            zip_ref.extractall(temp_UPLOAD_FOLDER)
            zip_ref.close()


            # print(temp_UPLOAD_FOLDER.split('\\'))
            zip_file = convert(temp_UPLOAD_FOLDER.split('\\')[-1],filename.split('.zip')[0])
            print(zip_file)


            # background_remove(temp_UPLOAD_FOLDER)
            my_thread = Thread(target=background_remove, args=[temp_UPLOAD_FOLDER])
            my_thread.start()

            return send_file(zip_file, as_attachment=True)


            # return redirect(url_for('upload_file',filename=filename))
    # return send_file(zip_file, as_attachment=True)
    return render_template('accounts/register.html')


def background_remove(path):
    time.sleep(10)
    shutil.rmtree(path)
    return '200'

def inplace_change(filename, old_string, new_string):
    # Safely read the input filename using 'with'
    with open(filename) as f:
        s = f.read()
        if old_string not in s:
            # print('"{old_string}" not found in {filename}.'.format(**locals()))
            return

    # Safely write the changed content, if found in the file
    with open(filename, 'w') as f:
        # print('Changing "{old_string}" to "{new_string}" in {filename}'.format(**locals()))
        s = s.replace(old_string, new_string)
        f.write(s)


def double_spaces(line):
    spaces = 0
    for char in line:
        if char == ' ':
            spaces = spaces + 1
        else:
            break
    line = ' ' * spaces + line 
    return line

def make_archive(source, destination):
    base = os.path.basename(destination)
    name = base.split('.')[0]
    format = base.split('.')[1]
    archive_from = os.path.dirname(source)
    archive_to = os.path.basename(source.strip(os.sep))
    print(source, destination, archive_from, archive_to)
    shutil.make_archive(name, format, archive_from, archive_to)
    shutil.move('%s.%s'%(name,format), destination)

def convert(parent_folder_name,folder_name):
    file_path = parent_folder_name
    dirname = os.path.dirname(__file__)
    file_path = os.path.join(dirname, file_path)
    file_path = file_path.replace(os.sep, '/')
    # print(file_path)


    unziped_folder_path = file_path
    old_folder_path = unziped_folder_path+'/'
    intermediate_folder_path = file_path+'/intermediate/'
    new_folder_path = file_path+'/new/'

    intermediate_folder_path = intermediate_folder_path.replace(os.sep, '/')
    new_folder_path = new_folder_path.replace(os.sep, '/')

    print('---------intermediate_folder_path---------')
    print(intermediate_folder_path)
    print('---------new_folder_path---------')
    print(new_folder_path)


    try:
        os.mkdir(intermediate_folder_path)
        os.mkdir(new_folder_path)
    except Exception as e: 
        print(e)
        print('File exists')
            

    for file in os.listdir(file_path+'//'):
        # print(file)
        if file.endswith(".xml"):
            # print(file)
            temp = old_folder_path+file
            # print('##########')
            # print(temp)
            inplace_change(temp,'<Form:SWVersionNo>1</Form:SWVersionNo>','<Form:SWVersionNo>1.0</Form:SWVersionNo>')

            # Find Sequence 
            sequence = ['NameBankCode','NameBankDesc','BranchName','PropDateRem','NatureRemCategory','BsrCode','CountryRemMadeSecb','CurrencySecbCode','AmtPayForgnRem','AmtPayIndRem','TaxPayGrossSecb','RevPurCategory','RevPurCode']
            store_sequence = []
            for tag in sequence:
                with open(temp) as f:
                    for line in f:
                        if tag in line:
                            store_sequence.append(line)
                
                        
            # Correct Sequence
            counter = -1
            with open(old_folder_path+file) as f:
                with open(intermediate_folder_path+file, "w") as f1:
                    for line in f:
                        if '<ns5:RemittanceDetls>' in line:
                            counter = 0
                            # print(line)
                            f1.write(line)
                            # print('open')
                        elif '</ns5:RemittanceDetls>' in line:
                            counter = -1
                            f1.write(line)
                            # print('close')
                        elif counter != -1:
                            # print(counter)
                            # print(store_sequence[counter])
                            f1.write(store_sequence[counter])
                            counter = counter + 1
                            # print('sequence')
                        else:
                            f1.write(line)
                            # print('nornal')

            # Add extra spaces
            # print('adding spaces')
            with open(intermediate_folder_path+file) as f:
                with open(new_folder_path+file, "w") as f1:
                    for line in f:
                        line = double_spaces(line)
                        f1.write(line)

    make_archive(new_folder_path[:-1], old_folder_path+folder_name+'_new.zip')
    
    return old_folder_path+folder_name+'_new.zip'
    




if __name__ == "__main__":
    app.secret_key='secret123'
    app.run(debug=False)
