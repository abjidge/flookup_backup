from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path("structure/c_corp/", views.c_corp, name = "c_corp"),
    path("structure/llp/", views.llp, name = "llp"),
    path("structure/trust/", views.trust, name = "trust"),
    path('company_details', views.company_details, name='company_details'),
    path('address_details', views.address_details, name='address_details'),
    path('shareholder_details', views.shareholder_details, name='shareholder_details'),
    path('director_details', views.director_details, name='director_details'),
    path('update_director', views.update_director, name='update_director'),
    path('update_founder', views.update_founder, name='update_founder'),
    path('update_share', views.update_share, name='update_share'),
    path('create_profile', views.create_profile, name='create_profile'),
    path('comments/<str:id>/', views.user_comment, name='comments'),
    path('partner_details', views.partner_details, name='partner_details'),
    path('company_documents', views.company_documents, name='company_documents'),
    path("open_files", views.open_files, name = "open_files"),
    path("delete_files", views.delete_files, name = "delete_files"),
    path("trust_details", views.trust_details, name ="trust_details"),
    path("nature_updation", views.nature_updation, name ="nature_updation"),
    path("prog_level", views.prog_level, name ="prog_level"),
    path("delete_company/<str:id>", views.delete_company, name = "delete_company"),
    path("delete_property_owner", views.delete_property_owner, name = "delete_property_owner"),
    path("nature_of_trust", views.nature_of_trust, name = "nature_of_trust"),
    path("token_amount/", views.token_amount, name = "token_amount"),
    path("change_token_amount", views.change_token_amount, name = "change_token_amount"),
    path("pay_due_amount/<str:id>", views.pay_due_amount, name = "pay_due_amount"),
    path("transaction_success", views.transaction_success, name = "transaction_success"),
    path("delete_files_document", views.delete_files_document, name = "delete_files_document"),
    
]