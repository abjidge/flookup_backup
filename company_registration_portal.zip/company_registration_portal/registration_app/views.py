from locale import currency
from django.shortcuts import render, redirect,  HttpResponse
from .models import *
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import datetime
import razorpay
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.utils.dateparse import parse_date
import boto3
import time
from pprint import pprint
import uuid
from urllib.parse import urlencode
from dashboard.views import create_new_form
import sib_api_v3_sdk
from sib_api_v3_sdk.rest import ApiException

key = "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"

# Configure API key authorization: api-key
configuration = sib_api_v3_sdk.Configuration()
configuration.api_key['api-key'] = key

# create an instance of the API class
api_instance = sib_api_v3_sdk.TransactionalEmailsApi(sib_api_v3_sdk.ApiClient(configuration))

def send_email(to, template_id, params):
    # reference
    # to = [{"email":"ab1jidge@gmail.com","name":"John Doe"}]
    # template_id=1
    # params={"Name":"sadsa"}
    send_smtp_email = sib_api_v3_sdk.SendSmtpEmail(to=to, template_id=template_id, params=params, headers={"X-Mailin-custom": "custom_header_1:custom_value_1|custom_header_2:custom_value_2|custom_header_3:custom_value_3", "charset": "iso-8859-1"})
    try:
        # Send a transactional email
        api_response = api_instance.send_transac_email(send_smtp_email)
        pprint(api_response)
    except ApiException as e:
        print("Exception when calling SMTPApi->send_transac_email: %s\n" % e)

client = razorpay.Client(auth=(settings.RAZOR_KEY_ID, settings.RAZOR_KEY_SECRET))

s3_client = boto3.client("s3",
                         region_name='ap-south-1',
                         aws_access_key_id=settings.AWS_S3_ACCESS_KEY_ID,
                         aws_secret_access_key=settings.AWS_S3_SECRET_ACCESS_KEY
                        )

def token_amount_page(func):
    def wrapper(request):
        current_user = request.user
        if current_user.profile.is_admin or current_user.profile.is_employee:
            current_user.profile.total_tokens = 10**6
            current_user.profile.save()
        x = request.GET.get("pk")
        print(x)
        total_token = current_user.profile.total_tokens
        total_forms = User_form_id.objects.filter(user = current_user)
        cnt = 0
        for form in total_forms:
            comp = Company.objects.filter(company_id = form)
            if comp.exists(): cnt += 1
        # if not (x == "1") and (current_user.profile.is_admin or current_user.profile.is_employee or (cnt == total_token and cnt > 0)):
        #     return redirect("/dashboard")
        user_token = User_form_id.objects.filter(form_id = current_user.profile.current_form_id)
        token_amount_paid = "0"
        if user_token.exists():
            user_token = User_form_id.objects.get(form_id = current_user.profile.current_form_id)
            token_amount_paid = user_token.token_amount_paid
            total_token = current_user.profile.total_tokens
            total_forms = User_form_id.objects.filter(user = current_user)
            cnt = 0
            for form in total_forms:
                comp = Company.objects.filter(company_id = form)
                if comp.exists(): cnt += 1
            if cnt < total_token:
                token_amount_paid = "1"
                user_token.token_amount_paid = "1"
                user_token.save()
            print("total tokens count", cnt, total_token, token_amount_paid)
        else:
            print("inside new form")
            val = uuid.uuid4()
            print(str(val))
            user_created = User_form_id(user = request.user, form_id = val)
            request.user.profile.current_form_id = val
            request.user.save()
            user_created.save()
        print(token_amount_paid, current_user, current_user.profile.current_form_id)
        if token_amount_paid == "0":
            query_string = urlencode({'pk': x})
            return redirect("/register/token_amount/?" + query_string)
        return func(request)
    return wrapper

def token_amount(request):
    arr = [0, 1999, 1499, 1499, 4000]
    amt = int(request.GET.get("pk"))
    val = int(arr[amt]*.2)
    DATA = {
    "amount": val*100,
    "currency": "INR",
    "payment_capture": "1",
    }
    payment = client.order.create(data=DATA)
    order_id = payment["id"]
    
    context = {
        "amount": val,
        "api_key": settings.RAZOR_KEY_ID,
        "order_id": order_id,
        "amt":amt
    }
    return render(request, "dashboard/token_page.html", context)

@csrf_exempt
def change_token_amount(request):
    current_user = request.user
    user_token = User_form_id.objects.get(form_id = current_user.profile.current_form_id)
    user_token.token_amount_paid = "1"
    amt = request.POST.get("amt")
    arr = [0, 1999, 1499, 1499, 4000]
    user_token.total_amount = arr[int(amt)]
    user_token.amount_paid = int(request.POST.get("amount"))
    user_token.save()
    current_user.profile.total_tokens += 1
    order_id = request.POST.get("razorpay_order_id")
    payment_id = request.POST.get("razorpay_payment_id")
    signature = request.POST.get("razorpay_signature")

    val = current_user.profile.current_form_id
    Transaction(user_id = current_user, form_id_id = val,  amount = request.POST.get("amount"), order_id = order_id, payment_id = payment_id, signature = signature).save()
    current_user.save()
    return JsonResponse({"message":"saved"}, status = 200)


def pay_due_amount(request, id):
    request.user.profile.current_form_id = id
    request.user.save()
    print(id)
    user_form = User_form_id.objects.get(form_id = id)
    tot_amount = int(user_form.total_amount)
    due = int(user_form.amount_paid)
    DATA = {
    "amount": (tot_amount-due)*100,
    "currency": "INR",
    "payment_capture": "1",
    }
    payment = client.order.create(data=DATA)
    order_id = payment["id"]
    context = {
        "amount": tot_amount-due,
        "api_key": settings.RAZOR_KEY_ID,
        "order_id": order_id
    }

    return render(request, "dashboard/pay_due.html", context)

@csrf_exempt
def transaction_success(request):
    print("asdkhadkajd")
    current_user = request.user
    val = current_user.profile.current_form_id
    print(val)
    if request.method == "POST":
        User_form_id.objects.get(form_id = current_user.profile.current_form_id).token_amount_paid = "1"
        order_id = request.POST.get("razorpay_order_id")
        payment_id = request.POST.get("razorpay_payment_id")
        signature = request.POST.get("razorpay_signature")
        val = current_user.profile.current_form_id
        Transaction(user_id = current_user, form_id_id = val,  amount = request.POST.get("amount"), order_id = order_id, payment_id = payment_id, signature = signature).save()
        current_user.save()
        user_form_ob = User_form_id.objects.get(form_id = val)
        user_form_ob.amount_paid += int(request.POST.get("amount"))
        user_form_ob.save()
        comp_data = Company.objects.get(company_id_id = val)
        comp_data.payment_status = "1"
        comp_data.save()
        print(comp_data.name1,comp_data.payment_status)
        return JsonResponse({"message":"succesful in saving the transaction"}, status = 200)



@login_required(login_url='/accounts/login/')
# @token_amount_page
def index(request) :
    # User_form_id.objects.all().delete()
    print(request.user.email)
    current_user = request.user
    val = current_user.profile.current_form_id
    if val == "0":
        return create_new_form(request)        
    if User_form_id.objects.get(form_id = current_user.profile.current_form_id).token_amount_used == "0":
        User_form_id.objects.get(form_id = current_user.profile.current_form_id).token_amount_used = "1"
        user_form_ob = User_form_id.objects.get(form_id = val)
        # user_form_ob.amount_paid = 
        print("yes this cond was used this time")
        user_form_ob.save()
        request.user.save()

    if request.method == 'POST':
        structure = request.POST["structure"]
        query_string =  urlencode({'pk': structure})
        if structure == "1":
            return redirect("/register/structure/c_corp/?"+query_string)
        elif structure == "2":
            return redirect("/register/structure/llp/?"+query_string)
        else:
            return redirect("/register/structure/trust/?"+query_string)
    x = request.GET.get("pk")
    if not (x == "1") and (current_user.profile.is_admin or current_user.profile.is_employee):
        return redirect("/dashboard")        
    cnt = 0
    total_forms = User_form_id.objects.filter(user = current_user)
    for form in total_forms:
        comp = Company.objects.filter(company_id = form)
        if comp.exists(): cnt += 1
    print(cnt, x, "hiee")
    if cnt and not x:
        return redirect("/dashboard")        

    return render(request, 'dashboard/test.html')

@login_required(login_url='/accounts/login/')
@token_amount_page
def c_corp(request):
    current_user = request.user
    if current_user.is_staff:
        return redirect("dashboard/")
    
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    company_data=Company.objects.filter(company_id = user_obj)
    if not company_data.exists():
        Company(company_id=user_obj, name1="dum", name2="", name3="",name4="", type="Activity Code 01:Agriculture, Hunting and related Service activities", business_activity_description="", status = "", company_type = "1").save()
    return render(request, "dashboard/c_corp.html")

@login_required(login_url='/accounts/login/')
@token_amount_page
def llp(request):
    current_user = request.user
    if current_user.is_staff:
        return redirect("/dashboard/")
    DATA = {
    "amount": 1000000,
    "currency": "INR",
    "payment_capture": "1",
    }
    payment = client.order.create(data=DATA)
    order_id = payment["id"]
    
    context = {
        "amount": 10000,
        "api_key": settings.RAZOR_KEY_ID,
        "order_id": order_id
    }
    
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    company_data=Company.objects.filter(company_id = user_obj)
    if not company_data.exists():
        Company(company_id=user_obj, name1="dum", name2="", name3="",name4="", type="Activity Code 01:Agriculture, Hunting and related Service activities", business_activity_description="", status = "", company_type = "2").save()
    return render(request, "dashboard/llp.html", context)
    
def change_struct(request):
    if request.method == 'GET':
        actual = request.GET["actual"]
        return redirect("")

@login_required(login_url='/accounts/login/')
@token_amount_page
def trust(request):
    current_user = request.user
    if current_user.is_staff:
        return redirect("dashboard/")
    user_obj=request.user.profile.current_form_id
    print(user_obj)
    user_obj = User_form_id.objects.get(form_id = user_obj)
    company_data=Company.objects.filter(company_id = user_obj)
    if not company_data.exists():
        Company(company_id=user_obj, name1="dum", name2="", name3="",name4="", type="Activity Code 01:Agriculture, Hunting and related Service activities", business_activity_description="", status = "", company_type = "3").save()

    return render(request, "dashboard/trust.html")

@csrf_exempt  
@login_required(login_url='/accounts/login/')
def company_details(request):
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    company_data=Company.objects.filter(company_id = user_obj)
    if request.method =="POST":
        name1=request.POST.get('c_name1', "")
        name2=request.POST.get('c_name2', "")
        name3=request.POST.get('c_name3', "")
        name4=request.POST.get('c_name4', "")
        type=request.POST.get("nature_oa", "")
        structure_type=request.POST.get("structure_type", "")
        business_activity_description = request.POST.get('comp_desc', "")
        if company_data.exists():
            company_data=Company.objects.get(company_id = user_obj)
            company_data.name1 = name1
            company_data.name2 = name2
            company_data.name3 = name3
            company_data.name4 = name4
            company_data.type = type
            company_data.business_activity_description = business_activity_description
            company_data.save()
        else:
            new_company = Company(company_id=user_obj, name1=name1, name2=name2, name3=name3,name4=name4, type=type, business_activity_description=business_activity_description, status = "", company_type = structure_type)
            new_company.save()  
        return JsonResponse({"message":"Successfully saved"},status=200)
    if request.method == "GET":
        updating_the_data = request.GET.get("delete")
        if updating_the_data:
            Company.objects.filter(company_id = user_obj).delete()
            return JsonResponse({"message":"Successfully saved"},status=200)
        else:
            company_data=company_data.values()
            # print(company_data)
            return JsonResponse({"context":list(company_data)})

@csrf_exempt
@login_required(login_url='/accounts/login/')
def prog_level(request):
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    company_data=Company.objects.get(company_id = user_obj)
    company_data.registeration_progress_level = int(request.POST.get("prog", "0"))
    print("company_data:", company_data.registeration_progress_level, request.POST.get("prog", "0"))
    company_data.save()
    return JsonResponse({"message":"Changed the reg level"},status = 200)

    
@csrf_exempt  
@login_required(login_url='/accounts/login/')
def address_details(request):
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    company_data=Addresses.objects.filter(company_id=user_obj).exists()
    if request.method=="POST":
        address1=request.POST.get('cmp_address1', "")
        address2=request.POST.get('cmp_address2', "")
        city=request.POST.get('cmp_city',"")
        state=request.POST.get('cmp_state', "")
        zipcode=request.POST.get('cmp_zipcode', "")
        phone=request.POST.get('phone_number', "")
        property_type=request.POST.get('own_rented',"")
        owner_name=request.POST.get('owner_name', "")
        police = "samie" # api for policestation
        if company_data:
            company_data = Addresses.objects.get(company_id=user_obj)
            company_data.address1 = address1
            company_data.address2 = address2
            company_data.city = city
            company_data.state = state
            company_data.zipcode = zipcode
            company_data.phone_number = phone
            company_data.property_type = property_type
            company_data.owner_name = owner_name
            company_data.save()
        else:
            add_details=Addresses(company_id=user_obj, address1=address1, address2 = address2, city=city, state=state, phone_number=phone, property_type=property_type, zipcode = zipcode, owner_name = owner_name, nearest_police_station = police)
            add_details.save()
        return JsonResponse({"message":"Successfully saved"},status=200)

    if request.method == "GET":
        updating_the_data = request.GET.get("delete")
        if updating_the_data:
            Addresses.objects.filter(company_id = user_obj).delete()
            return JsonResponse({"message":"Successfully saved"},status=200)
        else:
            company_data=Addresses.objects.filter(company_id=user_obj).values()
            # print("Address :", company_data)
            return JsonResponse({"context":list(company_data)})


@csrf_exempt
@login_required(login_url='/accounts/login/')
def shareholder_details(request):
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)

    company_data=Founder.objects.all().filter(company_id = user_obj)
    share_holder_data = Share_capital.objects.filter(company_id = user_obj)

    if request.method =="POST":
        auth_share = request.POST.get("auth_share_capital[]")
        paid_share = request.POST.get("paid_share_capital[]")
        face_value = request.POST.get("face_value[]")
        fname=request.POST.getlist('first_name[]')
        mname = request.POST.getlist('middle_name[]')
        lname=request.POST.getlist('last_name[]')
        citizenshipstatus=request.POST.getlist('share_holder_nationality[]')
        shares_alloted=request.POST.getlist('shares1[]')
        if share_holder_data.exists():
            share_holder_data =Share_capital.objects.get(company_id = user_obj)
            share_holder_data.auth_share_capital = auth_share
            share_holder_data.paid_share_capital = paid_share
            share_holder_data.face_value = face_value
            share_holder_data.save()
        else: 
            share_status = Share_capital(company_id = user_obj, auth_share_capital = auth_share, paid_share_capital = paid_share, face_value = face_value)
            share_status.save()
        ln = len(fname)
        # print(fname, mname, lname, citizenshipstatus, shares_alloted, ln)
        if company_data.exists():
            company_data.delete()

        for i in range(ln):
            val = shares_alloted[i]
            if val:
                val = int(val)
            else:
                val = 0
            founder_create = Founder(company_id = user_obj, first_name = fname[i], last_name = lname[i], middle_name = mname[i], citizenship_status = citizenshipstatus[i], shares_alloted = val)
            founder_create.save()        
        # if company_data.exists():
        #     company_data.delete()
        return JsonResponse({"message":"Successfully saved"},status=200)
        
    if request.method == "GET":
        updating_the_data = request.GET.get("delete")
        if updating_the_data:
             
            Share_capital.objects.filter(company_id = user_obj).delete()
            Founder.objects.filter(company_id = user_obj).delete()
            return JsonResponse({"message":"Successfully saved"},status=200)
        else:
            share_data = Share_capital.objects.filter(company_id = user_obj).values()
            founder_data = Founder.objects.filter(company_id = user_obj).values()
            # print("share_data :", share_data)
            return JsonResponse({"share_data":list(share_data), "founder_data":list(founder_data)})

@csrf_exempt
@login_required(login_url='/accounts/login/')
def director_details(request):
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    director_data=Director.objects.filter(company_id=user_obj)
    if request.method =="POST":
        dir_name1=request.POST.getlist('dir_name1[]')
        dir_occ1=request.POST.getlist('dir_occ1[]')
        dir_mobile1=request.POST.getlist('dir_mobile1[]')
        dir_email1=request.POST.getlist('dir_email1[]')
        dir_citizen=request.POST.getlist('dir_nationality[]')
        dir_dsc=request.POST.getlist('dir_dsc[]')
        if director_data.exists():
            director_data.delete()
        for i in range(len(dir_name1)):
            director_details=Director(company_id = user_obj, name = dir_name1[i], current_occupation = dir_occ1[i], mobile_number = dir_mobile1[i], email = dir_email1[i], citizenship_status = dir_citizen[i], is_posses_DSC = dir_dsc[i])
            director_details.save()
        return JsonResponse({"message":"Successfully saved"},status=200)
    if request.method == "GET":
        updating_the_data = request.GET.get("delete")
        if updating_the_data:
            Director.objects.filter(company_id = user_obj).delete()
            return JsonResponse({"message":"Successfully deleted"},status=200)
        else:
            director_data = Director.objects.filter(company_id = user_obj).values()
            return JsonResponse({"director_data": list(director_data)})


@csrf_exempt
@login_required(login_url='/accounts/login/')
def update_director(request):
    if request.method == "POST":
        dir_id=request.POST.get('dir_id')
        dir_name=request.POST.get('dir_name')
        dir_occ=request.POST.get('dir_occ')
        dir_mobile=request.POST.get('dir_mobile')
        dir_email=request.POST.get('dir_email')
        dir_citizen=request.POST.get('dir_nationality')
        dir_dsc=request.POST.get('dir_dsc')
        
        director = Director.objects.get(id = dir_id)
        director.name = dir_name
        director.mobile_number = dir_mobile
        director.citizenship_status = dir_citizen
        director.current_occupation = dir_occ
        director.email = dir_email
        director.is_posses_DSC = dir_dsc
        director.save()
        return JsonResponse({"message":"Successfully saved"},status=200)
    return JsonResponse({"message":"Method not allowed"},status=200)


@csrf_exempt
@login_required(login_url='/accounts/login/')
def update_founder(request):
    if request.method == "POST":
        f_id=request.POST.get('f_id')
        f_first_name=request.POST.get('f_first_name')
        f_middle_name=request.POST.get('f_middle_name')
        f_last_name=request.POST.get('f_last_name')
        f_citizen=request.POST.get('f_nationality')
        f_share=request.POST.get('f_share')
        
        founder = Founder.objects.get(id = f_id)
        founder.first_name = f_first_name
        founder.middle_name = f_middle_name
        founder.last_name = f_last_name
        founder.shares_alloted = f_share
        founder.citizenship_status = f_citizen
        founder.save()
        return JsonResponse({"message":"Successfully saved"},status=200)
    return JsonResponse({"message":"Method not allowed"},status=200)

@csrf_exempt
@login_required(login_url='/accounts/login/')
def update_share(request):
    if request.method == "POST":
        comp_id=request.POST.get('comp_id')
        auth_share_capital=request.POST.get('auth_share_capital')
        paid_share_capital=request.POST.get('paid_share_capital')
        face_value=request.POST.get('face_value')
        
        share = Share_capital.objects.get(company_id_id = comp_id)
        share.auth_share_capital = auth_share_capital
        share.paid_share_capital = paid_share_capital
        share.face_value = face_value
        share.save()
        return JsonResponse({"message":"Successfully saved"},status=200)
    return JsonResponse({"message":"Method not allowed"},status=200)
    
@csrf_exempt
@login_required(login_url='/accounts/login/')
def company_documents(request):

    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    documents_data = company_document.objects.filter(company_id=user_obj)
    if request.method == "POST":
        dir_passphoto1 = get_file_name(request,'dir_passphoto1[]')
        dir_pancard1 = get_file_name(request,'dir_pancard1[]')
        type_of_proof_of_identity = request.POST.get("dir_proof1")
        dir_prooff1 = get_file_name(request,'dir_prooff1[]')
        type_of_proof_of_residence = request.POST.get("dir_proofr1")
        dir_proofrf1 = get_file_name(request,'dir_proofrf1[]')

        property_owner = request.POST.get("property_owner")
        own_sale_deed = get_file_name(request,'own_sale_deed')
        own_noc = get_file_name(request,'own_noc')
        rent_agree = get_file_name(request,'rent_agree')
        rent_reciept = get_file_name(request,'rent_reciept')
        rent_noc = get_file_name(request,'rent_noc')
        prop_proof = get_file_name(request,'prop_proof') # property proof
        concern_letter = get_file_name(request,'concern_letter[]')
        print(concern_letter)
        if documents_data.exists():
            documents_data = company_document.objects.get(company_id=user_obj)
            arr = []
            documents_data.type_of_proof_of_identity = type_of_proof_of_identity
            documents_data.type_of_proof_of_residence = type_of_proof_of_residence
            if len(dir_passphoto1):
                arr.append(documents_data.director_photo)
                documents_data.director_photo = dir_passphoto1
            if len(dir_pancard1):
                arr.append(documents_data.director_pan)
                documents_data.director_pan = dir_pancard1
            if len(dir_prooff1):
                arr.append(documents_data.director_proof_indentity)
                documents_data.director_proof_indentity = dir_prooff1
            if len(dir_proofrf1):
                arr.append(documents_data.director_proof_residence)
                documents_data.director_proof_residence = dir_proofrf1
            if len(own_sale_deed):
                arr.append(documents_data.own_sale_deed)
                documents_data.own_sale_deed = own_sale_deed
            if len(own_noc):
                arr.append(documents_data.own_noc)
                documents_data.own_noc = own_noc
            if len(rent_agree):
                arr.append(documents_data.rent_agree)
                documents_data.rent_agree = rent_agree
            if len(rent_reciept):
                arr.append(documents_data.rent_reciept)
                documents_data.rent_reciept = rent_reciept
            if len(rent_noc):
                arr.append(documents_data.rent_noc)
                documents_data.rent_noc = rent_noc
            if len(prop_proof):
                arr.append(documents_data.prop_proof)
                documents_data.prop_proof = prop_proof
            if len(concern_letter):
                arr.append(documents_data.concern_letter)
                documents_data.concern_letter = concern_letter
            
            documents_data.save()
            return JsonResponse({"arr":arr, "message":"wohooo"}, status = 200)
        
        document_create = company_document(company_id = user_obj,director_photo = dir_passphoto1,director_pan = dir_pancard1, type_of_proof_of_identity = type_of_proof_of_identity, director_proof_indentity = dir_prooff1,type_of_proof_of_residence = type_of_proof_of_residence,director_proof_residence  =dir_proofrf1,  property_owner = property_owner, own_sale_deed = own_sale_deed, own_noc = own_noc, rent_agree = rent_agree, rent_reciept = rent_reciept, rent_noc = rent_noc, prop_proof = prop_proof, concern_letter = concern_letter)
        document_create.save()
        return JsonResponse({"message":"whooo"}, status=200)
    if request.method == 'GET':
        updating_the_data = request.GET.get("delete")
        if updating_the_data:
            company_data = list(company_document.objects.filter(company_id = user_obj).values())
            print("company_data", len(company_data))
            arr = []
            if len(company_data) > 0:
                for key,val in company_data[0].items():
                    if val and "+_+" in val:
                        link = val
                        response = s3_client.delete_object(
                                Bucket=settings.AWS_STORAGE_BUCKET_NAME,
                                Key='Registration/' +str(request.user.profile.current_form_id) + "/"+link,
                            )
            company_document.objects.filter(company_id = user_obj).delete()
            return JsonResponse({"arr":arr, "message":"Successfully saved"},status=200)
        else:
            company_data=company_document.objects.filter(company_id=user_obj).values()
            # fields = [field.name for field in company_document._meta.get_fields(include_hidden=True)]
            # print(fields)
            company_data = list(company_data)
            company_data_to_work = list(company_document.objects.filter(company_id=user_obj).values())
            if company_data:
                for key,val in company_data[0].items():
                    if val and "+_+" in val:
                        temp = []
                        if "-*-" in val:
                            for x in val.split("-*-"):
                                idx = x.index("+_+")
                                temp.append(x[idx+3:])
                            company_data[0][key] = temp
                        else:
                            idx = val.index("+_+")
                            val = val[idx + 3:]
                            company_data[0][key] = [val]
                # print("here printing")
            comp_temp = company_data
            company_data = company_data_to_work
            if company_data:
                for key,val in company_data[0].items():
                    if val and "+_+" in val:
                        temp = []
                        if "-*-" in val:
                            for x in val.split("-*-"):
                                temp.append(x)
                            company_data[0][key] = temp
                        else:
                            idx = val.index("+_+")
                            company_data[0][key] = [val]
            company_data_to_work = company_data
            company_data = comp_temp
            return JsonResponse({"context":company_data, "work":company_data_to_work})



@login_required(login_url='/accounts/login/')
def get_file_name(request, item):
    media_storage = MediaStorage()
    media_storage.location = media_storage.location + "/" +  request.user.profile.current_form_id
    ct = datetime.datetime.now()
    file = request.FILES.getlist(item)
    temp = []
    for files in file:
        url_name = str(ct) + "+_+" + files.name
        media_storage.save(url_name, files)
        temp.append(url_name)
    return "-*-".join(temp)

@csrf_exempt
@login_required(login_url='/accounts/login/')
def open_files(request):
    user_obj=request.user.profile.current_form_id
    if request.method == "POST":
        link = request.POST.get("link")
        response = s3_client.generate_presigned_url('get_object',Params={'Bucket': settings.AWS_STORAGE_BUCKET_NAME,'Key': 'Registration/' +str(user_obj) + "/"+link})
        
        return JsonResponse(response, safe=False)

@csrf_exempt
@login_required(login_url='/accounts/login/')
def delete_files(request):
    user_obj=request.user.profile.current_form_id
    if request.method == "POST":
        link = request.POST.get("link")
        response = s3_client.delete_object(
                Bucket=settings.AWS_STORAGE_BUCKET_NAME,
                Key='Registration/' +str(user_obj) + "/"+link,
            )
        return JsonResponse({"message":"successsfull"}, status = 200)

@login_required(login_url='/accounts/login/')
def create_profile(request):
    if request.method =="POST":
        username = request.POST['username']
        email = request.POST['useremail']
        password = request.POST['userpassword']
        level = request.POST['access']
        
        user = User.objects.create_user(username, email, password)
        if level == "Admin":
            user.profile.is_admin = True
            user.profile.is_client = False
        elif level == "Employee":
            user.profile.is_employee = True
            user.profile.is_client = False
        else:
            user.profile.is_client = True
            
        user.save()
            
        return redirect("/dashboard/")
        
    else:
        return HttpResponse("Method not allowed")
    

@csrf_exempt    
def user_comment(request, id):
    user_obj = User_form_id.objects.get(form_id = id)
    comment_data=Comment.objects.filter(company_id=user_obj)
    if request.method =="POST":
        print("triggering the male for this comment", request.user.email, request.user)
        print(Company.objects.get(company_id = user_obj).name1)
        send_email([{"email":user_obj.user.email,"name":"John Doe"}], 14, {"name":str(user_obj.user), "company":Company.objects.get(company_id = user_obj).name1})
        comment_text = request.POST.get("comment_text")
        comment_file = request.FILES.get("comment_file")
        new_name = "Comment/" + str(id)
        media_storage = MediaStorage()
        media_storage.location = new_name
        ct = datetime.datetime.now()
        files = comment_file
        if files:
            url_name = str(ct) + "+_+" + files.name
            media_storage.save(url_name, files)
        else:
            url_name = ""
        # print("here after getting the data")
        new_comment = Comment(user = request.user, file_upload = url_name, comment = comment_text, company_id = user_obj)
        new_comment.save()
        return JsonResponse({"message":"file saved succesfully"})


    # data = {
    #     "comment": comment_data.comment,
    #     "user": request.user,
    #     "time": comment_data.timestamp
    # } 
    new_name = "Comment/" + str(id)
    # response = s3_client.generate_presigned_url('get_object',
    #                                         Params={'Bucket': settings.AWS_STORAGE_BUCKET_NAME,
    #                                             'Key': new_name + "/"+})
    data = []
    for ins in comment_data:
        dict = {}
        dict['comment'] = ins.comment
        dict['user'] = ins.user.username
        dict['time'] = ins.timestamp.strftime('%b. %d, %Y, %I:%m %p')
        val = ins.file_upload
        if val and "+_+" in val:
            idx = val.index("+_+")
            val = val[idx + 3:]
        dict["com_name"] = val
        dict["com_link"] = s3_client.generate_presigned_url('get_object',
                                            Params={'Bucket': settings.AWS_STORAGE_BUCKET_NAME,
                                                'Key': new_name + "/"+ ins.file_upload})
        
        data.append(dict)
    return JsonResponse({"data": data}, status=200)
    
@csrf_exempt
@login_required(login_url='/accounts/login/')
def partner_details(request):
    
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    partner_data = Partner.objects.all().filter(company_id = user_obj)
    if request.method == "POST":
        partner1_desg = request.POST.getlist('partner1_desg[]', '')
        partner1_name = request.POST.getlist('partner1_name[]', '')
        partner1_dob = request.POST.getlist('partner1_dob[]', '')
        partner1_ciz_status = request.POST.getlist('partner1_ciz_status[]', '')
        partner1_pan = request.POST.getlist('partner1_pan[]', '')
        partner1_pob = request.POST.getlist('partner1_pob[]', '')
        partner1_permadd1 = request.POST.getlist('partner1_permadd1[]', '')
        partner1_permadd2 = request.POST.getlist('partner1_permadd2[]', '')
        partner1_permcity = request.POST.getlist('partner1_permcity[]', '')
        partner1_permstate = request.POST.getlist('partner1_permstate[]', '')
        partner1_permcode = request.POST.getlist('partner1_permcode[]', '')
        partner1_perm_pres = request.POST.getlist('partner1_perm_pres[]', '')
        partner1_presadd1 = request.POST.getlist('partner1_presadd1[]', '')
        partner1_presadd2 = request.POST.getlist('partner1_presadd2[]', '')
        partner1_prescity = request.POST.getlist('partner1_prescity[]', '')
        partner1_presstate = request.POST.getlist('partner1_presstate[]', '')
        partner1_prescode = request.POST.getlist('partner1_prescode[]', '')
        partner1_occup = request.POST.getlist('partner1_occup[]', '')
        partner1_educ = request.POST.getlist('partner1_educ[]', '')
        partner1_dsc = request.POST.getlist('partner1_dsc[]', '')
        partner1_desig_typebody = request.POST.getlist('partner1_desig_typebody[]', '')
        partner1_desig_cin = request.POST.getlist('partner1_desig_cin[]', '')
        partner1_desig_pan = request.POST.getlist('partner1_desig_pan[]', '')
        partner1_desig_name = request.POST.getlist('partner1_desig_name[]', '')
        partner1_desig_permadd1 = request.POST.getlist('partner1_desig_permadd1[]', '')
        partner1_desig_permadd2 = request.POST.getlist('partner1_desig_permadd2[]', '')
        partner1_desig_permcity = request.POST.getlist('partner1_desig_permcity[]', '')
        partner1_desig_permstate = request.POST.getlist('partner1_desig_permstate[]', '')
        partner1_desig_permcode = request.POST.getlist('partner1_desig_permcode[]', '')
        body_corp_name = request.POST.getlist('body_corp_name[]', '')
        body_corp_din = request.POST.getlist('body_corp_din[]', '')
        body_corp_desg = request.POST.getlist('body_corp_desg[]', '')
        profit_perc = request.POST.getlist("profit_perc[]", "")
        are_you_desig_partner = request.POST.getlist("are_you_desig_partner[]", "")
        if partner_data.exists():
            partner_data.delete()
        length_of_data = len(partner1_desg)
        for i in range(length_of_data):
            if partner1_dob[i]:
                val_dob = parse_date(partner1_dob[i])
            else:
                val_dob = datetime.date.today()
            partner_data = Partner(company_id = user_obj, type_of_desg = partner1_desg[i], name = partner1_name[i], dob = val_dob, partner_citz_status = partner1_ciz_status[i], pan_passport_details = partner1_pan[i], place_of_birth = partner1_pob[i], perm_add1 = partner1_permadd1[i], perm_add2 = partner1_permadd2[i], perm_city = partner1_permcity[i], perm_state = partner1_permstate[i], perm_zipcode = partner1_permcode[i], perm_pres_same = partner1_perm_pres[i], pres_add1 = partner1_presadd1[i], pres_add2 = partner1_presadd2[i], pres_city = partner1_prescity[i], pres_state = partner1_presstate[i], pres_zipcode = partner1_prescode[i], occupation = partner1_occup[i], education = partner1_educ[i], dsc_no = partner1_dsc[i], desig_typebody = partner1_desig_typebody[i], desig_cin = partner1_desig_cin[i], desig_pan = partner1_desig_pan[i], desig_name = partner1_desig_name[i], desig_permadd1 = partner1_desig_permadd1[i], desig_permadd2 = partner1_desig_permadd2[i], desig_permcity = partner1_desig_permcity[i], desig_permstate = partner1_desig_permstate[i], desig_permcode = partner1_desig_permcode[i], body_corp_name = body_corp_name[i], body_corp_din = body_corp_din[i], body_corp_desg = body_corp_desg[i], profit_perc = profit_perc[i], are_you_desig_partner = are_you_desig_partner[i])
            partner_data.save()
        return JsonResponse({"message":"Successfully saved"},status=200)

    if request.method == "GET":
        updating_the_data = request.GET.get("delete")
        if updating_the_data:
            Partner.objects.filter(company_id = user_obj).delete()
            return JsonResponse({"message":"Successfully saved"},status=200)
        else:
            partner_data = Partner.objects.filter(company_id = user_obj).values()
            # print(partner_data)
            return JsonResponse({"partner_data": list(partner_data)})
@csrf_exempt
@login_required(login_url='/accounts/login/')
def trust_details(request):
    user_obj=request.user.profile.current_form_id
    # user_obj = User_form_id.objects.get(form_id = user_obj)
    comp_obj = Company.objects.get(company_id = user_obj)
    trust_data = Trust_details.objects.filter(company_id = comp_obj)
    if request.method == "POST":
        truste_name = request.POST.get('truste_name', )
        truste_address1 = request.POST.get('truste_address1', )
        truste_address2 = request.POST.get('truste_address2', )
        truste_city = request.POST.get('truste_city', )
        truste_state = request.POST.get('truste_state', )
        truste_zipcode = request.POST.get('truste_zipcode', )
        settler_name = request.POST.get('settler_name', )
        settler_address1 = request.POST.get('settler_address1', )
        settler_address2 = request.POST.get('settler_address2', )
        settler_city = request.POST.get('settler_city', )
        settler_state = request.POST.get('settler_state', )
        settler_zipcode = request.POST.get('settler_zipcode', )
        if trust_data.exists():
            trust_data = Trust_details.objects.get(company_id = comp_obj)
            trust_data.truste_name = truste_name
            trust_data.truste_address1 = truste_address1
            trust_data.truste_address2 = truste_address2
            trust_data.truste_city = truste_city
            trust_data.truste_state = truste_state
            trust_data.truste_zipcode = truste_zipcode
            trust_data.settler_name = settler_name
            trust_data.settler_address1 = settler_address1
            trust_data.settler_address2 = settler_address2
            trust_data.settler_city = settler_city
            trust_data.settler_state = settler_state
            trust_data.settler_zipcode = settler_zipcode    
            trust_data.save()
        else:
            trust_data = Trust_details(company_id = comp_obj, truste_name = truste_name ,truste_address1 = truste_address1 ,truste_address2 = truste_address2 ,truste_city = truste_city ,truste_state = truste_state ,truste_zipcode = truste_zipcode ,settler_name = settler_name ,settler_address1 = settler_address1 ,settler_address2 = settler_address2 ,settler_city = settler_city ,settler_state = settler_state ,settler_zipcode = settler_zipcode)
            trust_data.save()
        return JsonResponse({"message":"Successfully saved"},status=200)
        
    if request.method == "GET":
        updating_the_data = request.GET.get("delete")
        if updating_the_data:
            Trust_details.objects.filter(company_id = comp_obj).delete()
            return JsonResponse({"message":"Successfully saved"},status=200)
        else:
            company_data=Trust_details.objects.filter(company_id=comp_obj).values()
            # print(company_data)
            return JsonResponse({"context":list(company_data)})



# code = ['Activity Code 01', 'Activity Code 02', 'Activity Code 05', 'Activity Code 10', 'Activity Code 11', 'Activity Code 12', 'Activity Code 13', 'Activity Code 14', 'Activity Code 15', 'Activity Code 16', 'Activity Code 17', 'Activity Code 18', 'Activity Code 19', 'Activity Code 20', 'Activity Code 21', 'Activity Code 22', 'Activity Code 23', 'Activity Code 24', 'Activity Code 25', 'Activity Code 26', 'Activity Code 27', 'Activity Code 28', 'Activity Code 29', 'Activity Code 30', 'Activity Code 31', 'Activity Code 32', 'Activity Code 33', 'Activity Code 34', 'Activity Code 35', 'Activity Code 36', 'Activity Code 37', 'Activity Code 40', 'Activity Code 41', 'Activity Code 45', 'Activity Code 50', 'Activity Code 51', 'Activity Code 52', 'Activity Code 55', 'Activity Code 60', 'Activity Code 61', 'Activity Code 62', 'Activity Code 63', 'Activity Code 64', 'Activity Code 65', 'Activity Code 66', 'Activity Code 67', 'Activity Code 70', 'Activity Code 71', 'Activity Code 72', 'Activity Code 73', 'Activity Code 74', 'Activity Code 75', 'Activity Code 80', 'Activity Code 85', 'Activity Code 90', 'Activity Code 91', 'Activity Code 92', 'Activity Code 93', 'Activity Code 95', 'Activity Code 96', 'Activity Code 97', 'Activity Code 99']
    # bus = ['Agriculture, Hunting and related Service activities', 'Forestry, logging and related Service activities', 'Fishing, Operation of fish hatcheries and fish farms; Service activities incidental to fishing', 'Mining of coal and lignite, extraction of peat', 'Extraction of crude petroleum and natural gas, service activities incidental to oil and gas extraction excluding surveying', 'Mining of uranium and thorium ores', 'Mining of metal ores', 'Other Mining and Quarrying', 'Manufacture of food products and beverages', 'Manufacture of tobacco products', 'Manufacture of textiles', 'Manufacture of wearing apparel, dressing and dyeing of fur', 'Tanning and dressing of leather, manufacture of luggage handbags, saddlery & harness and footwear', 'Manufacture of wood and of products of wood and cork, except furniture; manufacture of articles of straw and plating materials', 'Manufacture of paper and paper products', 'Publishing, printing and reproduction of recorded media', 'Manufacture of coke, refined petroleum products and nuclear fuel', 'Manufacture of chemicals and chemical products', 'Manufacture of rubber and plastic products', 'Manufacture of other non-metallic mineral products', 'Manufacture of basic metals', 'Manufacture of fabricated metal products, except machinery and equipments', 'Manufacture of machinery and equipment n.e.c', 'Manufacture of office, accounting and computing machinery', 'Manufacture of electrical machinery and apparatus n.e.c', 'Manufacture of radio, television and communication equipment and apparatus', 'Manufacture of medical, precision and optical instruments, watches and clocks', 'Manufacture of motor vehicles, trailers and semi-trailers', 'Manufacture of other transport equipment', 'Manufacture of furniture; manufacturing n.e.c', 'Recycling', 'Electricity, gas, steam and hot water supply', 'Collection, purification and distribution of water', 'Construction', 'Sale, maintenance and repair of motor vehicles and motorcycles; retail sale of automotive fuel', 'Wholesale trade and commission trade, except of motor vehicles and motorcycles', 'Retail trade, except of motor vehicles and motorcycles, repair of personal and household goods', 'Hotels and Restaurants', 'Land transport; transport via pipelines', 'Water Transport', 'Air Transpor', 'Supporting and auxiliary transport activities, activities of travel agencies', 'Post and telecommunications', 'Financial intermediation, except insurance and pension funding', 'Insurance and pension funding, except compulsory social security', 'Activities auxiliary to financial intermediation', 'Real estate activities', 'Renting of machinery and equipment without operator and of personal and household goods', 'Computer and related activities', 'Research and Development', 'Other Business Activities', 'Public Administration and Defence, compulsory social security', 'Education', 'Health and Social Work', 'Sewage and refuse disposal, sanitation and similar activities', 'Activities of membership organizations n.e.c.', 'Recreational, cultural and sporting activities', 'Other Service activities', 'Activities of private households as employers of domestic staff', 'Undifferentiated goods-producing activities of private households for own use', 'Undifferentiated service-producing activities of private households for own use', 'Extra territorial organizations and bodies']
    # print("lkjasdalkdj")
    # for i,j in zip(code, bus):
    #     data = Drop_down_list(description = j, drop_code = i)
    #     data.save()
    # print("doneee")


def nature_updation(request):
    drop_down = Drop_down_list.objects.all().values()
    return JsonResponse({"data":list(drop_down)}, status = 200)


def first_page(request):
    return render(request, "dashboard/first_page.html")


def delete_company(request, id):
    print(id)
    User_form_id.objects.get(form_id = str(id)).delete()
    return redirect("/dashboard")


def delete_property_owner(request):
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    if request.method == "GET":
        company_data = list(company_document.objects.filter(company_id = user_obj).values())
        arr = ["own_sale_deed", "own_noc", "rent_agree", "rent_reciept", "rent_noc"]
        if company_data:
            data_object = company_data[0]
            for i in arr:
                val = data_object.get(i, "")
                if val and "+_+" in val:
                    link = val
                    response = s3_client.delete_object(
                            Bucket=settings.AWS_STORAGE_BUCKET_NAME,
                            Key='Registration/' +str(request.user.profile.current_form_id) + "/"+link,
                            )
            documents_data = company_document.objects.get(company_id=user_obj)
            documents_data.own_sale_deed = ""
            documents_data.own_noc = ""
            documents_data.rent_agree = ""
            documents_data.rent_reciept = ""
            documents_data.rent_noc = ""
            documents_data.save()
            return JsonResponse({"arr":arr, "message":"Successfully saved"},status=200)


@csrf_exempt
def nature_of_trust(request):
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    company_data = Nature_of_trust.objects.filter(company_id=user_obj)
    print("started saving the data in nature_of_trust")
    if request.method == 'POST':
        revoc = request.POST.get("revoc", "")
        discre = request.POST.get("discre", "")
        trust_fund_setup = request.POST.get("trust_fund_setup", "")
        trust_trustee_service = request.POST.get("trust_trustee_service", "")
        trust_trustee_aif_reg = request.POST.get("trust_trustee_aif_reg", "")
        if company_data.exists():
            company_data = Nature_of_trust.objects.get(company_id=user_obj)
            company_data.discre = discre
            company_data.trust_fund_setup = trust_fund_setup
            company_data.trust_trustee_service = trust_trustee_service
            company_data.trust_trustee_aif_reg = trust_trustee_aif_reg
            company_data.revoc = revoc
            company_data.save()
        else:
            company_data = Nature_of_trust(company_id = user_obj, revoc = revoc, discre = discre, trust_fund_setup = trust_fund_setup, trust_trustee_service = trust_trustee_service, trust_trustee_aif_reg = trust_trustee_aif_reg)
            company_data.save()
        return JsonResponse({"message":"Successfully saved"},status=200)



def delete_files_document(request):
    id = request.GET.get("id")
    file_name = request.GET.get("file_name")
    user_obj=request.user.profile.current_form_id
    link = id.replace("_._", " ")
    response = s3_client.delete_object(
            Bucket=settings.AWS_STORAGE_BUCKET_NAME,
            Key='Registration/' +str(user_obj) + "/"+link,
        )
    user_obj=request.user.profile.current_form_id
    user_obj = User_form_id.objects.get(form_id = user_obj)
    # documents_data.save()
    file_arr = ['director_photo', 'director_pan', 'director_proof_indentity', 'director_proof_residence', 'own_sale_deed', 'own_noc', 'rent_agree', 'rent_reciept', 'rent_noc', 'prop_proof', "concern_letter"]
    file_field = ["dir_passphoto1_id", "dir_pancard1_id", "dir_prooff1_id", "dir_proofrf1_id", "own_sale_deed_id", "own_noc_id", "rent_agree_id", "rent_reciept_id", "rent_noc_id", "prop_proof_id","concern_letter_id"]

    change_file = file_arr[file_field.index(file_name)]
    x = company_document.objects.get(company_id=user_obj)
    y = list(company_document.objects.filter(company_id=user_obj).values())[0]
    temp = [i for i in y[change_file].split("-*-")]
    if link in temp:
        temp.remove(link)
        up = "-*-".join(temp)
        print(up)
        company_document.objects.filter(company_id=user_obj).update(**{change_file:up})
    else:
        if not temp:
            company_document.objects.filter(company_id=user_obj).update(**{change_file:""})
    return JsonResponse({"message":"successsfull"}, status = 200)




                    





    