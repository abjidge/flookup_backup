from django.contrib import admin
# Register your models here.
from .models import *

#  # iterable list
admin.site.register(Profile)
admin.site.register(Company)
admin.site.register(Addresses)
admin.site.register(Founder)
admin.site.register(Director)
admin.site.register(company_document)
admin.site.register(Partner)
admin.site.register(Share_capital)
admin.site.register(Comment)
admin.site.register(User_form_id)
admin.site.register(Assignee)
admin.site.register(Drop_down_list)
admin.site.register(Trust_details)
admin.site.register(Nature_of_trust)
admin.site.register(Transaction)






# admin.site.register(User)
