from email.policy import default
from unittest.util import _MAX_LENGTH
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.timezone import now
from django.utils import timezone
from storages.backends.s3boto3 import S3Boto3Storage




    
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_admin = models.BooleanField(default = False)
    is_client = models.BooleanField(default = True)
    is_employee = models.BooleanField(default = False)
    current_form_id = models.CharField(default = "0", max_length = 50)
    total_tokens = models.IntegerField(default = 0, null = True)
    def __str__(self):
        return self.user.username
    
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()


class User_form_id(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    form_id = models.CharField(max_length = 50, default = None, primary_key=True)
    total_amount = models.IntegerField(default = 10000)
    amount_paid = models.IntegerField(default = 0)
    token_amount_paid = models.CharField(default = "0", max_length = 1,null = True)
    token_amount_used = models.CharField(default = "0", max_length=1, null=True)
    


class Company(models.Model):
    company_id= models.ForeignKey(User_form_id, on_delete = models.CASCADE ,default=None, primary_key=True)
    name1 = models.CharField(max_length=50,default=None)
    name2 = models.CharField(max_length=50,default=None)
    name3 = models.CharField(max_length=50, blank=True, default=None)
    name4 = models.CharField(max_length=50, blank=True, default=None)
    type = models.CharField(max_length=200, default=None)
    business_activity_description=models.CharField(max_length=100, default=None)
    # product_service_description = models.CharField(max_length=500, default=None)
    registeration_progress_level=models.IntegerField(default=0)
    status = models.CharField(max_length=50, default=None, blank=True)
    company_type = models.CharField(max_length =100, default = None, null = True)
    payment_status = models.CharField(default = "0", max_length = 2)
    status_info = models.CharField(max_length=160, default="No update", null = True)
    
    def __str__(self):
        return self.name1

    
class Addresses(models.Model):    
    company_id= models.ForeignKey(User_form_id, on_delete = models.CASCADE ,default=None, primary_key=True)
    address1 = models.CharField(max_length=100,default=None )
    address2 = models.CharField(max_length=100,default=None )
    city=models.CharField(max_length=50 ,default=None)
    state=models.CharField(max_length=50,default=None)
    phone_number = models.CharField(max_length=50, default=None)
    property_type = models.CharField(max_length=100,default=None)
    nearest_police_station=models.CharField(max_length=100, default=None)
    zipcode = models.CharField(max_length = 20, default = None)
    owner_name = models.CharField(max_length = 50, default=None)
    

class Share_capital(models.Model):
    company_id= models.ForeignKey(User_form_id, on_delete = models.CASCADE ,default=None, primary_key=True)
    auth_share_capital = models.IntegerField(default = 100000)
    paid_share_capital = models.IntegerField(default = 100000)
    face_value = models.IntegerField(default = 10)


class Founder(models.Model):
    company_id= models.ForeignKey(User_form_id, on_delete = models.CASCADE ,default=None )
    first_name = models.CharField(max_length=20,default=None)
    middle_name = models.CharField(max_length = 20, default=None)
    last_name = models.CharField(max_length=20,default=None)
    citizenship_status=models.CharField(max_length=30,default=None)
    shares_alloted=models.IntegerField(null=True, blank=True)    
    
class Director(models.Model):
    id = models.AutoField(primary_key=True, default=None)
    company_id= models.ForeignKey(User_form_id, on_delete = models.CASCADE ,default=None)
    name = models.CharField(max_length=50,default=None)
    mobile_number = models.CharField(max_length=50, default = None)
    citizenship_status=models.CharField(max_length=50,default=None)
    current_occupation=models.CharField(max_length=100,default=None)
    email=models.EmailField(max_length=30,default=None)
    is_posses_DSC=models.CharField(max_length = 10, default="No")

    
class company_document(models.Model):
    company_id= models.ForeignKey(User_form_id, on_delete = models.CASCADE ,default=None, primary_key=True)
    director_photo = models.TextField(default=None)
    director_pan = models.TextField(default=None)
    type_of_proof_of_identity = models.TextField(default=None)
    director_proof_indentity = models.TextField(default=None)
    type_of_proof_of_residence = models.TextField(default=None)
    director_proof_residence = models.TextField(default=None)
    property_owner = models.TextField(default=None)
    own_sale_deed = models.TextField(default=None)
    own_noc = models.TextField(default=None)
    rent_agree = models.TextField(default=None)
    rent_reciept = models.TextField(default=None)
    rent_noc = models.TextField(default=None)
    prop_proof = models.TextField(default=None)
    concern_letter = models.TextField( default=None, blank = True, null=True)



class Partner(models.Model):
    #partner_id, comp_id
    company_id= models.ForeignKey(User_form_id, on_delete = models.CASCADE ,default=None)
    desg_partner = (("1", "Indivisual"), ("3", "Body_with_din"), ("2", "body_without_din"))
    type_of_desg = models.CharField(max_length = 100, default="1", choices = desg_partner )
    name = models.CharField(max_length=20,default=None)
    dob = models.DateField(default = timezone.now)
    partner_citz_status = models.CharField(default = None, max_length = 40)
    pan_passport_details = models.CharField(max_length = 30, default = "10")
    place_of_birth = models.CharField(max_length = 40, default = None)
    perm_add1 = models.CharField(max_length = 200, default = None)
    perm_add2 = models.CharField(max_length = 200, default = None)
    perm_city = models.CharField(max_length = 200, default = None)
    perm_state = models.CharField(max_length = 200, default = None)
    perm_zipcode = models.CharField(max_length = 200, default = None)
    perm_pres_same = models.CharField(max_length = 10, default = None)
    pres_add1 = models.CharField(max_length = 200, default = None)
    pres_add2 = models.CharField(max_length = 200, default = None)
    pres_city = models.CharField(max_length = 200, default = None)
    pres_state = models.CharField(max_length = 200, default = None)
    pres_zipcode = models.CharField(max_length = 200, default = None)
    occupation = models.CharField(max_length = 200, default = None)
    education = models.CharField(max_length = 200, default = None)
    dsc_no = models.CharField(max_length = 100, default = None)
    desig_typebody = models.CharField(max_length = 100, default = None)
    desig_cin = models.CharField(max_length = 100, default = None)
    desig_pan = models.CharField(max_length = 100, default = None)
    desig_name = models.CharField(max_length = 100, default = None)
    desig_permadd1 = models.CharField(max_length = 100, default = None)
    desig_permadd2 = models.CharField(max_length = 100, default = None)
    desig_permcity = models.CharField(max_length = 100, default = None)
    desig_permstate = models.CharField(max_length = 100, default = None)
    desig_permcode = models.CharField(max_length = 100, default = None)
    body_corp_name = models.CharField(max_length = 100, default = None)
    body_corp_din = models.CharField(max_length = 100, default = None)
    body_corp_desg = models.CharField(max_length = 100, default = None)
    profit_perc = models.CharField(max_length = 50, default = None)
    are_you_desig_partner = models.CharField(max_length = 100, default = "NO", null = True)

class MediaStorage(S3Boto3Storage):
    location = 'Registration'
    file_overwrite = True

class Comment(models.Model):
    id = models.AutoField(primary_key = True)
    comment = models.TextField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    company_id= models.ForeignKey(User_form_id, on_delete = models.CASCADE ,default=None)
    file_upload = models.CharField(max_length= 500, default = None)
    
    # parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True)
    timestamp = models.DateTimeField(auto_now = True)
    
class Assignee(models.Model):
    company = models.OneToOneField(Company, on_delete=models.CASCADE, primary_key = True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    
class Drop_down_list(models.Model):
    # id = models.AutoField(primary_key = True)
    description = models.CharField(max_length = 200, default = None)
    drop_code = models.CharField(max_length = 100, default = None)

class Trust_details(models.Model):
    company_id= models.OneToOneField(Company, on_delete = models.CASCADE ,default=None, primary_key=True)
    truste_name = models.CharField(max_length = 100, default = None)
    truste_address1 = models.CharField(max_length = 100, default = None)
    truste_address2 = models.CharField(max_length = 100, default = None)
    truste_city = models.CharField(max_length = 100, default = None)
    truste_state = models.CharField(max_length = 100, default = None)
    truste_zipcode = models.CharField(max_length = 100, default = None)
    settler_name = models.CharField(max_length = 100, default = None)
    settler_address1 = models.CharField(max_length = 100, default = None)
    settler_address2 = models.CharField(max_length = 100, default = None)
    settler_city = models.CharField(max_length = 100, default = None)
    settler_state = models.CharField(max_length = 100, default = None)
    settler_zipcode = models.CharField(max_length = 100, default = None)

class Nature_of_trust(models.Model):
    company_id= models.ForeignKey(User_form_id, on_delete = models.CASCADE ,default=None, primary_key=True)
    revoc = models.CharField(max_length = 100, default = None)
    discre = models.CharField(max_length = 100, default = None)
    trust_fund_setup = models.CharField(max_length = 100, default = None)
    trust_trustee_service = models.CharField(max_length = 100, default = None)
    trust_trustee_aif_reg = models.CharField(max_length = 100, default = None)

class Transaction(models.Model):
    user_id = models.ForeignKey(User, on_delete = models.CASCADE)
    form_id = models.ForeignKey(User_form_id, on_delete = models.CASCADE)
    amount = models.IntegerField(default = 0)
    timestamp = models.DateTimeField(auto_now = True)
    order_id = models.CharField(max_length = 100, default = None)
    payment_id = models.CharField(max_length = 100, default = None)
    signature = models.CharField(max_length = 100, default = None)
    

