from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard_panel, name = "dashboard_panel"),
    path("company/<str:id>/", views.company_view, name = "company"),
    path('users/', views.users, name = "users"),
    path("create_new_form/", views.create_new_form, name = "create_new_form"),
    path("filter", views.filter, name = "filter_form"),
    path("export_csv_pvt", views.exportcsv_pvt, name = "export_csv_pvt"),
    path("export_csv_llp", views.exportcsv_llp, name = "export_csv_llp"),
    path("export_csv_trust", views.exportcsv_trust, name = "export_csv_trust"),
    path("change_assignee", views.change_assignee, name = "change_assignee"),
    path("change_status", views.change_status, name = "change_status"),
    path("change_status_info", views.change_status_info, name = "change_status_info"),
    path("delete_user", views.delete_user, name = "delete_user"),
    path("test_ex", views.test_ex, name = "test_ex"),
    path("draft_company/<str:id>/<str:structure_type>/", views.draft_company, name = "draft_company"),
    
]