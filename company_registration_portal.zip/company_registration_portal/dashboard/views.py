import re
import struct
from urllib.request import Request
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import get_user_model
from dashboard.models import *
from registration_app.models import *
import uuid
from django.db.models import Q
import csv
from django.views.decorators.csrf import csrf_exempt
from registration_app import views
from datetime import datetime
from django.http import JsonResponse
from django.conf import settings
import boto3
from urllib.parse import urlencode
from pprint import pprint


# from registration_app.views import send_email

import sib_api_v3_sdk
from sib_api_v3_sdk.rest import ApiException

key = "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"

# Configure API key authorization: api-key
configuration = sib_api_v3_sdk.Configuration()
configuration.api_key['api-key'] = key

# create an instance of the API class
api_instance = sib_api_v3_sdk.TransactionalEmailsApi(sib_api_v3_sdk.ApiClient(configuration))

def send_email(to, template_id, params):
    # reference
    # to = [{"email":"ab1jidge@gmail.com","name":"John Doe"}]
    # template_id=1
    # params={"Name":"sadsa"}
    send_smtp_email = sib_api_v3_sdk.SendSmtpEmail(to=to, template_id=template_id, params=params, headers={"X-Mailin-custom": "custom_header_1:custom_value_1|custom_header_2:custom_value_2|custom_header_3:custom_value_3", "charset": "iso-8859-1"})
    try:
        # Send a transactional email
        api_response = api_instance.send_transac_email(send_smtp_email)
        pprint(api_response)
    except ApiException as e:
        print("Exception when calling SMTPApi->send_transac_email: %s\n" % e)


@login_required(login_url='/accounts/login/')
def dashboard_panel(request):
    current_user = request.user
    user_id = current_user.id
    if current_user.profile.is_employee:
        com_list = Assignee.objects.filter(user_id = user_id)
        forms = User_form_id.objects.filter(form_id__in = com_list)
        ins = Company.objects.filter(company_id__in = forms)
        context = {'company': ins}
    elif current_user.profile.is_admin:
        allUsers = User.objects.all()
        ins = Company.objects.filter(registeration_progress_level = 1)
        incomplete = Company.objects.filter(registeration_progress_level = 0)
        context = {'company': ins, "incomplete_company":incomplete, "users": allUsers}
    elif current_user.profile.is_client:
        forms = User_form_id.objects.filter(user = current_user.id)
        ins = Company.objects.filter(company_id__in = forms, registeration_progress_level = 1)
        incomplete = Company.objects.filter(company_id__in = forms, registeration_progress_level = 0)
        context = {'company': ins, "incomplete_company":incomplete}
    return render(request, 'dashboard/user_panel.html', context)

@login_required(login_url='/accounts/login/')
def filter(request):
    
    if request.method == "GET":
        st = request.GET.get("search-name")
        if st!=None:
            current_user = request.user
            user_id = current_user.id
            if current_user.profile.is_employee:
                com_list = Assignee.objects.filter(user_id = user_id)
                forms = User_form_id.objects.filter(form_id__in = com_list)
                ins = Company.objects.filter(company_id__in = forms, name1__icontains = st)
                context = {'company': ins}
            elif current_user.profile.is_client:
                forms = User_form_id.objects.filter(user = current_user.id)
                ins = Company.objects.filter(company_id__in = forms, registeration_progress_level = 1, name1__icontains = st)
                incomplete = Company.objects.filter(company_id__in = forms, registeration_progress_level = 0, name1__icontains = st)
                context = {'company': ins, "incomplete_company":incomplete}
            else:
                ins = Company.objects.filter(registeration_progress_level = 1, name1__icontains = st)
                incomplete = Company.objects.filter(registeration_progress_level = 0, name1__icontains = st)
                allUsers = User.objects.all()
                context = {'company': ins, "incomplete_company":incomplete, "users": allUsers}
            return render(request, 'dashboard/user_panel.html', context)

    if request.method == "POST":
        current_user = request.user
        user_id = current_user.id
        if current_user.profile.is_employee:
            com_list = Assignee.objects.filter(user_id = user_id)
            forms = User_form_id.objects.filter(form_id__in = com_list)
        else:
            forms = User_form_id.objects.all()
        query_condition = Q(company_id__in = forms)
        
        com_status = request.POST["comp_status"]
        payment = request.POST["comp_payment"]
        com_type = request.POST["comp_type"]
        print(com_status, "+++", com_type)
        
        if com_status != "0":
            query_condition &= Q(status = com_status)

        if payment != "2":
            query_condition &= Q(payment_status = payment)

        if com_type != "0":
            query_condition &= Q(company_type = com_type)
            print("145")
    
        filtered = Company.objects.filter(query_condition, registeration_progress_level = 1)
        filtered_draft = Company.objects.filter(query_condition, registeration_progress_level = 0)
        allUsers = User.objects.all()
        context = {'company': filtered, "incomplete_company": filtered_draft, "users": allUsers}
        
        return render(request, 'dashboard/user_panel.html', context)

@csrf_exempt
def company_view(request, id):
    request.user.profile.current_form_id = id
    request.user.save()
    company = Company.objects.get(company_id = id)
    address = Addresses.objects.get(company_id = id)
    if company.company_type == "3":
        context = {
            'company': company,
            'address': address,
        }
    elif company.company_type == "2":
        partners = Partner.objects.filter(company_id = id)
        doc_names = list(company_document.objects.filter(company_id = id).values())
        values = {}
        user_obj=request.user.profile.current_form_id
        s3_client = boto3.client("s3",
                         region_name='ap-south-1',
                         aws_access_key_id=settings.AWS_S3_ACCESS_KEY_ID,
                         aws_secret_access_key=settings.AWS_S3_SECRET_ACCESS_KEY
                        )

        for doc in doc_names:
            for key,valu in doc.items():
                if valu and "+_+" in valu:
                    temp = [i for i in valu.split("-*-")]
                    arr = []
                    for val in temp:
                        link = val
                        response = s3_client.generate_presigned_url('get_object',
                                                        Params={'Bucket': settings.AWS_STORAGE_BUCKET_NAME,
                                                            'Key': 'Registration/' +str(user_obj) + "/"+link})
                        arr.append(response)
                    values[key] = arr[:]
        context = {
            'company': company,
            'address': address,
            'partners': partners,
            'values': values,
        }
    else:
        share = Share_capital.objects.get(company_id = id)
        directors = Director.objects.filter(company_id = id)
        founders = Founder.objects.filter(company_id = id)
        doc_names = list(company_document.objects.filter(company_id = id).values())
        values = {}
        user_obj=request.user.profile.current_form_id
        s3_client = boto3.client("s3",
                         region_name='ap-south-1',
                         aws_access_key_id=settings.AWS_S3_ACCESS_KEY_ID,
                         aws_secret_access_key=settings.AWS_S3_SECRET_ACCESS_KEY
                        )

        for doc in doc_names:
            for key,valu in doc.items():
                if valu and "+_+" in valu:
                    temp = [i for i in valu.split("-*-")]
                    arr = []
                    for val in temp:
                        link = val
                        response = s3_client.generate_presigned_url('get_object',
                                                        Params={'Bucket': settings.AWS_STORAGE_BUCKET_NAME,
                                                            'Key': 'Registration/' +str(user_obj) + "/"+link})
                        arr.append(response)
                    values[key] = arr[:]
        print(values)
        context = {
            'company': company,
            'address': address,
            'founders': founders,
            'share': share,
            'directors': directors,
            "values":values,
            }
        
    return render(request, 'dashboard/company.html', context)

@csrf_exempt
def exportcsv_pvt(request):
    if request.method == 'POST':
        comp_id = request.POST['comp_id']

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="company_data.csv"'
        writer = csv.writer(response)
        
        writer.writerow(['Name1', 'Name2', 'Name3','Name4', 'Type', 'Nature of Activity', 'Business Description', 'Company Address Line 1', 'Company Address Line 2', 'City', 'State', 'Police Station', 'Zipcode', 'Phone', 'Property Type', 'Owner Name', 'Director Name', 'Director Phone', 'Director CityzenShip', 'Director Occupation', 'Director Email', 'DSC Status', 'Auth Share Capital', 'Paid Share Capital', 'Face Value', 'Founder First Name', 'Founder Middle Name', 'Founder Last Name', 'Founder Citizenship', 'Founder Share'])
        
        if comp_id != '0':
            company = Company.objects.get(company_id = comp_id)
            id = company.company_id
            
            record = [company.name1, company.name2, company.name3, company.name4, "Pvt. Ltd", company.type, company.business_activity_description]
            address = Addresses.objects.get(company_id = id)
            record += [address.address1, address.address2, address.city, address.state, address.nearest_police_station, address.zipcode, address.phone_number, address.property_type, address.owner_name]
            founders = Founder.objects.filter(company_id = id)
            directors = Director.objects.filter(company_id = id)
            print("Record", len(record))
            if not directors:
                record += ["", "", "", "", "", ""]
            else:
                director = directors[0]
                record += [director.name, director.mobile_number, director.citizenship_status, director.current_occupation, director.email, director.is_posses_DSC]
            share = Share_capital.objects.get(company_id = id)
            record += [share.auth_share_capital, share.paid_share_capital, share.face_value]
            if not founders:
                record += ["", "", "", "", "", ""]
            else:
                founder = founders[0]
                record += [founder.first_name, founder.middle_name, founder.last_name, founder.citizenship_status, founder.shares_alloted]
            writer.writerow(tuple(record))
            mx = max(len(founders), len(directors))
            for j in range(1, mx):
                record = [ "" for i in range(16)]
                if j < len(directors):
                    director = directors[j]
                    record += [director.name, director.mobile_number, director.citizenship_status, director.current_occupation, director.email, director.is_posses_DSC]
                else:
                    record += ["", "", "", "", "", ""]
                record += ["", "", ""]
                if j < len(founders):
                    founder = founders[j]
                    record += [founder.first_name, founder.middle_name, founder.last_name, founder.citizenship_status, founder.shares_alloted]
                else:
                    record += ["", "", "", "", "", ""]
                writer.writerow(tuple(record))
            
        else: #Filtered records download
            current_user = request.user
            user_id = current_user.id
            if current_user.profile.is_employee:
                com_list = Assignee.objects.filter(user_id = user_id)
                forms = User_form_id.objects.filter(form_id__in = com_list)
            else:
                forms = User_form_id.objects.all()
            
            query_condition = Q(company_id__in = forms)
            
            com_status = request.POST["comp_status"]
            payment = request.POST["comp_payment"]
            
            if com_status != "0":
                query_condition &= Q(status = com_status)

            if payment != "2":
                query_condition &= Q(payment_status = payment)
        
            companies = Company.objects.filter(query_condition, registeration_progress_level = 1, company_type = "1")
            lst = []
            for company in companies:
                id = company.company_id
                record = [company.name1, company.name2, company.name3, company.name4, "Pvt. Ltd", company.type, company.business_activity_description]
                address = Addresses.objects.get(company_id = id)
                record += [address.address1, address.address2, address.city, address.state, address.nearest_police_station, address.zipcode, address.phone_number, address.property_type, address.owner_name]
                directors = Director.objects.filter(company_id = id)
                if not directors:
                    record += ["", "", "", "", "", ""]
                else:
                    director = directors[0]
                    record += [director.name, director.mobile_number, director.citizenship_status, director.current_occupation, director.email, director.is_posses_DSC]
                share = Share_capital.objects.get(company_id = id)
                record += [share.auth_share_capital, share.paid_share_capital, share.face_value]
                founders = Founder.objects.filter(company_id = id)
                if not founders:
                    record += ["", "", "", "", "", ""]
                else:
                    founder = founders[0]
                    record += [founder.first_name, founder.middle_name, founder.last_name, founder.citizenship_status, founder.shares_alloted]
                lst.append(tuple(record))
                mx = max(len(founders), len(directors))
                for j in range(1, mx):
                    record = [ "" for i in range(16)]
                    if j < len(directors):
                        director = directors[j]
                        record += [director.name, director.mobile_number, director.citizenship_status, director.current_occupation, director.email, director.is_posses_DSC]
                    else:
                        record += ["", "", "", "", "", ""]
                    record += ["", "", ""]
                    if j < len(founders):
                        founder = founders[j]
                        record += [founder.first_name, founder.middle_name, founder.last_name, founder.citizenship_status, founder.shares_alloted]
                    else:
                        record += ["", "", "", "", "", ""]
                    lst.append(tuple(record))
            
            for i in lst:
                writer.writerow(i)
            
        return response
    
    current_user = request.user
    user_id = current_user.id
    if current_user.profile.is_admin:
        forms = User_form_id.objects.all()
    else:
        com_list = Assignee.objects.filter(user_id = user_id)
        forms = User_form_id.objects.filter(form_id__in = com_list)
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="all_company_data.csv"'
    writer = csv.writer(response)
    
    writer.writerow(['Name1', 'Name2', 'Name3','Name4', 'Type', 'Nature of Activity', 'Business Description', 'Company Address Line 1', 'Company Address Line 2', 'City', 'State', 'Police Station', 'Zipcode', 'Phone', 'Property Type', 'Owner Name', 'Director Name', 'Director Phone', 'Director CityzenShip', 'Director Occupation', 'Director Email', 'DSC Status', 'Auth Share Capital', 'Paid Share Capital', 'Face Value', 'Founder First Name', 'Founder Middle Name', 'Founder Last Name', 'Founder Citizenship', 'Founder Share'])
    
    lst = []
    for form in forms:
        id = form.form_id
        company_len = Company.objects.filter(company_id = id)
        if not company_len:
            continue
        company = Company.objects.get(company_id = id)
        if company.company_type == "1" and company.registeration_progress_level == 1:
            record = [company.name1, company.name2, company.name3, company.name4, "Pvt. Ltd", company.type, company.business_activity_description]
            address = Addresses.objects.get(company_id = id)
            record += [address.address1, address.address2, address.city, address.state, address.nearest_police_station, address.zipcode, address.phone_number, address.property_type, address.owner_name]
            directors = Director.objects.filter(company_id = id)
            if not directors:
                record += ["", "", "", "", "", ""]
            else:
                director = directors[0]
                record += [director.name, director.mobile_number, director.citizenship_status, director.current_occupation, director.email, director.is_posses_DSC]
            share = Share_capital.objects.get(company_id = id)
            record += [share.auth_share_capital, share.paid_share_capital, share.face_value]
            founders = Founder.objects.filter(company_id = id)
            if not founders:
                record += ["", "", "", "", "", ""]
            else:
                founder = founders[0]
                record += [founder.first_name, founder.middle_name, founder.last_name, founder.citizenship_status, founder.shares_alloted]
            lst.append(tuple(record))
            mx = max(len(founders), len(directors))
            for j in range(1, mx):
                record = [ "" for i in range(16)]
                if j < len(directors):
                    director = directors[j]
                    record += [director.name, director.mobile_number, director.citizenship_status, director.current_occupation, director.email, director.is_posses_DSC]
                else:
                    record += ["", "", "", "", "", ""]
                record += ["", "", ""]
                if j < len(founders):
                    founder = founders[j]
                    record += [founder.first_name, founder.middle_name, founder.last_name, founder.citizenship_status, founder.shares_alloted]
                else:
                    record += ["", "", "", "", "", ""]
                lst.append(tuple(record))
    
    for i in lst:
        writer.writerow(i)
    return response


def users(request):
    param = request.GET.get('search-user')
    if param is not None:
        allUsers = User.objects.filter(username__icontains=param)
    else:
        allUsers = User.objects.all()
    context = {'users': allUsers}
    return render(request, 'dashboard/users.html', context)


def create_new_form(request):
    print("inside new form")
    val = uuid.uuid4()
    print(str(val))
    user_created = User_form_id(user = request.user, form_id = val)
    request.user.profile.current_form_id = val
    request.user.save()
    user_created.save()
    query_string =  urlencode({'pk': 1})
    return redirect("/register/?"+query_string)


@csrf_exempt
def change_assignee(request):
    if request.method == "POST":
        emp = request.POST['emp']
        comp_id = request.POST['comp_id']
        user_id = User_form_id.objects.get(form_id = comp_id)
        print(user_id.user.email)
        send_email([{"email":user_id.user.email,"name":"John Doe"}], 15, {"name":str(user_id.user), "employee_name":str(emp)})
        
        emp_user = User.objects.get(username = emp)
        company = Company.objects.get(company_id = comp_id)
        assignee = Assignee(company = company, user = emp_user)
        assignee.save()
    return JsonResponse({"message": "success"})


@csrf_exempt
def change_status(request):
    if request.method == "POST":
        comp_id = request.POST['comp_id']
        status = request.POST['comp_status']
        user_id = User_form_id.objects.get(form_id = comp_id)
        print(user_id.user.email)
        send_email([{"email":user_id.user.email,"name":"John Doe"}], 16, {"name":str(user_id.user), "status":str(status)})
        company = Company.objects.get(company_id = comp_id)
        company.status = status
        company.save()
    return JsonResponse({"message": "success"})

def draft_company(request, id, structure_type):
    print("asdkjahsdjahsd")
    print(id, structure_type)
    request.user.profile.current_form_id = id
    request.user.save()
    if structure_type == "1":
        return redirect("/register/structure/c_corp")
    if structure_type == "2":
        return redirect("/register/structure/llp")
    return redirect("/register/structure/trust")


@csrf_exempt
def delete_user(request):
    if request.method == "POST":
        user_id = request.POST['user_id']
        user = User.objects.get(id = user_id)
        user.delete()
        return JsonResponse({"message": "User deleted"})

@csrf_exempt
def change_status_info(request):    
    if request.method == "POST":
        comp_id = request.POST['comp_id']
        info = request.POST['info']
        company = Company.objects.get(company_id = comp_id)
        company.status_info = info
        company.save()
        return JsonResponse({"message": "Status Updated"})


@csrf_exempt
def exportcsv_llp(request):
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="company_data.csv"'
    writer = csv.writer(response)
    
    writer.writerow(['Name1', 'Name2', 'Type', 'Nature of Activity', 'Business Description', 'Company Address Line 1', 'Company Address Line 2', 'City', 'State', 'Police Station', 'Zipcode', 'Phone', 'Property Type', 'Owner Name', 'Partner Name', 'Partner DOB', 'Partner Citizenship', 'Partner Type', 'Partner Pan/Passport', 'Partner PoB', 'Partner Occupation', 'Partner Education', 'Partner DSC/DIN', 'Partner Profit percentage', 'Partner Permanent Address 1', 'Partner Permanent Address 2', 'Partner Permanent City', 'Partner Permanent State', 'Partner Permanent Zipcode', 'Partner Permanent/Present address same', 'Partner Present Address 1', 'Partner Present Address 2', 'Partner Present City', 'Partner Present State', 'Partner Present Zipcode'])
    
    if request.method == 'POST':
        comp_id = request.POST['comp_id']

        if comp_id != '0':
            company = Company.objects.get(company_id = comp_id)
            id = company.company_id
            
            record = [company.name1, company.name2, "LLP", company.type, company.business_activity_description]
            address = Addresses.objects.get(company_id = id)
            record += [address.address1, address.address2, address.city, address.state, address.nearest_police_station, address.zipcode, address.phone_number, address.property_type, address.owner_name]
            partners = Partner.objects.filter(company_id = id)
            print("record", len(record))
            if not partners:
                record += ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]
            else:
                partner = partners[0]
                record += [partner.name, partner.dob, partner.partner_citz_status, partner.type_of_desg, partner.pan_passport_details, partner.place_of_birth, partner.occupation, partner.education, partner.dsc_no, partner.profit_perc, partner.perm_add1, partner.perm_add2, partner.perm_city, partner.perm_state, partner.perm_zipcode, partner.perm_pres_same, partner.pres_add1, partner.pres_add2, partner.pres_city, partner.pres_state, partner.pres_zipcode]
            writer.writerow(tuple(record))
            for j in range(1, len(partners)):
                record = ["" for i in range(14)]
                partner = partners[j]
                record += [partner.name, partner.dob, partner.partner_citz_status, partner.type_of_desg, partner.pan_passport_details, partner.place_of_birth, partner.occupation, partner.education, partner.dsc_no, partner.profit_perc, partner.perm_add1, partner.perm_add2, partner.perm_city, partner.perm_state, partner.perm_zipcode, partner.perm_pres_same, partner.pres_add1, partner.pres_add2, partner.pres_city, partner.pres_state, partner.pres_zipcode]
                writer.writerow(tuple(record))
            
        else: #Filtered records download
            current_user = request.user
            user_id = current_user.id
            if current_user.profile.is_employee:
                com_list = Assignee.objects.filter(user_id = user_id)
                forms = User_form_id.objects.filter(form_id__in = com_list)
            else:
                forms = User_form_id.objects.all()
            query_condition = Q(company_id__in = forms)
            
            com_status = request.POST["comp_status"]
            payment = request.POST["comp_payment"]
            
            if com_status != "0":
                query_condition &= Q(status = com_status)

            if payment != "2":
                query_condition &= Q(payment_status = payment)
        
            companies = Company.objects.filter(query_condition, registeration_progress_level = 1, company_type = "2")
            lst = []
            for company in companies:
                id = company.company_id
                record = [company.name1, company.name2, "LLP", company.type, company.business_activity_description]
                address = Addresses.objects.get(company_id = id)
                record += [address.address1, address.address2, address.city, address.state, address.nearest_police_station, address.zipcode, address.phone_number, address.property_type, address.owner_name]
                partners = Partner.objects.filter(company_id = id)
                
                if not partners:
                    record += ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]
                else:
                    partner = partners[0]
                    record += [partner.name, partner.dob, partner.partner_citz_status, partner.type_of_desg, partner.pan_passport_details, partner.place_of_birth, partner.occupation, partner.education, partner.dsc_no, partner.profit_perc, partner.perm_add1, partner.perm_add2, partner.perm_city, partner.perm_state, partner.perm_zipcode, partner.perm_pres_same, partner.pres_add1, partner.pres_add2, partner.pres_city, partner.pres_state, partner.pres_zipcode]
                lst.append(tuple(record))
                for j in range(1, len(partners)):
                    record = ["" for i in range(14)]
                    partner = partners[j]
                    record += [partner.name, partner.dob, partner.partner_citz_status, partner.type_of_desg, partner.pan_passport_details, partner.place_of_birth, partner.occupation, partner.education, partner.dsc_no, partner.profit_perc, partner.perm_add1, partner.perm_add2, partner.perm_city, partner.perm_state, partner.perm_zipcode, partner.perm_pres_same, partner.pres_add1, partner.pres_add2, partner.pres_city, partner.pres_state, partner.pres_zipcode]
                    lst.append(tuple(record))
            
            for i in lst:
                writer.writerow(i)
            
        return response
    
    current_user = request.user
    user_id = current_user.id
    
    if current_user.profile.is_admin:
        forms = User_form_id.objects.all()
    else:
        com_list = Assignee.objects.filter(user_id = user_id)
        forms = User_form_id.objects.filter(form_id__in = com_list)
    
    lst = []
    for form in forms:
        id = form.form_id
        company_len = Company.objects.filter(company_id = id)
        if not company_len:
            continue
        company = Company.objects.get(company_id = id)
        if company.company_type == "2" and company.registeration_progress_level == 1:
            record = [company.name1, company.name2, "LLP", company.type, company.business_activity_description]
            address = Addresses.objects.get(company_id = id)
            record += [address.address1, address.address2, address.city, address.state, address.nearest_police_station, address.zipcode, address.phone_number, address.property_type, address.owner_name]
            partners = Partner.objects.filter(company_id = id)
            
            if not partners:
                record += ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]
            else:
                partner = partners[0]
                record += [partner.name, partner.dob, partner.partner_citz_status, partner.type_of_desg, partner.pan_passport_details, partner.place_of_birth, partner.occupation, partner.education, partner.dsc_no, partner.profit_perc, partner.perm_add1, partner.perm_add2, partner.perm_city, partner.perm_state, partner.perm_zipcode, partner.perm_pres_same, partner.pres_add1, partner.pres_add2, partner.pres_city, partner.pres_state, partner.pres_zipcode]
            lst.append(tuple(record))
            for j in range(1, len(partners)):
                record = ["" for i in range(14)]
                partner = partners[j]
                record += [partner.name, partner.dob, partner.partner_citz_status, partner.type_of_desg, partner.pan_passport_details, partner.place_of_birth, partner.occupation, partner.education, partner.dsc_no, partner.profit_perc, partner.perm_add1, partner.perm_add2, partner.perm_city, partner.perm_state, partner.perm_zipcode, partner.perm_pres_same, partner.pres_add1, partner.pres_add2, partner.pres_city, partner.pres_state, partner.pres_zipcode]
                lst.append(tuple(record))
    
    for i in lst:
        writer.writerow(i)
    return response

@csrf_exempt
def exportcsv_trust(request):
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="company_data.csv"'
    writer = csv.writer(response)
    
    writer.writerow(['Name', 'Type', 'Business Description', 'Company Address Line 1', 'Company Address Line 2', 'City', 'State', 'Police Station', 'Zipcode', 'Phone', 'Property Type', 'Owner Name', 'Trustee Name', 'Trustee Address 1', 'Trustee Address 2', 'Trustee City', 'Trustee State', 'Trustee Zipcode', 'Settler Name', 'Settler Address 1', 'Settler Address 2', 'Settler City', 'Settler State', 'Settler Zipcode'])
    
    if request.method == 'POST':
        comp_id = request.POST['comp_id']

        if comp_id != '0':
            company = Company.objects.get(company_id = comp_id)
            id = company.company_id
            
            record = [company.name1, "Trust/Fund", company.business_activity_description]
            address = Addresses.objects.get(company_id = id)
            record += [address.address1, address.address2, address.city, address.state, address.nearest_police_station, address.zipcode, address.phone_number, address.property_type, address.owner_name]
            trust = Trust_details.objects.get(company_id = company)
            record += [trust.truste_name, trust.truste_address1, trust.truste_address2, trust.truste_city, trust.truste_state, trust.truste_zipcode, trust.settler_name, trust.settler_address1, trust.settler_address2, trust.settler_city, trust.settler_state, trust.settler_zipcode]
            
            writer.writerow(tuple(record))
            
        else: #Filtered records download
            current_user = request.user
            user_id = current_user.id
            if current_user.profile.is_employee:
                com_list = Assignee.objects.filter(user_id = user_id)
                forms = User_form_id.objects.filter(form_id__in = com_list)
            else:
                forms = User_form_id.objects.all()
                
            query_condition = Q(company_id__in = forms)
            
            com_status = request.POST["comp_status"]
            payment = request.POST["comp_payment"]
            
            if com_status != "0":
                query_condition &= Q(status = com_status)

            if payment != "2":
                query_condition &= Q(payment_status = payment)
        
            companies = Company.objects.filter(query_condition, registeration_progress_level = 1, company_type = "3")
            lst = []
            for company in companies:
                id = company.company_id
                record = [company.name1, "Trust/Fund", company.business_activity_description]
                address = Addresses.objects.get(company_id = id)
                record += [address.address1, address.address2, address.city, address.state, address.nearest_police_station, address.zipcode, address.phone_number, address.property_type, address.owner_name]
                trust = Trust_details.objects.get(company_id = company)
                record += [trust.truste_name, trust.truste_address1, trust.truste_address2, trust.truste_city, trust.truste_state, trust.truste_zipcode, trust.settler_name, trust.settler_address1, trust.settler_address2, trust.settler_city, trust.settler_state, trust.settler_zipcode]
                lst.append(tuple(record))
            
            for i in lst:
                writer.writerow(i)
            
        return response
    
    current_user = request.user
    user_id = current_user.id
    
    if current_user.profile.is_admin:
        forms = User_form_id.objects.all()
    else:
        com_list = Assignee.objects.filter(user_id = user_id)
        forms = User_form_id.objects.filter(form_id__in = com_list)
    
    lst = []
    for form in forms:
        id = form.form_id
        company_len = Company.objects.filter(company_id = id)
        if not company_len:
            continue
        company = Company.objects.get(company_id = id)
        if company.company_type == "3" and company.registeration_progress_level == 1:
            record = [company.name1, "Trust/Fund", company.business_activity_description]
            address = Addresses.objects.get(company_id = id)
            record += [address.address1, address.address2, address.city, address.state, address.nearest_police_station, address.zipcode, address.phone_number, address.property_type, address.owner_name]
            trust = Trust_details.objects.get(company_id = company)
            record += [trust.truste_name, trust.truste_address1, trust.truste_address2, trust.truste_city, trust.truste_state, trust.truste_zipcode, trust.settler_name, trust.settler_address1, trust.settler_address2, trust.settler_city, trust.settler_state, trust.settler_zipcode]
            lst.append(tuple(record))
    
    for i in lst:
        writer.writerow(i)
    return response

def test_ex(request):
    return render(request, 'dashboard/token_page.html')

