from django.contrib import admin
from django.urls import path, include
from django.contrib.auth.views import LogoutView
from django.views.generic.base import RedirectView
from . import views

favicon_view = RedirectView.as_view(url='/static/favicon.ico', permanent=True)

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", views.index, name="first"),
    path("guides/", views.guides, name="guides"),
    path('register/', include('registration_app.urls')),
    path('dashboard/', include('dashboard.urls')),
    path('accounts/', include('allauth.urls')),
    path('logout', LogoutView.as_view()),
    path('favicon.ico', favicon_view),
]