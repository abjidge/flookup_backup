from django.shortcuts import render, redirect
import csv
import  os
from django.templatetags.static import static
import io
def index(request):
    return render(request, 'first_page.html')

def guides(request):
    
    items = []
    cwd = os.getcwd()
    with io.open(os.path.join(cwd, "question.csv"), "r", encoding="utf-8") as csvfile:
    # with open(os.path.join(cwd, "question.csv")) as csvfile:    
        csvReader = csv.reader(csvfile)    
        for row in csvReader:        
            items.append([row[0], row[1]])        
    return render(request, 'guides.html', {"context":items[1:]})