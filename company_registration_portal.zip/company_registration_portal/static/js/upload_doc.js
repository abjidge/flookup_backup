function document_upload(){
    arr = ["dir_passphoto1[]", "dir_pancard1[]", "dir_prooff1[]", "dir_proofrf1[]","concern_letter[]", "own_sale_deed", "own_noc", "rent_agree", "rent_reciept", "rent_noc", "prop_proof"]
    values = {}
    var datas = new FormData();
    $.each(arr, function(i, item){
        console.log($("input[name = '"+item+"'"))
        x = $("input[name = '"+item+"'")[0].files
        if (i < 5 && x.length){
            $.each(x, function(a, it){
                datas.append(item, it)
            })
        }
        else{
            if (x.length){
                datas.append(item, x[0])
            }
        }
    })
    prop_owner = $("select[name = 'property_owner' ").val()
    datas.append("property_owner", prop_owner)

    dir_proofr1 = $('select[name ="dir_proofr1"').val()
    datas.append("dir_proofr1", dir_proofr1)

    dir_proof1 = $("select[name = 'dir_proof1'").val()
    datas.append("dir_proof1", dir_proof1)
    
    console.log(datas)
    for (var pair of datas.entries()) {
        if (Array.isArray(pair[1])){
            console.log(pair[0]+ ', ' + pair[1][0]); 
        }
        else{
            console.log(pair[0]+ ', ' + pair[1]); 
        }
    }
    $.ajax({
        url:"/register/company_documents",
        type:"POST",
        enctype: 'multipart/form-data',
        processData: false,
        contentType: false,
        cache: false,
        data:datas,
        success: function(data){
            $.each(data.arr, function(i, item){
                $.ajax({
                    type:"POST",
                    data:{"link": item},
                    url:"/register/delete_files"
                })
            })
        }
    })

}

function document_form_check(){
    var arr = ['director_photo', 'director_pan', 'director_proof_indentity', 'director_proof_residence', 'own_sale_deed', 'own_noc', 'rent_agree', 'rent_reciept', 'rent_noc', 'prop_proof',"concern_letter"]
    
    var field = ["dir_passphoto1_id", "dir_pancard1_id", "dir_prooff1_id", "dir_proofrf1_id", "own_sale_deed_id", "own_noc_id", "rent_agree_id", "rent_reciept_id", "rent_noc_id", "prop_proof_id", "concern_letter_id"]
    var rese = []
    $.ajax({
        url:"/register/company_documents",
        type:"GET",
        success: function(data){
            object_values = data["context"][0]
            object_actual = data["work"][0]
            if (object_actual){
                for (i = 0; i < field.length; i++){
                    // $("#"+field[i]+"").text(object_values[arr[i]])
                    rese.push(object_actual[arr[i]])
                }
                temp = []
                for (i = 0; i < arr.length; i++){
                    temp.push(i)
                }
                $.each(temp, function(i,it){
                    // ajax to get the open link
                    var res = rese[i];
                    var xyz = [];
                    for (iz = 0; iz < res.length; iz++){
                        xyz.push(iz)
                    }
                    console.log(xyz, res)
                    var change_htm = "";
                    $.each(xyz, function(j, item){
                        if (res[item] && res[item].length > 15){
                            $.ajax({
                                type:"POST",
                                url : "/register/open_files",
                                data : {"link" : res[item]},
                                success: function(data){
                                    console.log(res[item], data, field[i])
                                    var index_re = res[item].indexOf("+_+")
                                    var temp_file_name = res[item].replaceAll(" ", "_._")
                                    change_htm += '<a href = "'+data+'"> '+res[item].slice(index_re + 3)+'</a><a class = "btn" onclick = delete_file_doc("'+temp_file_name+'","'+field[i]+'",this)>Delete</a>'
                                    $("#"+field[i]+"").html(change_htm)
                                    
                                }
                            })
                        }
                    })
                })
            }
        }
    })
    
}

function delete_file_doc(temp, id, el){

    var element = el;
    // $("#"+id).text("")
    // $("#"+id).next().remove()
    $(element).prev().remove();
    $(element).remove();

    $.ajax({
        type:"GET",
        data:{"id":temp, "file_name":id},
        url:"/register/delete_files_document",
        success:function(data){
        }
    })
 }

// 
