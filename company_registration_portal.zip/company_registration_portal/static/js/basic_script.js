
// dynamic data validation using jquery
// name = "cmp_address1"
email_reg = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
phone_no = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/
address = /^[a-z0-9\s,'--.@!#$%^&8()/_]*$/i
name_reg = /^[a-zA-Z\s]*$/
number_check = /^\d+$/
alpha_num_check = /^[a-zA-Z0-9]*$/
pan_check = /([A-Z]){5}([0-9]){4}([A-Z]){1}$/
cin_check = /^([L|U]{1})([0-9]{5})([A-Za-z]{2})([0-9]{4})([A-Za-z]{3})([0-9]{6})$/

check = [1,1,1,1,1,1,1,1]
$(document).on("input",".address_check", function(){

    if (address.test($(this).val()))
    {
        $(this).css("color", "black")
        check[0] = 1
    }
    else{
        $(this).css("color", "red")
        check[0] = 0
    }
})
$(document).on("input",".name_check", function(){

    if (name_reg.test($(this).val()))
    {
        $(this).css("color", "black")
        check[1] = 1
    }
    else{
        $(this).css("color", "red")
        check[1] = 0
    }
})
$(document).on("input",".phone_no_check", function(){

    if (phone_no.test($(this).val()))
    {
        $(this).css("color", "black")
        
        check[2] = 1
    }
    else{
        $(this).css("color", "red")
        
        check[2] = 0
    
    }
})
$(document).on("input",".number_check", function(){

    if (number_check.test($(this).val()))
    {
        $(this).css("color", "black")
        
        check[3] = 1

    }
    else{
        $(this).css("color", "red")
        
        check[3] = 0
    
    }
})
$(document).on("input",".email_check", function(){

    if (email_reg.test($(this).val()))
    {
        $(this).css("color", "black")
        
        check[4] = 1
    }
    else{
        $(this).css("color", "red")
        
        check[4] = 0
    }
})
$(document).on("input", ".alpha_num_check",function(){

    if (alpha_num_check.test($(this).val()))
    {
        $(this).css("color", "black")
        
        check[5] = 1
    }
    else{
        $(this).css("color", "red")
        
        check[5] = 0
    
    }
})
$(document).on("input", ".pan_check",function(){

    if (pan_check.test($(this).val()))
    {
        $(this).css("color", "black")
        
        check[6] = 1
    }
    else{
        $(this).css("color", "red")
        
        check[6] = 0
    
    }
})
$(document).on("input", ".cin_check",function(){

    if (cin_check.test($(this).val()))
    {
        $(this).css("color", "black")
        
        check[7] = 1
    }
    else{
        $(this).css("color", "red")
        
        check[7] = 0
    
    }
})
// name_check
// phone_no_check
// number_check
// address_check
// email_check
// alpha_num_check

$(document).ready(update_data)
$(document).ready(updateprog)
$(document).ready(nature_update)


let flag = true
let flag_document = true
let next_btn = document.getElementById("next_btn");
let back_btn = document.getElementById("back_btn");
var steps = document.querySelectorAll(".step");
let form_step = document.querySelectorAll(".form-step");
let active = 1;
var structure_type = $("#struct_change").val()
let x_dir = 1;
$(document).ready(function(){
    arr = ["","Director ", "Partner ",""]
    $("#dir_partner_display").text(arr[parseInt($("#struct_change").val())])
})

$(document).on("change", ".file_director", function(){
    var files = $(this)[0].files
    if (active == 6 && structure_type == "1"){
        x_dir = $(".form-five div").length - 2
    }
    else if (active == 5 && structure_type == "2"){
        x_dir = $(".partner_details_num").length
    }
    if (x_dir != files.length){
        alert("select " + x_dir.toString() + " Files")
        $(this).val("")
    }
    change_in_input()
})

next_btn.addEventListener("click", function(){
    change_in_input()
    if (active == 4 && $("#struct_change").val() == "2"){
        var flag = 1;
        $.each($("select[name = 'partner1_desg']"), function(){
            if ($(this).val() != "Individual"){flag = 0}
        })
        if (flag == 0){
            $("#concern_letter_div").removeClass("dp")
        }
        else{
            $("#concern_letter_div").addClass("dp")
            $("input[name='concern_letter']").val("")
        }
    }
    let sm = 0
    for (j = 0; j < check.length; j++){
        sm += check[j]
    }
    let share_total_check = true;
    if (active == 1 && structure_type != "3"){
        document_form_check()
        change_in_input()
    }
    if (active == 1 && $("input[name='c_name1']").val().length == 0) {
        alert("Company_name is required")
        return
    }
    if (active == 5 && structure_type == "2"){
        document_upload()
        // if ($(".mandatory_list_ul li").length){
        //     return
        // }
    }
    if (active == 4 && structure_type == "1"){
        curr = 0
        x = $("input[name='shares1']")
        $.each(x, function(){
            curr += parseInt($(this).val())
        })
        need = $("input[name='paid_share_capital'").val()/$("input[name='face_value'").val()
        need = parseInt(need)
        if (need != curr){
            share_total_check = false
            alert("sum of total shares should be equal to" + need.toString())
            $.each(x, function(){
                $(this).css("color","red")
            })
        }
        else{
            $.each(x, function(){
                $(this).css("color","black")
            })
            share_total_check = true;
        }
    }
    console.log(sm, share_total_check)
    if (sm == check.length && share_total_check){
        active++;

        if (active > steps.length){
            if (structure_type != "3"){
                document_upload()
                alert("Document upload Successful")
            }
            else{
                ajax_query()
            }
        
        if ($(".mandatory_list_ul li").length == 0){
            values = {"prog":1}
            $("#next_btn").prop("disabled", false);
            $("#next_btn").css("background-color", "black")
            $("#next_btn").text("Submit");

        }
        else{
            $("#next_btn").prop("disabled", true);
            values = {"prog":0}
            $("#next_btn").css("background-color", "silver")
            $("#next_btn").text("Submit");
        }
        $.ajax({
            url:"/register/prog_level",
            type:"POST",
            data: values,
            success:function(){
            }
        })
            if ($("#next_btn").prop("disabled") == false)
            {
                location.href = "/dashboard"
            }
            active = steps.length;
        }
        updateprog();
        ajax_query()
    }


})

back_btn.addEventListener("click", function(){
    change_in_input()
    let sm = 0
    for (j = 0; j < check.length; j++){
        sm += check[j]
    }
    if (sm == check.length){
        active--;
        if (active < 1){
        active = 1;
        }
        updateprog();
        ajax_query();
    }
})
function updateprog(){
    text_comp = ["", "Company", "Partnership", "Trust/Fund"]
    text_company_in = text_comp[parseInt($("#struct_change").val())]
    $("#company_in_desc").text(text_company_in)

    steps.forEach((step, i) =>{
    if (i+1 == active){
        step.classList.add("active")
        form_step[i].classList.add("dp_active")
    }
    else{
        form_step[i].classList.remove("dp_active")
        form_step[i].classList.add("dp")
        step.classList.remove("active")
    }
    $(window).scrollTop(0); // scroll to the top
    })
    side_panel = $(".side_panel")
    if (active == 3){
        side_panel.removeClass("dp")
    }
    else{
        side_panel.addClass("dp")
    }
    side_nominee = $(".side_nominee")
    if (active == 5){
        side_nominee.removeClass("dp")
    }
    else{
        side_nominee.addClass("dp")
    }
    structure_type = $("#struct_change").val()
    side_panel_trustee = $(".side_panel_trustee")
    // console.log("here")
    // console.log(structure_type)
    // console.log(active)
    if (active == 4 && structure_type == "3"){
        side_panel_trustee.removeClass("dp")
    }
    else{
        side_panel_trustee.addClass("dp")
    }
    $("#next_btn").css("background-color", "black")
    $("#next_btn").prop("disabled", false);
    $("#next_btn").text("Continue");


    // script for dashboard btn
    dashboard_btn = $("#dashboard_btn")
    number_of_steps = $(".step").length
    if (active == number_of_steps){
        // alert("right here")
        dashboard_btn.removeClass("dp")
        if ($(".mandatory_list_ul li").length == 0){
            values = {"prog":1}
            $("#next_btn").prop("disabled", false);
            $("#next_btn").css("background-color", "black")
            $("#next_btn").text("Submit");

        }
        else{
            $("#next_btn").prop("disabled", true);
            values = {"prog":0}
            $("#next_btn").css("background-color", "silver")
            $("#next_btn").text("Submit");
        }
        $.ajax({
            url:"/register/prog_level",
            type:"POST",
            data: values,
            success:function(){

            }
        })
        
    }
    else{
        dashboard_btn.addClass("dp")
    }

    // script for checking the registration progress level
    // if ($("#struct_change").val() == "1"){
    //     if (active == 6){
    //         $("#next_btn").addClass("dp");
    //     }
    //     else{
    //         $("#next_btn").removeClass("dp");
    //     }
    // }
    // var mandat = $("#struct_change").val()
    // mandat_obj = $(".mandatory_list")
    // change_factor = 0
    // if (mandat == "1"){
    //     change_factor = 6
    // }
    // else if (mandat == "2"){
    //     change_factor = 5
    // }
    // else{
    //     change_factor = 4
    // }
    // console.log(active, change_factor,mandat,"right here")
    // if (active == change_factor){
    //     mandat_obj.removeClass("dp")
    // }
    // else{
    //     mandat_obj.addClass("dp")
    // }
    if (flag_document && structure_type != "3"){
        document_form_check()
        flag_document = false
    }
}


// <!-- script for adding a new founder to the form-->

names = []
f_names = []
wrapper_founder = $("#add_a_founder");
fieldHTML = '<div><h3 class ="share_holder_number">Share</h3><label>About You</label> <p class="p-desc">Enter your First name and last name according to the goverment ID.</p> <input type="text" name="first_name" placeholder="First Name" class = "name_check"> <input type="text" name="middle_name" placeholder="Middle Name" class = "name_check"> <input type="text" name="last_name" placeholder="Last Name" class = "name_check"> <br> <label>Citizenship Status</label> <p class = "p-desc">( Definitions of NRI, Foreign citizen )</p> <select name="share_holder_nationality"> <option value="indian">Indian</option> <option value="afghan">Afghan</option> <option value="albanian">Albanian</option> <option value="algerian">Algerian</option> <option value="american">American</option> <option value="andorran">Andorran</option> <option value="angolan">Angolan</option> <option value="antiguans">Antiguans</option> <option value="argentinean">Argentinean</option> <option value="armenian">Armenian</option> <option value="australian">Australian</option> <option value="austrian">Austrian</option> <option value="azerbaijani">Azerbaijani</option> <option value="bahamian">Bahamian</option> <option value="bahraini">Bahraini</option> <option value="bangladeshi">Bangladeshi</option> <option value="barbadian">Barbadian</option> <option value="barbudans">Barbudans</option> <option value="batswana">Batswana</option> <option value="belarusian">Belarusian</option> <option value="belgian">Belgian</option> <option value="belizean">Belizean</option> <option value="beninese">Beninese</option> <option value="bhutanese">Bhutanese</option> <option value="bolivian">Bolivian</option> <option value="bosnian">Bosnian</option> <option value="brazilian">Brazilian</option> <option value="british">British</option> <option value="bruneian">Bruneian</option> <option value="bulgarian">Bulgarian</option> <option value="burkinabe">Burkinabe</option> <option value="burmese">Burmese</option> <option value="burundian">Burundian</option> <option value="cambodian">Cambodian</option> <option value="cameroonian">Cameroonian</option> <option value="canadian">Canadian</option> <option value="cape verdean">Cape Verdean</option> <option value="central african">Central African</option> <option value="chadian">Chadian</option> <option value="chilean">Chilean</option> <option value="chinese">Chinese</option> <option value="colombian">Colombian</option> <option value="comoran">Comoran</option> <option value="congolese">Congolese</option> <option value="costa rican">Costa Rican</option> <option value="croatian">Croatian</option> <option value="cuban">Cuban</option> <option value="cypriot">Cypriot</option> <option value="czech">Czech</option> <option value="danish">Danish</option> <option value="djibouti">Djibouti</option> <option value="dominican">Dominican</option> <option value="dutch">Dutch</option> <option value="east timorese">East Timorese</option> <option value="ecuadorean">Ecuadorean</option> <option value="egyptian">Egyptian</option> <option value="emirian">Emirian</option> <option value="equatorial guinean">Equatorial Guinean</option> <option value="eritrean">Eritrean</option> <option value="estonian">Estonian</option> <option value="ethiopian">Ethiopian</option> <option value="fijian">Fijian</option> <option value="filipino">Filipino</option> <option value="finnish">Finnish</option> <option value="french">French</option> <option value="gabonese">Gabonese</option> <option value="gambian">Gambian</option> <option value="georgian">Georgian</option> <option value="german">German</option> <option value="ghanaian">Ghanaian</option> <option value="greek">Greek</option> <option value="grenadian">Grenadian</option> <option value="guatemalan">Guatemalan</option> <option value="guinea-bissauan">Guinea-Bissauan</option> <option value="guinean">Guinean</option> <option value="guyanese">Guyanese</option> <option value="haitian">Haitian</option> <option value="herzegovinian">Herzegovinian</option> <option value="honduran">Honduran</option> <option value="hungarian">Hungarian</option> <option value="icelander">Icelander</option> <option value="indonesian">Indonesian</option> <option value="iranian">Iranian</option> <option value="iraqi">Iraqi</option> <option value="irish">Irish</option> <option value="israeli">Israeli</option> <option value="italian">Italian</option> <option value="ivorian">Ivorian</option> <option value="jamaican">Jamaican</option> <option value="japanese">Japanese</option> <option value="jordanian">Jordanian</option> <option value="kazakhstani">Kazakhstani</option> <option value="kenyan">Kenyan</option> <option value="kittian and nevisian">Kittian and Nevisian</option> <option value="kuwaiti">Kuwaiti</option> <option value="kyrgyz">Kyrgyz</option> <option value="laotian">Laotian</option> <option value="latvian">Latvian</option> <option value="lebanese">Lebanese</option> <option value="liberian">Liberian</option> <option value="libyan">Libyan</option> <option value="liechtensteiner">Liechtensteiner</option> <option value="lithuanian">Lithuanian</option> <option value="luxembourger">Luxembourger</option> <option value="macedonian">Macedonian</option> <option value="malagasy">Malagasy</option> <option value="malawian">Malawian</option> <option value="malaysian">Malaysian</option> <option value="maldivan">Maldivan</option> <option value="malian">Malian</option> <option value="maltese">Maltese</option> <option value="marshallese">Marshallese</option> <option value="mauritanian">Mauritanian</option> <option value="mauritian">Mauritian</option> <option value="mexican">Mexican</option> <option value="micronesian">Micronesian</option> <option value="moldovan">Moldovan</option> <option value="monacan">Monacan</option> <option value="mongolian">Mongolian</option> <option value="moroccan">Moroccan</option> <option value="mosotho">Mosotho</option> <option value="motswana">Motswana</option> <option value="mozambican">Mozambican</option> <option value="namibian">Namibian</option> <option value="nauruan">Nauruan</option> <option value="nepalese">Nepalese</option> <option value="new zealander">New Zealander</option> <option value="ni-vanuatu">Ni-Vanuatu</option> <option value="nicaraguan">Nicaraguan</option> <option value="nigerien">Nigerien</option> <option value="north korean">North Korean</option> <option value="northern irish">Northern Irish</option> <option value="norwegian">Norwegian</option> <option value="omani">Omani</option> <option value="pakistani">Pakistani</option> <option value="palauan">Palauan</option> <option value="panamanian">Panamanian</option> <option value="papua new guinean">Papua New Guinean</option> <option value="paraguayan">Paraguayan</option> <option value="peruvian">Peruvian</option> <option value="polish">Polish</option> <option value="portuguese">Portuguese</option> <option value="qatari">Qatari</option> <option value="romanian">Romanian</option> <option value="russian">Russian</option> <option value="rwandan">Rwandan</option> <option value="saint lucian">Saint Lucian</option> <option value="salvadoran">Salvadoran</option> <option value="samoan">Samoan</option> <option value="san marinese">San Marinese</option> <option value="sao tomean">Sao Tomean</option> <option value="saudi">Saudi</option> <option value="scottish">Scottish</option> <option value="senegalese">Senegalese</option> <option value="serbian">Serbian</option> <option value="seychellois">Seychellois</option> <option value="sierra leonean">Sierra Leonean</option> <option value="singaporean">Singaporean</option> <option value="slovakian">Slovakian</option> <option value="slovenian">Slovenian</option> <option value="solomon islander">Solomon Islander</option> <option value="somali">Somali</option> <option value="south african">South African</option> <option value="south korean">South Korean</option> <option value="spanish">Spanish</option> <option value="sri lankan">Sri Lankan</option> <option value="sudanese">Sudanese</option> <option value="surinamer">Surinamer</option> <option value="swazi">Swazi</option> <option value="swedish">Swedish</option> <option value="swiss">Swiss</option> <option value="syrian">Syrian</option> <option value="taiwanese">Taiwanese</option> <option value="tajik">Tajik</option> <option value="tanzanian">Tanzanian</option> <option value="thai">Thai</option> <option value="togolese">Togolese</option> <option value="tongan">Tongan</option> <option value="trinidadian or tobagonian">Trinidadian or Tobagonian</option> <option value="tunisian">Tunisian</option> <option value="turkish">Turkish</option> <option value="tuvaluan">Tuvaluan</option> <option value="ugandan">Ugandan</option> <option value="ukrainian">Ukrainian</option> <option value="uruguayan">Uruguayan</option> <option value="uzbekistani">Uzbekistani</option> <option value="venezuelan">Venezuelan</option> <option value="vietnamese">Vietnamese</option> <option value="welsh">Welsh</option> <option value="yemenite">Yemenite</option> <option value="zambian">Zambian</option> <option value="zimbabwean">Zimbabwean</option>  </select> <br> <label for = "shares1">Shares Alloted </label> <p class = "p-desc">( holding (based on no of shares to total paid up capital) ) </p> <input type="number" name = "shares1" min="0" oninput="validity.valid||(value="");"> <br> <br> <br> <a class = "btn btn-primay remove_button">Remove</a> <br><br></div>';
$("#add_a_founder").click(function(){
    $(fieldHTML).insertBefore(wrapper_founder)
    share_holder_number()

});
$(".form-four").on('click', '.remove_button', function(e){
    e.preventDefault();
    $(this).parent('div').remove(); //Remove field html
    change_in_input()
    share_holder_number()
});

// script for adding shareholder numbering
function share_holder_number(){
    var iter_share = 1
    $.each($(".share_holder_number"), function(){
        $(this).text("Shareholder Details #"+iter_share.toString())
        iter_share += 1
    })
}



// <!-- script for adding name of the owner-->

$("#own_rented").change(function(){ 
    thevalue = $("#own_rented").val();
    if (thevalue == "Rented"){
    $("#owner_name").addClass("dp_active")
    $("#owner_name").removeClass("dp")

    }
    else{
    $("#owner_name").removeClass("dp_active")
    $("#owner_name").addClass("dp")
    }
}); 


// <!-- script for changing the structure -->

state = $("#struct_change").val();
$("#struct_change").change(function(){
    actual = $("#struct_change").val();
    box = $(".struct_popup")
    box.removeClass("dp")
    box.addClass("dp_active")
    chg = $("#make_change")
    no_chg = $("#no_change")
    chg.click(function(){
        value = "c_corp"
        if (actual == "1"){
            value = "/register/structure/c_corp"
        }
        else if (actual == "2"){
            value = "/register/structure/llp"
        }
        else{
            value = "/register/structure/trust"
        }
        location.href = value ;
        timer_arr = [0]
        $.each(timer_arr, function(xyz, index){
            clear_data()
        })
        box.removeClass("dp_active")
        box.addClass("dp")
    })
    no_chg.click(function(){
        $("#struct_change").val(state);
        box.removeClass("dp_active")
        box.addClass("dp")
    })
});


// <!-- script for finding all the id's of the input element of the forms

$(document).ready(function ()
{
});


// <!-- script for selecting the property type-->

$("#property_owner").change(function(){ 
    thevalue = $("#property_owner").val();
    first  = $("#property_owned")
    second = $("#property_rented")
    if (thevalue == "Rented by Director/Shareholder"){
        second.removeClass("dp")
        first.addClass("dp");
        var temp = [0]
        
    }
    else{
        first.removeClass("dp");
        second.addClass("dp");
    }
    change_in_input()
    alert("changed")
    $.each(temp, function(i, item){
        $.ajax({
            url: "/register/delete_property_owner",
            type:"GET",
            success:function(data){
                field = ["own_sale_deed_id", "own_noc_id", "rent_agree_id", "rent_reciept_id", "rent_noc_id"]
                $.each(data.arr, function(i, item){
                    $("#"+field[i]+"").attr("href", "")
                    $("#"+field[i]+"").text(" ")                        
                })

            }

        })
    })
}); 


// <!-- script for Adding a new Partner -->

wrapper = $("#add_a_partner")
fieldhtml = ' <div><h3 class = "partner_details_num"></h3><label for="partner1_desg">Type of designated Partner</label> <select name="partner1_desg" class = "partner_desg"> <option value="Individual">Individual</option> <option value="Body Corporate ( without DIN)">Body Corporate ( without DIN )</option> <option value="Body Corporate ( with DIN )">Body Corporate ( with DIN )</option> </select> <div class ="norm_partner1" > <label for="partner1_name">Name:</label> <input type="text" name = "partner1_name" id = "partner1_name" class = "name_check" placeholder = "Partner Name"> <label for="partner1_dob">Date of Birth :</label> <input type="date" name = "partner1_dob" id = "partner1_dob" placeholder = "Partner dob"> <label for="partner1_ciz_status">Citizenship Satus :</label> <select name="partner1_ciz_status" id="partner1_ciz_status" > <option value="Indian">Indian</option> <option value="NRI">NRI</option> </select> <label for="have_a_pan">Do you have a Pan ?</label> <select name="have_a_pan" class ="have_pan"> <option value="Yes">Yes</option> <option value="No">No</option> </select><label for="partner1_pan">PAN / Passport Details:</label > <input type="text" name = "partner1_pan" id = "partner1_pan" class = "alpha_num_check" placeholder = "Partner pan"><label for="partner1_pob">Place of Birth:</label> <input type="text" name = "partner1_pob" id = "partner1_pob" class = "name_check" placeholder = "Partner place of birth"><div><label>Permanent Address</label> <input type="text" name = "partner1_permadd1" id = "partner1_permadd1" placeholder="Permanent Address line 1" class = "address_check"> <br> <input type="text" name = "partner1_permadd2" id = "partner1_permadd2" placeholder="permanent Address line 2" class = "address_check"> <br> <input type="text" name = "partner1_permcity" id = "partner1_permcity" placeholder="permanent City" class = "name_check"> <br> <select name="partner1_permstate" id="partner1_permstate"> <option value="Andhra Pradesh">Andhra Pradesh</option> <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option> <option value="Arunachal Pradesh">Arunachal Pradesh</option> <option value="Assam">Assam</option> <option value="Bihar">Bihar</option> <option value="Chandigarh">Chandigarh</option> <option value="Chhattisgarh">Chhattisgarh</option> <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option> <option value="Daman and Diu">Daman and Diu</option> <option value="Delhi">Delhi</option> <option value="Lakshadweep">Lakshadweep</option> <option value="Puducherry">Puducherry</option> <option value="Goa">Goa</option> <option value="Gujarat">Gujarat</option> <option value="Haryana">Haryana</option> <option value="Himachal Pradesh">Himachal Pradesh</option> <option value="Jammu and Kashmir">Jammu and Kashmir</option> <option value="Jharkhand">Jharkhand</option> <option value="Karnataka">Karnataka</option> <option value="Kerala">Kerala</option> <option value="Madhya Pradesh">Madhya Pradesh</option> <option value="Maharashtra">Maharashtra</option> <option value="Manipur">Manipur</option> <option value="Meghalaya">Meghalaya</option> <option value="Mizoram">Mizoram</option> <option value="Nagaland">Nagaland</option> <option value="Odisha">Odisha</option> <option value="Punjab">Punjab</option> <option value="Rajasthan">Rajasthan</option> <option value="Sikkim">Sikkim</option> <option value="Tamil Nadu">Tamil Nadu</option> <option value="Telangana">Telangana</option> <option value="Tripura">Tripura</option> <option value="Uttar Pradesh">Uttar Pradesh</option> <option value="Uttarakhand">Uttarakhand</option> <option value="West Bengal">West Bengal</option>  </select> <br> <input type="text" name = "partner1_permcode" id = "partner1_permcode" placeholder = "permanent zipcode" class = "number_check"></div> <div style = "display: flex; "> <label for="partner1_perm_pres">Same as Permanent Address</label> <input type="checkbox" name="partner1_perm_pres" id="partner1_perm_pres" class = "same_as_perm" style = "width: 20px; height: 20px; position: relative; top:5px; margin-left: 20px;"> </div><div><label class = "partner1_present">Present Address</label> <input type="text" name = "partner1_presadd1" id = "partner1_presadd1" placeholder="present Address line 1" class = "address_check partner1_present"> <br> <input type="text" name = "partner1_presadd2" id = "partner1_presadd2" placeholder="present Address line 2" class = "address_check partner1_present"> <br> <input type="text" name = "partner1_prescity" id = "partner1_prescity" placeholder="present City" class = "name_check partner1_present"> <br> <select name="partner1_presstate" id="partner1_presstate" class = "partner1_present"> <option value="Andhra Pradesh">Andhra Pradesh</option> <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option> <option value="Arunachal Pradesh">Arunachal Pradesh</option> <option value="Assam">Assam</option> <option value="Bihar">Bihar</option> <option value="Chandigarh">Chandigarh</option> <option value="Chhattisgarh">Chhattisgarh</option> <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option> <option value="Daman and Diu">Daman and Diu</option> <option value="Delhi">Delhi</option> <option value="Lakshadweep">Lakshadweep</option> <option value="Puducherry">Puducherry</option> <option value="Goa">Goa</option> <option value="Gujarat">Gujarat</option> <option value="Haryana">Haryana</option> <option value="Himachal Pradesh">Himachal Pradesh</option> <option value="Jammu and Kashmir">Jammu and Kashmir</option> <option value="Jharkhand">Jharkhand</option> <option value="Karnataka">Karnataka</option> <option value="Kerala">Kerala</option> <option value="Madhya Pradesh">Madhya Pradesh</option> <option value="Maharashtra">Maharashtra</option> <option value="Manipur">Manipur</option> <option value="Meghalaya">Meghalaya</option> <option value="Mizoram">Mizoram</option> <option value="Nagaland">Nagaland</option> <option value="Odisha">Odisha</option> <option value="Punjab">Punjab</option> <option value="Rajasthan">Rajasthan</option> <option value="Sikkim">Sikkim</option> <option value="Tamil Nadu">Tamil Nadu</option> <option value="Telangana">Telangana</option> <option value="Tripura">Tripura</option> <option value="Uttar Pradesh">Uttar Pradesh</option> <option value="Uttarakhand">Uttarakhand</option> <option value="West Bengal">West Bengal</option>  </select> <br> <input type="text" name = "partner1_prescode" id = "partner1_prescode" placeholder = "present zipcode" class = "number_check partner1_present"></div> <label for="partner1_occup">Occupation :</label> <input type="text" name = "partner1_occup" id = "partner1_occup" placeholder = "Occupation" class = "name_check"> <label for="partner1_educ">Education :</label> <input type="text" name = "partner1_educ" id = "partner1_educ" placeholder = "Education" class = "name_check"> <label for="partner1_dsc">Whether already possess DSC/DIN no</label> <select name="partner1_dsc" id="partner1_dsc"> <option value="Yes">Yes</option> <option value="No">No</option> </select> </div> <div class="desig_partner1 dp"> <label for="partner1_desig_typebody">Type of body corporate :</label> <select name="partner1_desig_typebody" id="partner1_desig_typebody"> <option value="Pvt. Ltd Company">Pvt. Ltd Company</option> <option value="Limited Liablity Partnership">Limited Liablity Partnership</option> </select> <label for="partner1_desig_cin">Corporate Identity Number :</label> <input type="number" name = "partner1_desig_cin" id = "partner1_desig_cin" placeholder="CIN"> <br> <label for="partner1_desig_pan">PAN :</label> <input type="text" name = "partner1_desig_pan" id = "partner1_desig_pan" placeholder = "PAN" class = "alpha_num_check"> <label for="partner1_desig_name">Name :</label> <input type="text" name = "partner1_desig_name" id = "partner1_desig_name" placeholder = "designated Name"> <label>Registered Address Details :</label> <input type="text" name = "partner1_desig_permadd1" id = "partner1_desig_permadd1" placeholder="registered Address line 1" class = "address_check"> <br> <input type="text" name = "partner1_desig_permadd2" id = "partner1_desig_permadd2" placeholder="registered Address line 2" class = "address_check"> <br> <input type="text" name = "partner1_desig_permcity" id = "partner1_desig_permcity" placeholder="registered City" class = "name_check"> <br> <select name="partner1_desig_permstate" id="partner1_desig_permstate"> <option value="Andhra Pradesh">Andhra Pradesh</option> <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option> <option value="Arunachal Pradesh">Arunachal Pradesh</option> <option value="Assam">Assam</option> <option value="Bihar">Bihar</option> <option value="Chandigarh">Chandigarh</option> <option value="Chhattisgarh">Chhattisgarh</option> <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option> <option value="Daman and Diu">Daman and Diu</option> <option value="Delhi">Delhi</option> <option value="Lakshadweep">Lakshadweep</option> <option value="Puducherry">Puducherry</option> <option value="Goa">Goa</option> <option value="Gujarat">Gujarat</option> <option value="Haryana">Haryana</option> <option value="Himachal Pradesh">Himachal Pradesh</option> <option value="Jammu and Kashmir">Jammu and Kashmir</option> <option value="Jharkhand">Jharkhand</option> <option value="Karnataka">Karnataka</option> <option value="Kerala">Kerala</option> <option value="Madhya Pradesh">Madhya Pradesh</option> <option value="Maharashtra">Maharashtra</option> <option value="Manipur">Manipur</option> <option value="Meghalaya">Meghalaya</option> <option value="Mizoram">Mizoram</option> <option value="Nagaland">Nagaland</option> <option value="Odisha">Odisha</option> <option value="Punjab">Punjab</option> <option value="Rajasthan">Rajasthan</option> <option value="Sikkim">Sikkim</option> <option value="Tamil Nadu">Tamil Nadu</option> <option value="Telangana">Telangana</option> <option value="Tripura">Tripura</option> <option value="Uttar Pradesh">Uttar Pradesh</option> <option value="Uttarakhand">Uttarakhand</option> <option value="West Bengal">West Bengal</option>  </select> <br> <input type="text" name = "partner1_desig_permcode" id = "partner1_desig_permcode" placeholder = "registered zipcode" class = "number_check"> </div> <div class="body_corporate dp"> <label for="body_corp_name">Full Name</label> <input type="text" name = "body_corp_name" id = "body_corp_name" placeholder="Full Name" class = "name_check"> <label for="body_corp_din">DIN</label> <input type="text" name = "body_corp_din" id = "body_corp_din" placeholder="DIN" class = "number_check"> <label for="body_corp_desg">Designation</label> <input type="text" name = "body_corp_desg" id = "body_corp_desg" placeholder="Designation" class = "name_check"> </div> <label for = "profit_perc">Profit Percentage :</label> <input placeholder="Profit Percentage" type = "number" name = "profit_perc" class = "number_check" min="0" oninput="validity.valid||(value="");"> <label for="are_you_desig_partner">Are you a Designated Partner ?</label> <select name="are_you_desig_partner"> <option value="Yes">Yes</option> <option value="No">No</option> </select><br><br> <a class = "btn remove_partner_button"> Remove </a> <br><br></div></div>'
$("#add_a_partner").on("click", function(){
    // alert("clicked")
    $(fieldhtml).insertBefore(wrapper)
    partner_number()
});
$(".form-four").on('click', '.remove_partner_button', function(e){
    e.preventDefault();
    $(this).parent('div').remove(); //Remove field html
    partner_number()
    change_in_input()
});    

function partner_number(){
    var iter_share = 1;
    $.each($(".partner_details_num"), function(){
        $(this).text("Partner #"+iter_share.toString())
        iter_share += 1
    })
}


// adding more than two directors

wrapper_director = $("#add_a_director")
fieldhtml_director = '<div> <br><br><h4>Director Details</h4><input type="text" name = "dir_name1" placeholder="Director Name" id = "dir_name1" class = "name_check"> <input type="text" name = "dir_occ1" placeholder="Director Occupation" id = "dir_occ1" class = "name_check"> <input type="number" name = "dir_mobile1" placeholder="Director Mobile Number" id = "dir_mobile1" class = "phone_no_check"> <input type="text" name = "dir_email1" placeholder="Director Email-id" id = "dir_email1" class = "email_check"> <label for="dir_citizen">Citizenship Status :</label> <select name="dir_nationality"> <option value="indian">Indian</option> <option value="afghan">Afghan</option> <option value="albanian">Albanian</option> <option value="algerian">Algerian</option> <option value="american">American</option> <option value="andorran">Andorran</option> <option value="angolan">Angolan</option> <option value="antiguans">Antiguans</option> <option value="argentinean">Argentinean</option> <option value="armenian">Armenian</option> <option value="australian">Australian</option> <option value="austrian">Austrian</option> <option value="azerbaijani">Azerbaijani</option> <option value="bahamian">Bahamian</option> <option value="bahraini">Bahraini</option> <option value="bangladeshi">Bangladeshi</option> <option value="barbadian">Barbadian</option> <option value="barbudans">Barbudans</option> <option value="batswana">Batswana</option> <option value="belarusian">Belarusian</option> <option value="belgian">Belgian</option> <option value="belizean">Belizean</option> <option value="beninese">Beninese</option> <option value="bhutanese">Bhutanese</option> <option value="bolivian">Bolivian</option> <option value="bosnian">Bosnian</option> <option value="brazilian">Brazilian</option> <option value="british">British</option> <option value="bruneian">Bruneian</option> <option value="bulgarian">Bulgarian</option> <option value="burkinabe">Burkinabe</option> <option value="burmese">Burmese</option> <option value="burundian">Burundian</option> <option value="cambodian">Cambodian</option> <option value="cameroonian">Cameroonian</option> <option value="canadian">Canadian</option> <option value="cape verdean">Cape Verdean</option> <option value="central african">Central African</option> <option value="chadian">Chadian</option> <option value="chilean">Chilean</option> <option value="chinese">Chinese</option> <option value="colombian">Colombian</option> <option value="comoran">Comoran</option> <option value="congolese">Congolese</option> <option value="costa rican">Costa Rican</option> <option value="croatian">Croatian</option> <option value="cuban">Cuban</option> <option value="cypriot">Cypriot</option> <option value="czech">Czech</option> <option value="danish">Danish</option> <option value="djibouti">Djibouti</option> <option value="dominican">Dominican</option> <option value="dutch">Dutch</option> <option value="east timorese">East Timorese</option> <option value="ecuadorean">Ecuadorean</option> <option value="egyptian">Egyptian</option> <option value="emirian">Emirian</option> <option value="equatorial guinean">Equatorial Guinean</option> <option value="eritrean">Eritrean</option> <option value="estonian">Estonian</option> <option value="ethiopian">Ethiopian</option> <option value="fijian">Fijian</option> <option value="filipino">Filipino</option> <option value="finnish">Finnish</option> <option value="french">French</option> <option value="gabonese">Gabonese</option> <option value="gambian">Gambian</option> <option value="georgian">Georgian</option> <option value="german">German</option> <option value="ghanaian">Ghanaian</option> <option value="greek">Greek</option> <option value="grenadian">Grenadian</option> <option value="guatemalan">Guatemalan</option> <option value="guinea-bissauan">Guinea-Bissauan</option> <option value="guinean">Guinean</option> <option value="guyanese">Guyanese</option> <option value="haitian">Haitian</option> <option value="herzegovinian">Herzegovinian</option> <option value="honduran">Honduran</option> <option value="hungarian">Hungarian</option> <option value="icelander">Icelander</option> <option value="indonesian">Indonesian</option> <option value="iranian">Iranian</option> <option value="iraqi">Iraqi</option> <option value="irish">Irish</option> <option value="israeli">Israeli</option> <option value="italian">Italian</option> <option value="ivorian">Ivorian</option> <option value="jamaican">Jamaican</option> <option value="japanese">Japanese</option> <option value="jordanian">Jordanian</option> <option value="kazakhstani">Kazakhstani</option> <option value="kenyan">Kenyan</option> <option value="kittian and nevisian">Kittian and Nevisian</option> <option value="kuwaiti">Kuwaiti</option> <option value="kyrgyz">Kyrgyz</option> <option value="laotian">Laotian</option> <option value="latvian">Latvian</option> <option value="lebanese">Lebanese</option> <option value="liberian">Liberian</option> <option value="libyan">Libyan</option> <option value="liechtensteiner">Liechtensteiner</option> <option value="lithuanian">Lithuanian</option> <option value="luxembourger">Luxembourger</option> <option value="macedonian">Macedonian</option> <option value="malagasy">Malagasy</option> <option value="malawian">Malawian</option> <option value="malaysian">Malaysian</option> <option value="maldivan">Maldivan</option> <option value="malian">Malian</option> <option value="maltese">Maltese</option> <option value="marshallese">Marshallese</option> <option value="mauritanian">Mauritanian</option> <option value="mauritian">Mauritian</option> <option value="mexican">Mexican</option> <option value="micronesian">Micronesian</option> <option value="moldovan">Moldovan</option> <option value="monacan">Monacan</option> <option value="mongolian">Mongolian</option> <option value="moroccan">Moroccan</option> <option value="mosotho">Mosotho</option> <option value="motswana">Motswana</option> <option value="mozambican">Mozambican</option> <option value="namibian">Namibian</option> <option value="nauruan">Nauruan</option> <option value="nepalese">Nepalese</option> <option value="new zealander">New Zealander</option> <option value="ni-vanuatu">Ni-Vanuatu</option> <option value="nicaraguan">Nicaraguan</option> <option value="nigerien">Nigerien</option> <option value="north korean">North Korean</option> <option value="northern irish">Northern Irish</option> <option value="norwegian">Norwegian</option> <option value="omani">Omani</option> <option value="pakistani">Pakistani</option> <option value="palauan">Palauan</option> <option value="panamanian">Panamanian</option> <option value="papua new guinean">Papua New Guinean</option> <option value="paraguayan">Paraguayan</option> <option value="peruvian">Peruvian</option> <option value="polish">Polish</option> <option value="portuguese">Portuguese</option> <option value="qatari">Qatari</option> <option value="romanian">Romanian</option> <option value="russian">Russian</option> <option value="rwandan">Rwandan</option> <option value="saint lucian">Saint Lucian</option> <option value="salvadoran">Salvadoran</option> <option value="samoan">Samoan</option> <option value="san marinese">San Marinese</option> <option value="sao tomean">Sao Tomean</option> <option value="saudi">Saudi</option> <option value="scottish">Scottish</option> <option value="senegalese">Senegalese</option> <option value="serbian">Serbian</option> <option value="seychellois">Seychellois</option> <option value="sierra leonean">Sierra Leonean</option> <option value="singaporean">Singaporean</option> <option value="slovakian">Slovakian</option> <option value="slovenian">Slovenian</option> <option value="solomon islander">Solomon Islander</option> <option value="somali">Somali</option> <option value="south african">South African</option> <option value="south korean">South Korean</option> <option value="spanish">Spanish</option> <option value="sri lankan">Sri Lankan</option> <option value="sudanese">Sudanese</option> <option value="surinamer">Surinamer</option> <option value="swazi">Swazi</option> <option value="swedish">Swedish</option> <option value="swiss">Swiss</option> <option value="syrian">Syrian</option> <option value="taiwanese">Taiwanese</option> <option value="tajik">Tajik</option> <option value="tanzanian">Tanzanian</option> <option value="thai">Thai</option> <option value="togolese">Togolese</option> <option value="tongan">Tongan</option> <option value="trinidadian or tobagonian">Trinidadian or Tobagonian</option> <option value="tunisian">Tunisian</option> <option value="turkish">Turkish</option> <option value="tuvaluan">Tuvaluan</option> <option value="ugandan">Ugandan</option> <option value="ukrainian">Ukrainian</option> <option value="uruguayan">Uruguayan</option> <option value="uzbekistani">Uzbekistani</option> <option value="venezuelan">Venezuelan</option> <option value="vietnamese">Vietnamese</option> <option value="welsh">Welsh</option> <option value="yemenite">Yemenite</option> <option value="zambian">Zambian</option> <option value="zimbabwean">Zimbabwean</option></select> <label >Do you have a DSC ?</label> <p class = "p-desc">Digital Signature Certificate</p> <select name="dir_dsc" id="dir_dsc"> <option value="Yes">Yes</option> <option value="No">No</option> </select> <br><a class = "btn remove_director_button"> Remove </a> <br> <br> </div>';
$("#add_a_director").on("click", function(){
    // alert("clicked")
    $(fieldhtml_director).insertBefore(wrapper_director)
});
$(".form-five").on('click', '.remove_director_button', function(e){
    e.preventDefault();
    // alert("clicked")
    $(this).parent('div').remove(); //Remove field html
    change_in_input()

});    


// <!-- script for selecting the partner type -->

function check_class(name, arr){
    var sami = "";
    $(arr).each(function(i,item){
        if (item.hasClass(name)){
            sami = item
        }
    })
    return sami
}

$(document).on("change",'.partner_desg', function(){
    thevalue = $(this).val();
    var third = $(this).next().next().next().clone()
    var second = $(this).next().next().clone()
    var first = $(this).next().clone()
    // second = ""
    // third = ""
    $(this).next().next().next().remove()
    $(this).next().next().remove()
    $(this).next().remove()

    var arr = [first, second, third]
    f = check_class("norm_partner1", arr)
    s = check_class("desig_partner1", arr)
    t = check_class("body_corporate", arr)
    $(f).insertAfter($(this))
    $(s).insertAfter(f)
    $(t).insertAfter(s)

    first = $(this).next()
    second = $(this).next().next()
    third = $(this).next().next().next()
    if (thevalue == "Individual"){  
        first.removeClass("dp")
        second.addClass("dp")
        third.addClass("dp")
        partner_to_nominee(first, "Nominee")

    }
    else if (thevalue == "Body Corporate ( without DIN)"){
        first.removeClass("dp")
        second.removeClass("dp")
        third.addClass("dp")
        second.insertBefore(first)
        partner_to_nominee(first, "Partner")

    }
    else{
        first.addClass("dp")
        second.removeClass("dp")
        third.removeClass("dp")
        third.insertAfter(second)

    }
    $(".have_pan").val("No")
    change_in_input()
})



// script for changing partner to nominee
function partner_to_nominee(element, text){
    var arr = ["partner1_name", "partner1_dob", "partner1_pan", "partner1_pob"]
    var change_text = ""
    if (text == "Partner"){
        change_text = "Nominee"
    }
    else{
        change_text = "Partner"
    }
    $.each(arr, function(i,item){
        var temp = $(element).children("input[name='"+item+"']").attr("placeholder")
        temp = temp.replace(text, change_text)
        $(element).children("input[name='"+item+"']").attr("placeholder", temp)
    })
}

// <!-- script for changing present address as permanent address -->

$(document).on("change",'.same_as_perm',same_as_perm_change)

function same_as_perm_change(){
    if (this.checked){
        var top_of_curr = $(this).parent().prev()
        var bottom_of_curr = $(this).parent().next("div")
        // $(top_of_curr).addClass("dp")
        // $(bottom_of_curr).addClass("dp")
        // console.log("haslkjdasd", top_of_curr)  
        // console.log("haslkjdasd", bottom_of_curr)
        var values_of_perm = []
        // console.log(top)
        $(top_of_curr).find('input').each(function(){
            if ($(this).val()){
                values_of_perm.push($(this).val())
            }
            else{
                values_of_perm.push("")
            }
        })
        var ijz = 0
        $(bottom_of_curr).children('input').each(function(){
            $(this).val(values_of_perm[ijz])
            ijz += 1
        })
        var xyz = $(top_of_curr).children("select").first().val()

        $(bottom_of_curr).children("select").first().val(xyz)

    }
    else{
        var bottom_of_curr = $(this).parent().next()
        // top = $(this).parent().prev()
        $(bottom_of_curr).children("input").each(function(){
            $(this).val("")
        })
    }
    change_in_input()
}



// script for selecting the trust services 

$("#trust_trustee_service").change(function(){
    val = $("#trust_trustee_service").val()
    temp = $("#trust_trustee_aif_reg")
    if (val == "1"){
        temp.removeClass("dp")
    }
    else{
        temp.addClass("dp")
    }
})




// <!-- script for checking the face values -->

a = $("#auth_share_capital")
b = $("#paid_share_capital")
c = $("#face_value")
a.on("input", function(){
    b.val(a.val())
})
$("#paid_share_capital").on("input", function() {
    x = $("#auth_share_capital").val()
    y = $("#paid_share_capital").val()
    x = parseInt(x)
    y = parseInt(y)
    if (y>x){
        $("#paid_share_capital").val(parseInt(y/10))
    }
}
)
total_shares = parseInt(parseInt(b.val())/parseInt(c.val()))
$("#auth_share_capital, #paid_share_capital, #face_value").change(function(){
    x = parseInt(b.val())
    y = parseInt(c.val())
    total_shares = parseInt(x/y)
    alert("total_shares :" + total_shares.toString())
})



// Use our virtual addresss
add_va_btn = $("#add_our_va")
remove_va_btn = $("#remove_our_va")
arr_va = ["cmp_address1", "cmp_address2", "cmp_city", "cmp_state", "cmp_zipcode", "phone_number"]
val1_va = ["dummy_add_1", "dummy_add_2", "dummy_city", "Goa", 4568001, 7389705918]
val2_va = ["","","","",""]
$(add_va_btn).click(function(){
    // alert("clicked")
    for (i = 0; i < arr_va.length; i++){
        $("input[name='"+arr_va[i]+"']").val(val1_va[i])
    }
    $("select[name='own_rented']").val("Rented")
    $("input[name='owner_name']").val("dummy owner")
    $("#owner_name").removeClass("dp")

    change_in_input()

})
$(remove_va_btn).click(function(){
    for (i = 0; i < arr_va.length; i++){
        $("input[name='"+arr_va[i]+"']").val(val2_va[i])
    }
    $("select[name='own_rented']").val("Owned")
    $("input[name='owner_name']").val("")
    $("#owner_name").addClass("dp")
    change_in_input()
})


// use our trustee details

add_ta_btn = $("#add_our_ta")
remove_ta_btn = $("#remove_our_ta")
tarr = ["truste_name", "truste_address1", "truste_address2", "truste_city", "truste_zipcode"]
tval1 = ["dummy_name", "dummy_add_1", "dummy_add_2", "dummy_city",458001]
tval2 = ["","","","",""]
$(add_ta_btn).click(function(){
    // alert("clicked")
    for (i = 0; i < tarr.length; i++){
        $("input[name='"+tarr[i]+"']").val(tval1[i])
    }
})
$(remove_ta_btn).click(function(){
    for (i = 0; i < tarr.length; i++){
        $("input[name='"+tarr[i]+"']").val(tval2[i])
    }
})


//nature_activity_update
function nature_update(){
    $.ajax({
        type:"GET",
        url:"/register/nature_updation",
        success: function(data){
            nature_select = $("#nature_oa")
            if (nature_select){
                arr = data.data
                $.each(arr, function(i, item){
                    field = "<option value = '"+item.drop_code+":"+item.description+"'>"+item.drop_code+":"+item.description+"</option>"
                    nature_select.append(field)
                })
            }
        }
    })
}



// script for changing having perm and pres
$(document).on("change", ".partner1_perm_pres", function(){
    pt = $(this).parent().next()
    alert("change")
    if (!$(this).is("checked")){
        pt.removeClass("dp")
    }
    else{
        pt.addClass("dp")
    }
    change_in_input()

})

// use our  nominee director button
add_nd_btn = $("#add_our_nd")
remove_nd_btn = $("#remove_our_nd")
arr_nd = ["dir_name1", "dir_occ1", "dir_mobile1", "dir_email1"]
val1_nd = ["dummy_name", "dummy_occupation", "9494949494", "dummy@g.com"]
val2_nd = ["","","", ""]
$(add_nd_btn).click(function(){
    // alert("clicked")
    for (i = 0; i < arr_nd.length; i++){
        $("input[name='"+arr_nd[i]+"']").first().val(val1_nd[i])
    }
    change_in_input()

})
$(remove_nd_btn).click(function(){
    for (i = 0; i < arr_nd.length; i++){
        $("input[name='"+arr_nd[i]+"']").val(val2_nd[i])
    }
    $("select[name='own_rented']").val("Owned")
    $("input[name='owner_name']").val("")
    $("#owner_name").addClass("dp")
    change_in_input()
})



// script for changing having pan or not
$(document).on("change", ".have_pan", function(){
    x = $(this).val()
    if (x == "Yes"){
        $(this).next().next().addClass("pan_check")
        $(this).next().next().removeClass("alpha_num_check")
    }
    else{
        $(this).next().next().removeClass("pan_check")
        $(this).next().next().addClass("alpha_num_check")
    }
    change_in_input()

})