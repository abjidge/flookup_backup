
function clear_data()
{
    urls = ["/register/company_details", "/register/address_details", "/register/shareholder_details", "/register/director_details", "/register/partner_details", "/register/trust_details", "/register/company_documents"]
    index= 0
    values = {"delete":"yes"}
    temp = [0,1,2,3,4,5,6]
    $.each(temp, function(xyz, index) {
        $.ajax({
            url : urls[index],
            data : values,
            type : "GET",
            success : function(data){
                // console.log("success")
                // alert("success")
            },
            error : function(){
                console.log("Unsuccesful")
            }
        })
    })
}