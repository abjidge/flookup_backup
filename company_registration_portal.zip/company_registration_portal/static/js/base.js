var a;

function show_hide() {
  if (a == 1) {
    document.getElementById("content").style.display = "none";
    document.getElementById("table").style.width = "100%";
    document.getElementById("filter").style.background = "#fff";
    document.getElementById("filter").style.color = "#172b4d";
    return (a = 0);
  } else {
    document.getElementById("content").style.display = "inline";
    document.getElementById("filter").style.background = "#2c9467";
    document.getElementById("filter").style.color = "white";

    return (a = 1);
  }
}

function changeID(id) {
  // console.log(id)
  document.getElementById('hidden_id').value = id
  showAllComments()
}

function resetID() {
  document.getElementById('comment_area').innerHTML = ""
  document.getElementById('hidden_id').value = ""
  document.getElementById('comment_text').value = ""
  document.getElementById('comment_file').value = ""
}


function showAllComments() {

  id = document.getElementById('hidden_id').value;

  $.ajax({
    url: "/register/comments/" + id + "/",
    type:"GET",
    success: function(data){
        let comments = data.data;
        const comment_area = document.getElementById('comment_area');
        let content = "";
        let comments_array = [...comments];
        comments_array.forEach(com => {
            temp = `
            <div class="comment-item">
            <div class="comment-data">
              <p>${com.comment}</p>`

              if (com.com_name != "") {
                temp += `<a href = "${com.com_link}" class="com-download">${com.com_name}</a>`
              }

            temp += `</div>

            <div class="comment-details">
              <span><i class="fa-regular fa-user"></i> ${com.user}</span>
              <span><i class="fa-regular fa-calendar"></i> ${com.time}</span>
            </div>
            </div>
            `
            content += temp
        });

        comment_area.innerHTML = content;
    },
    error: function(data){
        alert("Error")
    }
})
}

function postComment(e)
{
  e.preventDefault()
  id = document.getElementById('hidden_id').value;
  values = new FormData()
  values.append("comment_text", $('#comment_text').val())
  x = $("input[name ='comment_file'")[0].files
  // print(x)
  if (x.length){
    values.append("comment_file", x[0])
  }
  if ($('#comment_text').val().length || x.length)
  {
    $.ajax({
    url: "/register/comments/" + id + "/",
    data: values,
    type:"POST",
    enctype: 'multipart/form-data',
    processData: false,
    contentType: false,
    cache: false,
    success: function(data){

        alert(data.message);
        showAllComments()
    },
    error: function(data){
        alert("Error")
    }
  })
  }
}

function downloadData(id, type) {
  values = {
    'comp_id' : id
  }
  let url;

  if (type == "1") {
    url = "/dashboard/export_csv_pvt"
  } else if (type == "2") {
    url = "/dashboard/export_csv_llp"
  } else {
    url = "/dashboard/export_csv_trust"
  }

  $.ajax({
    url: url,
    data: values,
    type:"POST",
    xhrFields: {
      responseType: 'blob'
    },
    success: function (data) {
      var a = document.createElement('a');
      var url = window.URL.createObjectURL(data);
      a.href = url;
      a.download = 'myfile.csv';
      document.body.append(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    },
    error: function(data){
        alert("Error")
    }
  })
}

function downloadAllData(type) {
  if(type == "1") {
    url = "/dashboard/export_csv_pvt"
  } else if(type == "2") {
    url = "/dashboard/export_csv_llp"
  } else {
    url = "/dashboard/export_csv_trust"
  }


  if (window.location.pathname == "/dashboard/filter") {

    values = {
      'comp_id': '0',
      'comp_type': sessionStorage.getItem("type"),
      'comp_status': sessionStorage.getItem("status"),
      'comp_payment': sessionStorage.getItem("payment")
    }

    console.log(sessionStorage.getItem("type"));

    $.ajax({
      url: url,
      data: values,
      type:"POST",
      xhrFields: {
        responseType: 'blob'
      },
      success: function (data) {
        var a = document.createElement('a');
        var url = window.URL.createObjectURL(data);
        a.href = url;
        a.download = 'filtered_data.csv';
        document.body.append(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
      },
      error: function(data){
          alert("Error 2")
      }
    })
  } else {

      $.ajax({
        url: url,
        type:"GET",
        xhrFields: {
          responseType: 'blob'
        },
        success: function (data) {
          var a = document.createElement('a');
          var url = window.URL.createObjectURL(data);
          a.href = url;
          a.download = 'all_company_data.csv';
          document.body.append(a);
          a.click();
          a.remove();
          window.URL.revokeObjectURL(url);
        },
        error: function(data){
            alert("Error")
        }
      })
  }
}

function changeAssignee(id, value) {
  // console.log(id)

  values = {
    'emp' : value,
    'comp_id': id
  }
  
  $.ajax({
    url: "/dashboard/change_assignee",
    data: values,
    type:"POST",
    success: function (data) {
      alert(data.message)
      location.reload()
    },
    error: function(data){
        alert("Error")
        location.reload()
    }
  })
}
 
function changeStatus(value, id) {
  // console.log(id)
  // console.log(value)

  values = {
    'comp_id': id,
    'comp_status': value,
  }
  
  $.ajax({
    url: "/dashboard/change_status",
    data: values,
    type:"POST",
    success: function (data) {
      alert(data.message)
      location.reload()
    },
    error: function(data){
        alert("Error")
        location.reload()
    }
  })
}

function filterToSession() {
  let comp_type = document.getElementById('comp_type')
  let comp_status = document.getElementById('comp_status')
  let comp_payment = document.getElementById('comp_payment')
  sessionStorage.setItem("type", comp_type.value);
  sessionStorage.setItem("status", comp_status.value);
  sessionStorage.setItem("payment", comp_payment.value);
}

function toggleMenu() {
  const menu = document.getElementById('menu-wrap')
  const profile = document.getElementById('profile')
  const link = document.querySelector('.btn-sign-out')
  const wrapper = document.querySelector('.menu-wrapper')

  if (menu.classList.contains('show-menu')) {
    menu.classList.remove('show-menu')
    link.style.display = 'none'

  } else {
    menu.classList.add('show-menu')
    link.style.display = 'flex'
  }
}

function deleteUser(id) {

  values = {
    'user_id': id
  }

  $.ajax({
    url: "/dashboard/delete_user",
    data: values,
    type:"POST",
    success: function(data) {
        alert(data.message);
        location.reload()
    },
    error: function(data){
        alert("Error")
    }
  })
}

function getStatusInfo(comp_id) {
    let info = document.getElementById("info_" + comp_id)
    document.getElementById('status_text').value = info.value
    document.getElementById('h_c_id').value = comp_id
}

function postStatusInfo() {
    let comp_id = document.getElementById('h_c_id').value;
    let status_info = document.getElementById('status_text').value

    values = {
      'comp_id': comp_id,
      'info': status_info
    }
  
    $.ajax({
      url: "/dashboard/change_status_info",
      data: values,
      type:"POST",
      success: function(data) {
          alert(data.message);
          location.reload()
      },
      error: function(data){
          alert("Error")
      }
    })
}