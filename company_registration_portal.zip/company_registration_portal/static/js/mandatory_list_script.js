$(document).on("change", "input", change_in_input)


function change_in_input(){
    var incomplete = new Set()
    $("#myform input").each(function(){
        x = $(this).val()
        pt = $(this).parent().closest('div')
        if (!x && !pt.hasClass("dp"))
        {
            //    console.log(pt.hasClass("dp"))
            incomplete.add($(this).attr("placeholder"))
        }
    })
    var complete = new Set()
    // console.log(incomplete)
    $("a").each(function(){
        x = $(this).data("holder")
        if(x && $(this).text()){
            complete.add(x)
            // console.log($(this).text())
        }
    })
    $("div").each(function(){
        x = $(this).data("holder-doc")
        if(x && !($(this).children().length == 0)){
            complete.add(x)
            // console.log($(this).text())
        }
    })
    var doc_set = new Set(["Middle Name","Concern Letter"])
    function getDifference(setA, setB) {
    return new Set(
        [...setA].filter(element => !setB.has(element))
    );
    }
    incomplete = getDifference(incomplete, complete)
    incomplete = getDifference(incomplete, doc_set)
    
    $(".mandatory_list_ul").empty();
    for (const item of incomplete) {
        $(".mandatory_list_ul").append("<li>" + item+"</li>")
    }

    change_in_data()

}

function change_in_data(){
    var incomplete_step = new Set()
    var complete = new Set()
    $("a").each(function(){
        x = $(this).data("step-name")
        pt = $(this).parent().closest('div')
        if(x && !pt.hasClass("dp")){
            if (!$(this).text()){
                complete.add(x)
            }   
            console.log($(this).text())
        }
    })
    $("div").each(function(){
        x = $(this).data("step-name")
        pt = $(this).parent().closest('div')
        if(x && !pt.hasClass("dp")){
            if ($(this).children().length == 0){
                complete.add(x)
            }   
            console.log($(this).text())
        }
    })
    
    // console.log(incomplete)
    console.log("complete set", complete, "hie")

    $(".form-step").each(function(){
        flag = false
        var thisinform = this;
        $(thisinform).find("input").each(function(){
            var this_input = this;
            x = $(this_input).val()
            pt = $(this).parent().closest('div')
            if (!x && !pt.hasClass("dp") && !($(this_input).attr("name") == "middle_name"))
            {    flag = true
                x = $(this_input).val()
            }
        })
        if (flag){
            incomplete_step.add($(thisinform).data("holder"))
        }
    })
    if (!complete.has("Documents") && incomplete_step.has("Documents")){
        incomplete_step.delete("Documents")
    }
    console.log("incomplete set", incomplete_step)
    $(".step").each(function(){
        val = $(this).data("holder")
        if (incomplete_step.has(val)){
            $(this).addClass("border_step")
        }
        else{
            $(this).removeClass("border_step")
        }
    })
}


