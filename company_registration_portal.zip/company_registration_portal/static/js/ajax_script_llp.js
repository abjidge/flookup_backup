

function update_data(){

    urls = ["/register/company_details", "/register/address_details", "/register/partner_details"]
    items = [
        ["c_name1", "c_name2","nature_oa", "comp_desc"],["cmp_address1", "cmp_address2", "cmp_city", "cmp_state", "cmp_zipcode", "phone_number", "own_rented", "owner_name"],["partner1_desg", "partner1_name", "partner1_dob", "partner1_ciz_status", "partner1_pan", "partner1_pob", "partner1_permadd1", "partner1_permadd2", "partner1_permcity", "partner1_permstate", "partner1_permcode", "partner1_perm_pres", "partner1_presadd1", "partner1_presadd2", "partner1_prescity", "partner1_presstate", "partner1_prescode", "partner1_occup", "partner1_educ", "partner1_dsc", "partner1_desig_typebody", "partner1_desig_cin", "partner1_desig_pan", "partner1_desig_name", "partner1_desig_permadd1", "partner1_desig_permadd2", "partner1_desig_permcity", "partner1_desig_permstate", "partner1_desig_permcode", "body_corp_name", "body_corp_din", "body_corp_desg", "profit_perc", "are_you_desig_partner"]
    ]
    
    need = [["name1", "name2", "type", "business_activity_description"], ["address1", "address2", "city", "state", "zipcode","phone_number", "property_type", "owner_name"],['type_of_desg', 'name', 'dob', 'partner_citz_status', 'pan_passport_details', 'place_of_birth', 'perm_add1', 'perm_add2', 'perm_city', 'perm_state', 'perm_zipcode', 'perm_pres_same', 'pres_add1', 'pres_add2', 'pres_city', 'pres_state', 'pres_zipcode', 'occupation', 'education', 'dsc_no', 'desig_typebody', 'desig_cin', 'desig_pan', 'desig_name', 'desig_permadd1', 'desig_permadd2', 'desig_permcity', 'desig_permstate', 'desig_permcode', 'body_corp_name', 'body_corp_din', 'body_corp_desg', "profit_perc","are_you_desig_partner"]]
    
    temp = [0,1,2]
    $.each(temp, function(xyz, curr) {
        $.ajax({
            url:urls[curr],
            type : "GET",
            success : function(data){
            if (curr == 2){
                object_values = data["partner_data"]
                if (object_values.length){
                    ln = object_values.length
                    for (x=1; x<ln; x++){
                        $("#add_a_partner").click()
                    }
                    for (j=0; j < need[curr].length; j++){
        
                        val_tag = $("input[name = '"+items[curr][j] +"']")
                        if (val_tag.length){
                        }
                        else{
                            val_tag =$("select[name = '"+items[curr][j] +"']")
                        }
                        x = 0
                        $(val_tag).each(function(){
                            $(this).val(object_values[x][need[curr][j]])
                            x++
                        })
                    }

                    $(".partner_desg").each(function(){
                        thevalue = $(this).val();
                        if (thevalue == "Individual"){
                            $(this).next().removeClass("dp")
                            $(this).next().next().addClass("dp")
                            $(this).next().next().next().addClass("dp")
                
                        }
                        else if (thevalue == "Body Corporate ( without DIN)"){
                            $(this).next().removeClass("dp")
                            $(this).next().next().removeClass("dp")
                            $(this).next().next().next().addClass("dp")
                        }
                        else{
                            $(this).next().addClass("dp")
                            $(this).next().next().removeClass("dp")
                            $(this).next().next().next().removeClass("dp")
                        }
                    })
                
        
                }
            }
            else{
                object_values = data["context"]
                if (object_values.length){
                    for (j=0; j < need[curr].length; j++){
                        val_tag = $("input[name = '"+items[curr][j] +"']")
                        if (val_tag.length){
                        }
                        else{
                            val_tag =$("select[name = '"+items[curr][j] +"']")
                        }
                        x = 0
                        $(val_tag).each(function(){
                            $(this).val(object_values[x][need[curr][j]])
                            x++
                        })
                    }
        
                }
                
            }
            // alert("changes_made")
            thevalue = $("#own_rented").val();
            if (thevalue == "Rented"){
            $("#owner_name").addClass("dp_active")
            $("#owner_name").removeClass("dp")
        
            }
            else{
            $("#owner_name").removeClass("dp_active")
            $("#owner_name").addClass("dp")
            }
            $(".partner_desg").each(function(){

                thevalue = $(this).val();
                var third = $(this).next().next().next().clone()
                var second = $(this).next().next().clone()
                var first = $(this).next().clone()
                // second = ""
                // third = ""
                $(this).next().next().next().remove()
                $(this).next().next().remove()
                $(this).next().remove()
            
                var arr = [first, second, third]
                f = check_class("norm_partner1", arr)
                s = check_class("desig_partner1", arr)
                t = check_class("body_corporate", arr)
                $(f).insertAfter($(this))
                $(s).insertAfter(f)
                $(t).insertAfter(s)
            
                first = $(this).next()
                second = $(this).next().next()
                third = $(this).next().next().next()
                
                if (thevalue == "Individual"){
                    first.removeClass("dp")
                    second.addClass("dp")
                    third.addClass("dp")
                }
                else if (thevalue == "Body Corporate ( without DIN)"){
                    first.removeClass("dp")
                    second.removeClass("dp")
                    third.addClass("dp")
                    second.insertBefore(first)
                }
                else{
                    first.addClass("dp")
                    second.removeClass("dp")
                    third.removeClass("dp")
                    third.insertBefore(second)
                }
                $(".have_pan").val("No")
                change_in_input()
            })
            }
        })  
    })
    
    updateprog()
    
}



function ajax_query(){
    items = [
        ["c_name1", "c_name2","nature_oa", "comp_desc"],["c_name1", "c_name2","nature_oa", "comp_desc"],["cmp_address1", "cmp_address2", "cmp_city", "cmp_state", "cmp_zipcode", "phone_number", "own_rented", "owner_name"],["partner1_desg", "partner1_name", "partner1_dob", "partner1_ciz_status", "partner1_pan", "partner1_pob", "partner1_permadd1", "partner1_permadd2", "partner1_permcity", "partner1_permstate", "partner1_permcode", "partner1_perm_pres", "partner1_presadd1", "partner1_presadd2", "partner1_prescity", "partner1_presstate", "partner1_prescode", "partner1_occup", "partner1_educ", "partner1_dsc", "partner1_desig_typebody", "partner1_desig_cin", "partner1_desig_pan", "partner1_desig_name", "partner1_desig_permadd1", "partner1_desig_permadd2", "partner1_desig_permcity", "partner1_desig_permstate", "partner1_desig_permcode", "body_corp_name", "body_corp_din", "body_corp_desg", "profit_perc", "are_you_desig_partner"]
    ]
    
    if (active == 1){
        val = active-1
    }
    else{
        val = active-2
    }
    names = items[val]
    if(val == 3){
        arr = []
        values=  {}
        for (index = 0; index < names.length; index++){
            val_tag = $("input[name = '"+names[index] +"']")
            if (val_tag.length){
            }
            else{
                val_tag =$("select[name = '"+names[index] +"']")
            }
            values[names[index]] = []
            $(val_tag).each(function(){
                values[names[index]].push($(this).val())
            })
        }
    }
    else{
        values = {}
        for (i = 0;i < names.length; i++){
            ele = $("input[name='"+names[i]+"']")
            if (ele.length){
                values[names[i]] = ele.val()
            }
            else{
                values[names[i]] = $("select[name='"+names[i]+"']").val()
            }
        }
    }
    values["structure_type"] = $("#struct_change").val()
    urls = ["/register/company_details","/register/company_details", "/register/address_details",
     "/register/partner_details"]
    $.ajax({
        url: urls[val],
        data: values,
        type:"POST",
        success: function(data){
            console.log(data.message)
        },
        error: function(data){
            console.log("Unsuccessfull")
        }
    })

    

}
