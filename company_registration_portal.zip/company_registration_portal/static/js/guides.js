var tab = $("#guide_display")
var modal_title = $("#exampleModalLabel")


$(".guide-item").on("click", function(){
    val = $(this).children("p").text()
    tab.removeClass("dp")
    tab.empty()
    modal_title.text($(this).children("h3").text())
    tab.append("<pre>"+val+"</pre>")
})
$(document).on("click", "#guide_display_close", function(){
    tab.empty()
    tab.addClass("dp")
})
