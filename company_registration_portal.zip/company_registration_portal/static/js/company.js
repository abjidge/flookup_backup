function editPrimary() {
    console.log("hi");
    const edit_btn = document.getElementById('edit-btn1');
    const save_btn = document.getElementById('save-btn1');
    edit_btn.style.display = 'none';
    save_btn.style.display = 'inline';
    var inp_list = document.querySelectorAll('#primary input');
    var inp_array = [...inp_list];
    inp_array.forEach(inp => {
        inp.readOnly = false;
    });
}

function savePrimary() {
    console.log("woked");
    let c_name1 = document.getElementById('c_name1');
    let c_name2 = document.getElementById('c_name2');
    let c_name3 = document.getElementById('c_name3');
    let c_name4 = document.getElementById('c_name4');
    let nature_oa = document.getElementById('c_now');
    let desc = document.getElementById('c_desc');

    let type = document.getElementById('h_type').value

    if (type == "3") {
        values = {
            'c_name1': c_name1.value,
            'comp_desc': desc.value,
        }
    } else if (type == "2") {
                values = {
            'c_name1': c_name1.value,
            'c_name2': c_name2.value,
            'comp_desc': desc.value,
            'nature_oa': nature_oa.value,
        }
    } else {
        values = {
            'c_name1': c_name1.value,
            'c_name2': c_name2.value,
            'c_name3': c_name3.value,
            'c_name4': c_name4.value,
            'nature_oa': nature_oa.value,
            'comp_desc': desc.value,
        }
    }

    $.ajax({
        url: "/register/company_details",
        data: values,
        type:"POST",
        success: function(data){
            alert(data.message)
            location.reload();
        },
        error: function(data){
            alert("Error")
        }
    })
}

function editAddress() {
    const edit_btn = document.getElementById('edit-btn2');
    const save_btn = document.getElementById('save-btn2');
    edit_btn.style.display = 'none';
    save_btn.style.display = 'inline';
    var inp_list = document.querySelectorAll('#address input');
    var inp_array = [...inp_list];
    inp_array.forEach(inp => {
        inp.readOnly = false;
    });
    inp_array[0].focus();
}

function saveAddress() {
    values = {
        'cmp_address1': document.getElementById('cmp_address1').value,
        'cmp_address2': document.getElementById('cmp_address2').value,
        'cmp_city': document.getElementById('cmp_city').value,
        'cmp_state': document.getElementById('cmp_state').value,
        'cmp_zipcode': document.getElementById('cmp_zipcode').value,
        'phone_number': document.getElementById('phone_number').value,
        'own_rented': document.getElementById('own_rented').value,
        'owner_name': document.getElementById('owner_name').value,
    }

    $.ajax({
        url: "/register/address_details",
        data: values,
        type:"POST",
        success: function(data){
            alert(data.message)
            location.reload();
        },
        error: function(data){
            alert("Error")
            location.reload();
        }
    })
}

function editShare() {
    const edit_btn = document.getElementById('edit-btn6');
    const save_btn = document.getElementById('save-btn6');
    edit_btn.style.display = 'none';
    save_btn.style.display = 'inline';
    var inp_list = document.querySelectorAll('#share input');
    var inp_array = [...inp_list];
    inp_array.forEach(inp => {
        inp.readOnly = false;
    });
    inp_array[0].focus();
}

function saveShare() {

    id = document.getElementById('h_comp_id').value

    values = {
        'comp_id': id,
        'auth_share_capital': document.getElementById('auth_share_capital').value,
        'paid_share_capital': document.getElementById('paid_share_capital').value,
        'face_value': document.getElementById('face_value').value,
    }

    $.ajax({
        url: "/register/update_share",
        data: values,
        type:"POST",
        success: function(data){
            alert(data.message)
            location.reload();
        },
        error: function(data){
            alert("Error")
            location.reload();
        }
    })
}

function editTrustee() {
    const edit_btn = document.getElementById('edit-btn31');
    const save_btn = document.getElementById('save-btn31');
    edit_btn.style.display = 'none';
    save_btn.style.display = 'inline';
    var inp_list = document.querySelectorAll('#trustee input');
    var inp_array = [...inp_list];
    inp_array.forEach(inp => {
        inp.readOnly = false;
    });
    inp_array[0].focus();
}

function saveTrustee() {
    values = {
        'truste_name': document.getElementById('te_name').value,
        'truste_address1': document.getElementById('te_address1').value,
        'truste_address2': document.getElementById('te_address2').value,
        'truste_city': document.getElementById('te_city').value,
        'truste_state': document.getElementById('te_state').value,
        'truste_zipcode': document.getElementById('te_zipcode').value,
        'settler_name': document.getElementById('se_name').value,
        'settler_address1': document.getElementById('se_address1').value,
        'settler_address2': document.getElementById('se_address2').value,
        'settler_city': document.getElementById('se_city').value,
        'settler_state': document.getElementById('se_state').value,
        'settler_zipcode': document.getElementById('se_zipcode').value,
    }

    $.ajax({
        url: "/register/trust_details",
        data: values,
        type:"POST",
        success: function(data){
            alert(data.message)
            location.reload();
        },
        error: function(data){
            alert("Error")
            location.reload();
        }
    })
}

function editFounder(id) {
    // console.log(id);

    let query = '#form_' + id + " input";
    var inp_list = document.querySelectorAll(query);
    var inp_array = [...inp_list];
    inp_array.forEach(inp => {
        inp.readOnly = false;
    });
    inp_array[0].focus();

    document.getElementById(id).style.display = "none";
    document.getElementById("saveBtn_" + id).style.display = "inline";
}

function saveFounder(key) {
    id = key.split("_")[1]
    console.log(id);

    values = {
        'f_id': id,
        'f_first_name': document.getElementById('f_first_name_' + id).value,
        'f_middle_name': document.getElementById('f_middle_name_' + id).value,
        'f_last_name': document.getElementById('f_last_name_' + id).value,
        'f_nationality': document.getElementById('f_nationality_' + id).value,
        'f_share': document.getElementById('f_share_' + id).value,
    }

    $.ajax({
        url: "/register/update_founder",
        data: values,
        type:"POST",
        success: function(data){
            alert(data.message)
            location.reload();
        },
        error: function(data){
            alert("Error")
            location.reload();
        }
    })
}

function editDirector(id) {
    // console.log(id);

    let query = '#form_' + id + " input";
    var inp_list = document.querySelectorAll(query);
    var inp_array = [...inp_list];
    inp_array.forEach(inp => {
        inp.readOnly = false;
    });
    inp_array[0].focus();

    document.getElementById(id).style.display = "none";
    document.getElementById("saveBtn_" + id).style.display = "inline";
}

function saveDirector(key) {
    id = key.split("_")[1]
    console.log(id);

    values = {
        'dir_id': id,
        'dir_name': document.getElementById('dir_name_' + id).value,
        'dir_occ': document.getElementById('dir_occ_' + id).value,
        'dir_mobile': document.getElementById('dir_mobile_' + id).value,
        'dir_email': document.getElementById('dir_email_' + id).value,
        'dir_nationality': document.getElementById('dir_nationality_' + id).value,
        'dir_dsc': document.getElementById('dir_dsc_' + id).value,
    }

    $.ajax({
        url: "/register/update_director",
        data: values,
        type:"POST",
        success: function(data){
            alert(data.message)
            location.reload();
        },
        error: function(data){
            alert("Error")
            location.reload();
        }
    })
}