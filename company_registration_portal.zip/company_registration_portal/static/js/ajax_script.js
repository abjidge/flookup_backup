function update_data(){

    urls = ["/register/company_details", "/register/address_details", "/register/shareholder_details", "/register/director_details"]
    items = [
        ["c_name1", "c_name2", "c_name3", "c_name4","nature_oa", "comp_desc"],["cmp_address1", "cmp_address2", "cmp_city", "cmp_state", "cmp_zipcode", "phone_number", "own_rented", "owner_name"], ["auth_share_capital", "paid_share_capital", "face_value", "first_name","middle_name" ,"last_name", "share_holder_nationality", "shares1"], ["dir_name1", "dir_occ1", "dir_mobile1", "dir_email1", "dir_nationality", "dir_dsc"]
    ]
    need = [["name1", "name2", "name3", "name4", "type", "business_activity_description"], ["address1", "address2", "city", "state", "zipcode","phone_number", "property_type", "owner_name"],["auth_share_capital","paid_share_capital","face_value", "first_name","middle_name" ,"last_name", "citizenship_status", "shares_alloted"], ["name", "current_occupation", "mobile_number", "email", "citizenship_status", "is_posses_DSC"]]
    
    temp = [0,1,2,3]
    $.each(temp, function(xyz, curr) {
        $.ajax({
            url:urls[curr],
            type : "GET",
            success : function(data){
            if (curr == 2){
                object_values = data["share_data"][0]
                if (object_values){
                    for (j=0; j < 3; j++){
                        $("input[name='" + items[curr][j] + "']").val(object_values[need[curr][j]])
                    }
                }
                object_values = data["founder_data"]
                if (object_values.length){
                    ln = object_values.length
                    for (x=1; x<ln; x++){
                        $("#add_a_founder").click()
                    }
                    for (j=3; j < need[curr].length; j++){
        
                        val_tag = $("input[name = '"+items[curr][j] +"']")
                        if (val_tag.length){
                        }
                        else{
                            val_tag =$("select[name = '"+items[curr][j] +"']")
                        }
                        x = 0
                        $(val_tag).each(function(){
                            $(this).val(object_values[x][need[curr][j]])
                            x++
                        })
        
                    }
                    
                }
            }
            else if (curr == 3){
                object_values = data["director_data"]
                if (object_values.length){
                    ln = object_values.length
                    for (x=2; x<ln; x++){
                        $("#add_a_director").click()
                    }
                    for (j=0; j < need[curr].length; j++){
                        val_tag = $("input[name = '"+items[curr][j] +"']")
                        if (val_tag.length){
                        }
                        else{
                            val_tag =$("select[name = '"+items[curr][j] +"']")
                        }
                        x = 0
                        $(val_tag).each(function(){
                            $(this).val(object_values[x][need[curr][j]])
                            x++
                        })
                    }
                    
                }
            }
            else{
                object_values = data["context"]
                if (object_values && object_values.length > 0){
                    for (j=0; j < need[curr].length; j++){
                        val_tag = $("input[name = '"+items[curr][j] +"']")
                        if (val_tag.length){
                        }
                        else{
                            val_tag =$("select[name = '"+items[curr][j] +"']")
                        }
                        x = 0
                        $(val_tag).each(function(){
                            $(this).val(object_values[x][need[curr][j]])
                            x++
                        })
                    }
        
                    }
                    // alert("changes_made")
            
                }

                thevalue = $("#own_rented").val();
                if (thevalue == "Rented"){
                $("#owner_name").addClass("dp_active")
                $("#owner_name").removeClass("dp")
            
                }
                else{
                $("#owner_name").removeClass("dp_active")
                $("#owner_name").addClass("dp")
                }
                
            }
            })
    })
    
    updateprog()
    
}



function ajax_query(){
    items = [
        ["c_name1", "c_name2", "c_name3", "c_name4","nature_oa", "comp_desc"],["c_name1", "c_name2", "c_name3", "c_name4","nature_oa", "comp_desc"],["cmp_address1", "cmp_address2", "cmp_city", "cmp_state", "cmp_zipcode", "phone_number", "own_rented", "owner_name"], ["auth_share_capital", "paid_share_capital", "face_value", "first_name","middle_name" ,"last_name", "share_holder_nationality", "shares1"], ["dir_name1", "dir_occ1", "dir_mobile1", "dir_email1", "dir_nationality", "dir_dsc"]
    ]
    
    if (active == 1){
        val = active-1
    }
    else{
        val = active-2
    }
    names = items[val]
    if(val == 3 || val == 4){
        arr = []
        values=  {}
        for (index = 0; index < names.length; index++){
            val_tag = $("input[name = '"+names[index] +"']")
            if (val_tag.length){
            }
            else{
                val_tag =$("select[name = '"+names[index] +"']")
            }
            values[names[index]] = []
            $(val_tag).each(function(){
                values[names[index]].push($(this).val())
            })
        }
    }
    else{
        values = {}
        for (i = 0;i < names.length; i++){
            ele = $("input[name='"+names[i]+"']")
            if (ele.length){
                values[names[i]] = ele.val()
            }
            else{
                values[names[i]] = $("select[name='"+names[i]+"']").val()
            }
        }
    }
    values["structure_type"] = $("#struct_change").val()
    urls = ["/register/company_details","/register/company_details", "/register/address_details", "/register/shareholder_details", "/register/director_details"]
    $.ajax({
        url: urls[val],
        data: values,
        type:"POST",
        success: function(data){
            console.log(data.message)
        },
        error: function(data){
            console.log("error in saving data")
        }
    })

    

}

