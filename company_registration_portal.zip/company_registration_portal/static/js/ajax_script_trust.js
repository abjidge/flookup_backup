function update_data()
{
    urls = ["/register/company_details", "/register/address_details","/register/trust_details"]

    items = [["c_name1", "comp_desc"],["cmp_address1", "cmp_address2", "cmp_city", "cmp_state", "cmp_zipcode", "phone_number", "own_rented", "owner_name"], ["truste_name", "truste_address1", "truste_address2", "truste_city", "truste_state", "truste_zipcode", "settler_name", "settler_address1", "settler_address2", "settler_city", "settler_state", "settler_zipcode"]]
    need = [["name1", "business_activity_description"], ["address1", "address2", "city", "state", "zipcode","phone_number", "property_type", "owner_name"], ["truste_name", "truste_address1", "truste_address2", "truste_city", "truste_state", "truste_zipcode", "settler_name", "settler_address1", "settler_address2", "settler_city", "settler_state", "settler_zipcode"]]
    temp = [0,1,2]
    $.each(temp, function(xyz, curr){
        $.ajax({
            url:urls[curr],
            type : "GET",
            success : function(data){
                object_values = data["context"]
                if (object_values.length){
                    for (j=0; j < need[curr].length; j++){
                        val_tag = $("input[name = '"+items[curr][j] +"']")
                        if (val_tag.length){
                        }
                        else{
                            val_tag =$("select[name = '"+items[curr][j] +"']")
                        }
                        x = 0
                        $(val_tag).each(function(){
                            $(this).val(object_values[x][need[curr][j]])
                            x++
                        })
                    }
                }
                thevalue = $("#own_rented").val();
                if (thevalue == "Rented"){
                    $("#owner_name").addClass("dp_active")
                    $("#owner_name").removeClass("dp")
                }
                else{
                    $("#owner_name").removeClass("dp_active")
                    $("#owner_name").addClass("dp")
                }
                }

        })
    })
}




function ajax_query()
{
    
    items = [["c_name1", "comp_desc"],["c_name1", "comp_desc"],["cmp_address1", "cmp_address2", "cmp_city", "cmp_state", "cmp_zipcode", "phone_number", "own_rented", "owner_name"], ["truste_name", "truste_address1", "truste_address2", "truste_city", "truste_state", "truste_zipcode", "settler_name", "settler_address1", "settler_address2", "settler_city", "settler_state", "settler_zipcode"], ["revoc", "discre", "trust_fund_setup", "trust_trustee_service", "trust_trustee_aif_reg"]
    ]
    if (active == 1){
        val = active-1
    }
    else{
        val = active-2
    }
    names = items[val]
    values = {}
    for (i = 0;i < names.length; i++){
        ele = $("input[name='"+names[i]+"']")
        if (ele.length){
            values[names[i]] = ele.val()
        }
        else{
            values[names[i]] = $("select[name='"+names[i]+"']").val()
        }
    }
    values["structure_type"] = $("#struct_change").val()

    urls = ["/register/company_details","/register/company_details", "/register/address_details","/register/trust_details", "/register/nature_of_trust"]
     $.ajax({
        url: urls[val],
        data: values,
        type:"POST",
        success: function(data){
            console.log(data.message)
        },
        error: function(data){
            console.log("Unsuccessfull")
    }
    })

}
