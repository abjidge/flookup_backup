const navbar = document.getElementById('navbar');
let scrolled = false;

window.onscroll = function() {
  if(window.pageYOffset > 100) {
      navbar.classList.remove('top');
      if(!scrolled) {
        navbar.style.transform = 'translateY(-70px)';
      }
      setTimeout(function() {
        navbar.style.transform = 'translateY(0)';
        scrolled = true;
      }, 200);
  } else {
    navbar.classList.add('top');
    scrolled = false;
  }
};

// Smooth scrolling 

$('#navbar a, .btn').on('click', function (e) {
  if (this.hash !== '') {
    e.preventDefault();

    const hash = this.hash;

    $('html, body').animate(
      {
        scrollTop: $(hash).offset().top - 100,
      },
      800
    );
  }
});


const about_modal = document.querySelector('#about_modal');
const terms_modal = document.querySelector('#terms_modal');
const overlay = document.querySelector('.overlay');

const btnCloseModal = document.querySelector('#close-about');
const btnCloseTermsModal = document.querySelector('#close-terms');
const btnOpenModal = document.querySelector('.show-modal');
const btnOpenTermsModal = document.querySelector('#terms_btn');

const openModal = function () {
  about_modal.classList.remove('hidden');
  overlay.classList.remove('hidden');
  document.body.classList.add('modal-open');
};

const openTermsModal = function () {
  terms_modal.classList.remove('hidden');
  overlay.classList.remove('hidden');
  document.body.classList.add('modal-open');
};

const closeModal = function () {
  about_modal.classList.add('hidden');
  overlay.classList.add('hidden');
  document.body.classList.remove('modal-open');
};

const closeTermsModal = function () {
  terms_modal.classList.add('hidden');
  overlay.classList.add('hidden');
  document.body.classList.remove('modal-open');
};


btnOpenModal.addEventListener('click', openModal);

btnOpenTermsModal.addEventListener('click', openTermsModal);

btnCloseModal.addEventListener('click', closeModal);

btnCloseTermsModal.addEventListener('click', closeTermsModal);

overlay.addEventListener('click', closeModal);
overlay.addEventListener('click', closeTermsModal);

document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && !about_modal.classList.contains('hidden')) {
    closeModal();
  }
  if (e.key === 'Escape' && !terms_modal.classList.contains('hidden')) {
    closeTermsModal();
  }
});

const items = document.querySelectorAll('.accordion button');

function toggleAccordion() {
  const itemToggle = this.getAttribute('aria-expanded');

  for (i = 0; i < items.length; i++) {
    items[i].setAttribute('aria-expanded', 'false');
  }

  if (itemToggle == 'false') {
    this.setAttribute('aria-expanded', 'true');
  }
}

items.forEach((item) => item.addEventListener('click', toggleAccordion));

var menuBtn = document.getElementById("menuBtn")
var sideNav = document.getElementById("sideNav")
var menu = document.getElementById("menu")
menuBtn.onclick = function() {
    if (sideNav.style.right == "-250px") {
        sideNav.style.right = "0";
        menu.src = "https://i.postimg.cc/cJRss6PP/close.png";
    } else {
        sideNav.style.right = "-250px";
        menu.src = "https://i.postimg.cc/j5RRCtb2/menu.png";
    }
}

function firstStep() {
  const formBtn = document.getElementById('form-two')
  formBtn.style.display = 'flex'
}

// const formBtn = document.getElementById('form-btn')


function startForm() {
  document.getElementById('form-btn').style.display = 'none'
  const form = document.getElementById('form-one')
  form.style.display = 'flex'
  const form2 = document.getElementById('form-two')
  form2.style.display = 'none'
}

function startForm2() {
  const form1 = document.getElementById('form-one')
  const form2 = document.getElementById('form-two')
  form1.style.display = 'none'
  form2.style.display = 'flex'
}

const yes1 = document.getElementById('yes-1')

if (yes1.checked == true) {
  console.log("done");
}

function giveAnswer() {
  const yes1 = document.getElementById('yes-1')
  const yes2 = document.getElementById('yes-2')
  const yes3 = document.getElementById('yes-3')
  const yes4 = document.getElementById('yes-4')
  const no2 = document.getElementById('no-2')
  const no3 = document.getElementById('no-3')
  const no4 = document.getElementById('no-4')

  if (yes1.checked) {
    showCompany("Trust")
  } else {
    if (yes2.checked || yes3.checked) {
      showCompany("Pvt. LTD");
    } else {
      showCompany("LLP");
    }
  }
}

function showCompany(name) {
  document.getElementById('form-result').style.display = 'flex'
  document.getElementById('com-type').textContent = name

}