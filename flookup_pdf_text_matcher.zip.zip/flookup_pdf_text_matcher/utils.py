import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (Mail, Attachment, FileContent, FileName, FileType, Disposition)

import environ
env = environ.Env()
# from dotenv import load_dotenv

# load_dotenv(dotenv_path="C:/Users/abjid/Desktop/flookup-pdf-extractor_codes/Frzaor_MangoDB_Project/Frzaor_MangoDB_Project/res.env")

def sendmailfunc(toemail,subject,body,encoded_file):
    message = Mail(
    from_email='tech@flookup.com',
    to_emails=toemail,
    subject=subject,
    html_content=body
    )

    attachedFile = Attachment(
    FileContent(encoded_file),
    FileName('result.csv'),
    FileType('application/csv'),
    Disposition('attachment')
    )
    # print(from_email)
    message.attachment = attachedFile
    sg = SendGridAPIClient(env('SENDGRID_API_KEY'))
    response = sg.send(message)
    print('----------------')
    print(response)
    return response
    