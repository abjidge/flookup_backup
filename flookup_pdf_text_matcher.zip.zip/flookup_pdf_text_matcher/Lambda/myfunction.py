try:
    import json
    import sys
    import os,io
    import boto3
    import requests
    import pandas as pd
    import json
    from io import StringIO 
    from string_grouper import match_strings, match_most_similar,group_similar_strings, compute_pairwise_similarities,StringGrouper
    from requests.auth import HTTPBasicAuth

    print("All imports ok ...")
except Exception as e:
    print("Error Imports : {} ".format(e))

s3 = boto3.client("s3")

def lambda_handler(event, context):
    try:
        print(event)
        incoming_data = json.loads(event['body'])
        print('--Inco-')
        print(incoming_data)
        final_data_path = incoming_data['final_data_file_path']
        data_file = incoming_data['data_file_path']
        email = incoming_data['email']
        user_token = incoming_data['user_token']
        lambda_token = incoming_data['lambda_token']
        
        
        if lambda_token == os.environ['LAMBDA_TOKEN']:

            # Get final data file
            final_data = get_final_csv_from_s3('flookup-pdf-extractor',final_data_path)

            # Get data file
            csv_obj = s3.get_object(Bucket='flookup-pdf-extractor', Key=data_file)
            body = csv_obj['Body']
            # csv_string = body.read().decode('cp1252')
            # data = pd.read_csv(StringIO(csv_string))
            data = pd.read_csv(io.BytesIO(body.read()),usecols=['Sno','Name of the Company','CIN','Company Name Status','CIN Status'])



            # main call
            result = validate_csv_file(final_data,data)
            
            # send mail
            
            url = os.environ['API_SERVER_BASE_URL'] + '/send_mail'
            subject = data_file.split('/')[-1] + " Result"
            body = 'PFA'
            params = {'to_email': email, 'subject': subject, 'body': body}
            slider_output = result.to_csv()
            files = {'file': ('result.csv', slider_output)}
            
            
            response = requests.post(url, params=params,files=files,auth=HTTPBasicAuth(os.environ['API_SERVER_USER'], os.environ['API_SERVER_PASSWORD']))

            # In case issue with sending email upload file to s3
            if response.status_code != 200:
                print('ERROR: Upload file to s3 - '+response.text)
                upload_dataframe_as_csv_to_s3('flookup-pdf-extractor','failed_files/'+final_data_path.split('/')[-1],result)

            # Reduce Limit
            url = os.environ['API_SERVER_BASE_URL']+'/update_limit'
            params = {'token': user_token, 'limit_change': data.shape[0]}
            response = requests.post(url, params=params,auth=HTTPBasicAuth(os.environ['API_SERVER_USER'], os.environ['API_SERVER_PASSWORD']))


            print('------done-----------')
            print(result.shape)

            print("event = {}".format(event))
            return {
                'statusCode': 200,
            }
        else:
            return {
                'statusCode': 401,
            }

    except Exception as e:
        print("Error While Processing File : {} ".format(e))
        return {
                'statusCode': 500,
            }


def get_final_csv_from_s3(bucket_name,file_path):
    
    bucket_name = 'flookup-pdf-extractor'
    object_key = file_path
    try:
        csv_obj = s3.get_object(Bucket=bucket_name, Key=object_key)
    except:
        temp = pd.DataFrame()
        return temp

    body = csv_obj['Body']
    # csv_string = body.read().decode('utf-8')

    # Only Pull specified labels
    # temp = pd.read_csv(StringIO(csv_string),usecols=['file_name','a','b','c','d','f','g','h'])
    temp = pd.read_csv(io.BytesIO(body.read()),usecols=['file_name','a','b','c','d','f','g','h'])

    # Convert Datatype to string object
    for col in temp.columns:
        temp[col] = temp[col].astype(str)

    return temp



def upload_dataframe_as_csv_to_s3(bucket,csv_path,data):
    csv_buffer = StringIO()
    data.to_csv(csv_buffer)
    s3.Object(bucket, csv_path).put(Body=csv_buffer.getvalue())


# Create a small set of artificial company names:

def validate_csv_file(final_data,data):
    data['Company Name Status'] = '-1'
    data['CIN Status'] = '-1'
    data['Company Name Confidance'] = -1.000
    data['Matching Company Name'] = '-1'
    data['CIN Confidance'] = -1.0000
    data['Matching CIN'] = '-1'
    data['file_name'] = '-1'


    data = data.fillna('-1')

    for col in ['Name of the Company','CIN']:
        data[col] = data[col].str.lower()
    df_obj = data.select_dtypes(['object'])
    data[df_obj.columns] = df_obj.apply(lambda x: x.str.strip())

    # Company Name Status
    for col in ['a', 'b', 'c', 'd', 'f', 'g', 'h']:
        print('----Company Name-----')
        print(col)
        matches = match_strings(final_data[col],data['Name of the Company'],min_similarity=0.8)


        for index, row in matches.iterrows():
            if row['similarity'] >= 0.9999:
                data.loc[row['right_index'],'Company Name Status'] = 'Yes'
                data.loc[row['right_index'],'Company Name Confidance'] = 1
                data.loc[row['right_index'],'file_name'] = final_data.at[row['left_index'],'file_name']
                data.loc[row['right_index'],'Matching Company Name'] = final_data.at[row['left_index'],col]

            else:
                if row['similarity'] > data.at[row['right_index'],'Company Name Confidance']: 
                    data.loc[row['right_index'],'Company Name Confidance'] = row['similarity']
                    data.loc[row['right_index'],'file_name'] = final_data.at[row['left_index'],'file_name']
                    data.loc[row['right_index'],'Matching Company Name'] = final_data.at[row['left_index'],col]
                    

    # CIN Status
    for col in ['a', 'b', 'c', 'd', 'f', 'g', 'h']:
        print('----CIN-----')
        print(col)
        matches = match_strings(final_data[col],data['CIN'],min_similarity=0.8)
        
        for index, row in matches.iterrows():
            if row['similarity'] >= 0.9999:
                data.at[row['right_index'],'CIN Status'] = 'Yes'
                data.at[row['right_index'],'CIN Confidance'] = 1
                data.at[row['right_index'],'file_name'] = final_data.at[row['left_index'],'file_name']
                data.loc[row['right_index'],'Matching CIN'] = final_data.at[row['left_index'],col]

            else:
                if row['similarity'] > data.at[row['right_index'],'CIN Confidance']: 
                    data.at[row['right_index'],'CIN Confidance'] = row['similarity']
                    data.at[row['right_index'],'file_name'] = final_data.at[row['left_index'],'file_name']
                    data.loc[row['right_index'],'Matching CIN'] = final_data.at[row['left_index'],col]


    data.loc[data["Name of the Company"] == '-1',"Name of the Company"] = ''
    data.loc[data["CIN"] == '-1',"CIN"] = ''
    data.loc[data["Company Name Status"] == '-1',"Company Name Status"] = ''
    data.loc[data["CIN Status"] == '-1',"CIN Status"] = ''
    data.loc[data["Company Name Confidance"] == -1,"Company Name Confidance"] = None
    data.loc[data["CIN Confidance"] == -1,"CIN Confidance"] = None
    data.loc[data["file_name"] == '-1',"file_name"] = ''
    data.loc[data['Matching Company Name']=='-1','Matching Company Name'] = ''
    data.loc[data['Matching CIN']=='-1','Matching CIN'] = ''


    return data