from flask import Flask, request, jsonify, render_template,Response
import os,io
import json
from flask import Flask,render_template, flash, redirect , url_for , session ,request, logging
from wtforms import Form, StringField , TextAreaField ,PasswordField , validators
from flask import make_response
from flask import send_file
from werkzeug.utils import secure_filename
import boto3
import pandas as pd
from io import StringIO 
import environ
from bson import ObjectId
from flask_pymongo import PyMongo
from flask_httpauth import HTTPBasicAuth
import base64
import time
import requests
from utils import *
import numpy as np
# from string_grouper import match_strings, match_most_similar,group_similar_strings, compute_pairwise_similarities,StringGrouper

app = Flask(__name__)

auth= HTTPBasicAuth()

UPLOAD_FOLDER = os.path.dirname(os.path.realpath(__file__))
ALLOWED_EXTENSIONS = set(['csv'])
ALLOWED_EXTENSIONS_PDF = set(['csv'])

env = environ.Env()

try:  
    app.config["MONGO_URI"] = "mongodb+srv://frazor:vWA98nkzc3dynLw0@cluster0.hxip4.mongodb.net/flookup_pdf_text_matcher?retryWrites=true&w=majority"
    mongodb_client = PyMongo(app)
    db=mongodb_client.db
    
except Exception as e:
    print("server issue",e)


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def allowed_pdf(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS_PDF

@app.route('/download_template', methods=['GET','POST'])
def download_template():
    return send_file('Template.csv', as_attachment=True)

@app.route('/download_pan_template', methods=['GET','POST'])
def download_pan_template():
    return send_file('Pan_Template.csv', as_attachment=True)


@app.route('/index',methods=['GET','POST'])
@app.route('/', methods=['GET','POST'])
def index():
    
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)

        selected_data_file = request.form.get('datafilename')

        inputtoken = request.form.get('inputPassword2')
        email = request.form.get('inputemail')

        user=db.users.find_one({"token":inputtoken})

        print(user) 
        if user!=None:
            if inputtoken == user['token']:

                if selected_data_file == 'Select Option':
                    # return('Select Data File Name')
                    data_file_names = get_data_file_names()
                    return render_template('home.html',data_file_names=data_file_names,status=0,msg = 'Select Data File Name')

                file = request.files['file']

                if file.filename == '':
                    flash('No selected file')
                    return redirect(request.url)

                if file and allowed_file(file.filename):
                    # print('---------aa-------')
                    filename = secure_filename(file.filename)
                    print(filename)
                    # Validate incoming data

                    data = pd.read_csv(request.files.get('file'),encoding='cp1252')

                    if validate_incoming_data(data):
                        print(data.shape[0])

                        if data.shape[0] <= int(user['limit']):
                            ts = str(int(time.time()))
                            data_file_path = 'upload/'+ts+'_'+filename
                            upload_dataframe_as_csv_to_s3(env('BUCKET'),data_file_path,data)

                            url = env('LAMBDA_URL')

                            payload = json.dumps({
                                "lambda_token": env("LAMBDA_TOKEN"),
                                "final_data_file_path": selected_data_file+"/final_data.csv",
                                "data_file_path": data_file_path,
                                "email": email,
                                "user_token": user['token']
                            })

                            headers = {
                            'Content-Type': 'application/json'
                            }   

                            # return payload

                            # trigger Lambda
                            response = requests.request("POST", url, headers=headers, data=payload)

                            if response.status_code == 503:
                                # return "File Submitted You will receive email shortly."
                                data_file_names = get_data_file_names()
                                return render_template('home.html',data_file_names=data_file_names,status=1,msg = 'File Submitted successfully. You will receive email shortly.')

                            else:
                                data_file_names = get_data_file_names()
                                return render_template('home.html',data_file_names=data_file_names,status=0,msg = 'Some error happend, Please upload file again.')
                                # return "Some error happend, Please upload file again"


                            # send email
                            # url = 'http://127.0.0.1:5000/send_mail'
                            # params = {'to_email': 'abhay@frazor.in', 'subject': 'This is a test mail', 'body': 'Congrats working'}
                            # slider_output = data.to_csv()
                            # files = {'file': ('data.csv', slider_output)}
                            # from requests.auth import HTTPBasicAuth
                            # response = requests.post(url, params=params,files=files,auth=HTTPBasicAuth('demo', 'demo@123') )

                            # return response.text

                        else:
                            # return 'Limit reached'
                            data_file_names = get_data_file_names()
                            return render_template('home.html',data_file_names=data_file_names,status=0,msg = 'Limit reached.')

                    else:
                        # return 'Enter valid format CSV'
                        data_file_names = get_data_file_names()
                        return render_template('home.html',data_file_names=data_file_names,status=0,msg = 'Enter valid format CSV.')
                else:
                    # return "File not allowed"
                    data_file_names = get_data_file_names()
                    return render_template('home.html',data_file_names=data_file_names,status=0,msg = 'File not allowed.')

            else:
                # return('Invalid User')
                data_file_names = get_data_file_names()
                return render_template('home.html',data_file_names=data_file_names,status=0,msg = 'Invalid User.')

        else:
            # return('Invalid Token')
            data_file_names = get_data_file_names()
            return render_template('home.html',data_file_names=data_file_names,status=0,msg = 'Invalid Token.')
        
    # global data_file_names
    data_file_names = get_data_file_names()
    print(data_file_names)
    return render_template('home.html',data_file_names=data_file_names,status=None,msg = None)



@app.route('/pan_upload', methods=['GET','POST'])
def pan_upload():
    if request.method == 'POST':

        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)

        selected_data_file = request.form.get('datafilename')

        inputtoken = request.form.get('inputPassword2')
        email = request.form.get('inputemail')

        user=db.users.find_one({"token":inputtoken})

        print(user) 
        if user!=None:
            if inputtoken == user['token']:

                if selected_data_file == 'Select Option':
                    # return('Select Data File Name')
                    data_file_names = get_data_file_names()
                    return render_template('Pan Upload.html',data_file_names=data_file_names,status=0,msg = 'Select Data File Name')

                file = request.files['file']
                print(file)
                if file.filename == '':
                    flash('No selected file')
                    return redirect(request.url)

                if file and allowed_file(file.filename):
                    # print('---------aa-------')
                    filename = secure_filename(file.filename)
                    print(filename)

                    data = pd.read_csv(request.files.get('file'),encoding='cp1252')

                    # Validate PAN
                    data_cols = list(data.columns)
                    for cols in data_cols:
                        if cols not in ['Sno','PAN']:
                            data_file_names = get_data_file_names()
                            return render_template('Pan Upload.html',data_file_names=data_file_names,status=0,msg = 'Invalida File Structure')

                    data = data.fillna('')
                    data['PAN'] = data['PAN'].str.upper()

                    # blanks
                    data['valid'] = np.where(data.PAN.str.contains('', regex=True), '' ,'Invalid')
                    # regex
                    data['valid'] = np.where(data.PAN.str.contains(r'^[A-Z]{5}[0-9]{4}[A-Z]$', regex=True), '' ,'Invalid')
                    
                    if data.valid.str.contains('Invalid').any():
                        # data_file_names = get_data_file_names()
                        resp = make_response(data.to_csv())
                        resp.headers["Content-Disposition"] = "attachment; filename=Invalid PANs.csv"
                        resp.headers["Content-Type"] = "text/csv"
                        return resp
                    else:
                        data = data[['Sno','PAN']]


                    # send email
                    url = 'http://0.0.0.0:5000/send_mail'
                    subject = 'Pan Validation - '+filename
                    body = 'User: '+user['username']+'<br>Email: '+ email
                    params = {'to_email': 'tech@flookup.com', 'subject': subject, 'body': body}
                    slider_output = data.to_csv()
                    files = {'file': ('data.csv', slider_output)}
                    from requests.auth import HTTPBasicAuth
                    response = requests.post(url, params=params,files=files,auth=HTTPBasicAuth('demo', 'demo@123') )
                    # return response.text
                    if response.status_code == 200:
                        data_file_names = get_data_file_names()
                        return render_template('Pan Upload.html',data_file_names=data_file_names,status=1,msg = 'File Submitted successfully')
                    else:
                        data_file_names = get_data_file_names()
                        return render_template('Pan Upload.html',data_file_names=data_file_names,status=0,msg = 'Something went wrong , Please submit again')

                else:
                    # return "File not allowed"
                    data_file_names = get_data_file_names()
                    return render_template('Pan Upload.html',data_file_names=data_file_names,status=0,msg = 'File not allowed.')

            else:
                # return('Invalid User')
                data_file_names = get_data_file_names()
                return render_template('Pan Upload.html',data_file_names=data_file_names,status=0,msg = 'Invalid User.')
        else:
            data_file_names = get_data_file_names()
            return render_template('Pan Upload.html',data_file_names=data_file_names,status=0,msg = 'Invalid User.')
    
    
    data_file_names = get_data_file_names()
    return render_template('Pan Upload.html',data_file_names=data_file_names,status=1,msg = '')



def upload_dataframe_as_csv_to_s3(bucket,csv_path,data):
    csv_buffer = StringIO()
    data.to_csv(csv_buffer)

    s3 = boto3.resource('s3',region_name=env('REGION_NAME'), 
                    aws_access_key_id=env('AWS_ACCESS_KEY'), 
                    aws_secret_access_key=env('AWS_SECRET_ACCESS_KEY'))

    s3.Object(bucket, csv_path).put(Body=csv_buffer.getvalue())


def validate_incoming_data(data):
    columns = list(data.columns)
    flag = 0
    for col in columns:
        if col.lower() not in ['sno','name of the company','cin','company name status', 'cin status']:
            flag = 1
            break
    if flag == 1:
        return 0
    return 1


def get_data_file_names():
    s3 = boto3.resource("s3", 
                  region_name=env('REGION_NAME'), 
                  aws_access_key_id=env('AWS_ACCESS_KEY'), 
                  aws_secret_access_key=env('AWS_SECRET_ACCESS_KEY'))
    
    my_bucket = s3.Bucket(env('BUCKET'))

    data_files_list = []
    for obj in my_bucket.objects.all():
        if obj.key.endswith('final_data.csv'):
            print(obj.key)
            if len(obj.key.split('/')) == 2:
                data_files_list.append(obj.key.split('/')[0])

    return data_files_list



##################################### Verifies if User is present in DB(If present Login deco will be True) #####################################

@auth.verify_password
def verify(username,password):
    user=db.Auth.find_one({"username":username,"password":password})
    if user:
        return True
    else:
        return False

##################################### Gives all users names #####################################


@app.route("/all_users",methods=["get"])
@auth.login_required
def read_user():
    user=db.Auth.find_one({"username":request.authorization["username"],"password":request.authorization["password"]})
    current_user_id=str(user["_id"])
    try:
        data=list(db.users.find({"user_id":current_user_id}))
        for user in data:
            user["_id"]=str(user["_id"])
        return Response(
            response=json.dumps(data),
            status=200,
            mimetype='application/json'
        )

    except Exception as e:
        print("exception",e)
        return Response(
            response="Couldn't find user",
            status=500,
            mimetype='application/json'
        )

##################################### Sends all users details to backend #####################################

@app.route("/post_user",methods=["post"])
@auth.login_required
def create_user():
    user_auth=db.Auth.find_one({"username":request.authorization["username"],"password":request.authorization["password"]})
    current_user_id=str(user_auth["_id"])
    try:
        user=dict(request.args)
        user["user_id"]=current_user_id
        data=list(db.users.find({"user_id":current_user_id}))
        for users in data:
            if users["username"]==user["username"]:
                return Response(
                    response="username taken",
                    status=200,
                    mimetype='application/json'
                )
            elif users["token"]==user["token"]:
                return Response(
                    response="token taken",
                    status=200,
                    mimetype='application/json'
                )
        dbresponse=db.users.insert_one(user)
        x=json.dumps({"message":"user created","id":f"{dbresponse.inserted_id}"})
        return Response(
            response=x,
            status=200,
            mimetype='application/json'
        )
    except Exception as e:
        print("exception",e)

##################################### Updates any one user details #####################################

@app.route("/update_user",methods=["post"])
@auth.login_required
def update_user():
    user_auth=db.Auth.find_one({"username":request.authorization["username"],"password":request.authorization["password"]})
    current_user_id=str(user_auth["_id"])
    try:
        user_details=dict(request.args)
        data=list(db.users.find())
        user=db.users.find_one({"username":user_details["username"],"user_id":current_user_id})
        if user:
            if "token" in user_details.keys():
                for users in data:
                    if users["token"]==user_details["token"]:
                        return Response(
                            response="token taken",
                            status=200,
                            mimetype='application/json'
                        )
            dbresponse=db.users.update_one(
                {"_id":ObjectId(user["_id"])},
                {"$set":user_details}
            )
        else:
            x=json.dumps({"message":"User not found"})
            return Response(
                response=x,
                status=500,
                mimetype='application/json'
            )
        if dbresponse.modified_count>=1:
            x=json.dumps({"message":"user updated"})
            return Response(
                response=x,
                status=200,
                mimetype='application/json'
            )
        else:
            x=json.dumps({"message":"Nothing to Update"})
            return Response(
                response=x,
                status=200,
                mimetype='application/json'
            )
    except Exception as e:
        print("exception",e)
        x=json.dumps({"message":"credentials error"})
        return Response(
            response=x,
            status=500,
            mimetype='application/json'
        )
        

##################################### Deletes any one user #####################################

@app.route("/delete_user",methods=["post"])
@auth.login_required
def delete_user():
    user_auth=db.Auth.find_one({"username":request.authorization["username"],"password":request.authorization["password"]})
    current_user_id=str(user_auth["_id"])
    try:
        username=request.args.get("username")
        user=db.users.find_one({"username":username,"user_id":current_user_id})
        if user:
            dbresponse=db.users.delete_one({"username":username})
            if dbresponse.deleted_count==1:
                x=json.dumps({"message":"user deleted"})
                return Response(
                    response=x,
                    status=200,
                    mimetype='application/json'
                )
        else:
            x=json.dumps({"message":"User not found"})
            return Response(
                response=x,
                status=200,
                mimetype='application/json'
            )
    except Exception as e:
        print("exception",e)
        x=json.dumps({"message":"credentials error"})
        return Response(
            response=x,
            status=500,
            mimetype='application/json'
        )


##################################### Updates Limit of user #####################################

@app.route("/update_limit",methods=["post"])
@auth.login_required
def update_limit():
    user_auth=db.Auth.find_one({"username":request.authorization["username"],"password":request.authorization["password"]})
    current_user_id=str(user_auth["_id"])
    try:
        limit_details=dict(request.args)
        user=db.users.find_one({"token":limit_details["token"],"user_id":current_user_id})
        if user:
            if (int(user["limit"])-int(limit_details["limit_change"]))>=0:
                dbresponse=db.users.update_one(
                    {"token":limit_details["token"]},
                    {"$set":{"limit": int(int(user["limit"])-int(limit_details["limit_change"]))}}
                )
                x=json.dumps({"message":"Successfully Changed Limit"})
                return Response(
                    response=x,
                    status=200,
                    mimetype='application/json'
                )
            else:
                x=json.dumps({"message":"Present Limit is too Low to decrease"})
                return Response(
                    response=x,
                    status=500,
                    mimetype='application/json'
                )
        else:
            x=json.dumps({"message":"User not Found"})
            return Response(
                response=x,
                status=500,
                mimetype='application/json'
            )
    except Exception as e:
        print("exception",e)
        x=json.dumps({"message":"credentials error"})
        return Response(
            response=x,
            status=500,
            mimetype='application/json'
        )

##################################### Sends emails to user #####################################

@app.route("/send_mail",methods=["post"])
@auth.login_required
def Send_mail():
    data=request.args
    print(dict(request.files))
    obj=request.files['file'].read()
    try:
        encoded_file = base64.b64encode(obj).decode()
        resp = sendmailfunc(data['to_email'],data['subject'],data['body'],encoded_file)
        # sendmailfunc(data['to_email'],data['subject'],data['body'],encoded_file,data['file_name'])
        print(resp)
        return Response(
            response="Succesfully Sent",
            status=200,
            mimetype='application/csv'
        )
    except Exception as e:
        print("exception",e)
        return Response(
            response="Email credentials error",
            status=500,
            mimetype='application/json'
        )

if __name__ == "__main__":
    app.secret_key='secret123'
    app.run(port=5000,debug=True)
